'use client'

import { useState, useEffect, createContext, useContext, ReactNode } from 'react'

export interface Currency {
  code: string
  name: string
  symbol: string
  rate: number
}

interface CurrencyContextType {
  currency: string
  setCurrency: (currency: string) => void
  currencies: Currency[]
  formatPrice: (price: number, fromCurrency?: string) => string
  convertPrice: (price: number, fromCurrency?: string, toCurrency?: string) => number
  loading: boolean
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined)

const defaultCurrencies: Currency[] = [
  { code: 'USD', name: 'US Dollar', symbol: '$', rate: 1 },
  { code: 'EUR', name: 'Euro', symbol: '€', rate: 0.85 },
  { code: 'IDR', name: 'Indonesian Rupiah', symbol: 'Rp', rate: 15000 },
  { code: 'GBP', name: 'British Pound', symbol: '£', rate: 0.73 },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥', rate: 110 },
  { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', rate: 6.45 },
  { code: 'INR', name: 'Indian Rupee', symbol: '₹', rate: 74 },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', rate: 1.35 },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$', rate: 1.25 },
  { code: 'CHF', name: 'Swiss Franc', symbol: 'CHF', rate: 0.92 }
]

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [currency, setCurrencyState] = useState<string>('USD')
  const [currencies, setCurrencies] = useState<Currency[]>(defaultCurrencies)
  const [loading, setLoading] = useState(false)

  // Load currency from localStorage
  useEffect(() => {
    const savedCurrency = localStorage.getItem('currency')
    if (savedCurrency) {
      setCurrencyState(savedCurrency)
    }
  }, [])

  // Save currency to localStorage
  const setCurrency = (newCurrency: string) => {
    setCurrencyState(newCurrency)
    localStorage.setItem('currency', newCurrency)
  }

  // Fetch real-time exchange rates (mock implementation)
  const fetchExchangeRates = async () => {
    setLoading(true)
    try {
      // In production, you would call a real API like fixer.io or openexchangerates.org
      // For now, we'll use mock data
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // Mock API response
      const mockRates = {
        USD: 1,
        EUR: 0.85,
        IDR: 15000,
        GBP: 0.73,
        JPY: 110,
        CNY: 6.45,
        INR: 74,
        AUD: 1.35,
        CAD: 1.25,
        CHF: 0.92
      }

      const updatedCurrencies = currencies.map(curr => ({
        ...curr,
        rate: mockRates[curr.code as keyof typeof mockRates] || curr.rate
      }))

      setCurrencies(updatedCurrencies)
    } catch (error) {
      console.error('Failed to fetch exchange rates:', error)
    } finally {
      setLoading(false)
    }
  }

  // Convert price from one currency to another
  const convertPrice = (
    price: number, 
    fromCurrency: string = 'USD', 
    toCurrency: string = currency
  ): number => {
    const fromRate = currencies.find(c => c.code === fromCurrency)?.rate || 1
    const toRate = currencies.find(c => c.code === toCurrency)?.rate || 1
    
    // Convert to USD first, then to target currency
    const usdPrice = price / fromRate
    return usdPrice * toRate
  }

  // Format price with currency symbol
  const formatPrice = (
    price: number, 
    fromCurrency: string = 'USD'
  ): string => {
    const convertedPrice = convertPrice(price, fromCurrency, currency)
    const currencyInfo = currencies.find(c => c.code === currency)
    
    if (!currencyInfo) return `$${price.toFixed(2)}`
    
    // Format based on currency
    switch (currency) {
      case 'IDR':
        return `${currencyInfo.symbol} ${convertedPrice.toLocaleString('id-ID', {
          minimumFractionDigits: 0,
          maximumFractionDigits: 0
        })}`
      case 'JPY':
        return `${currencyInfo.symbol}${convertedPrice.toLocaleString('ja-JP', {
          minimumFractionDigits: 0,
          maximumFractionDigits: 0
        })}`
      case 'EUR':
        return `${convertedPrice.toFixed(2).replace('.', ',')}${currencyInfo.symbol}`
      case 'GBP':
        return `${currencyInfo.symbol}${convertedPrice.toFixed(2)}`
      default:
        return `${currencyInfo.symbol}${convertedPrice.toFixed(2)}`
    }
  }

  // Auto-fetch exchange rates every hour
  useEffect(() => {
    fetchExchangeRates()
    const interval = setInterval(fetchExchangeRates, 60 * 60 * 1000) // 1 hour
    return () => clearInterval(interval)
  }, [])

  const value: CurrencyContextType = {
    currency,
    setCurrency,
    currencies,
    formatPrice,
    convertPrice,
    loading
  }

  return (
    <CurrencyContext.Provider value={value}>
      {children}
    </CurrencyContext.Provider>
  )
}

export function useCurrency() {
  const context = useContext(CurrencyContext)
  if (context === undefined) {
    throw new Error('useCurrency must be used within a CurrencyProvider')
  }
  return context
}