'use client'

import { useState, useEffect, useCallback } from 'react'
import { 
  StoreConfiguration, 
  DEFAULT_CONFIG, 
  DEFAULT_THEMES,
  StoreTheme,
  StoreFeatures,
  StoreBranding 
} from '@/lib/store-config'

const STORAGE_KEY = 'shophub_store_config'

export function useStoreConfig(storeId: string) {
  const [config, setConfig] = useState<StoreConfiguration>(DEFAULT_CONFIG)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Load configuration from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY}_${storeId}`)
      if (stored) {
        const parsedConfig = JSON.parse(stored)
        setConfig({
          ...DEFAULT_CONFIG,
          ...parsedConfig,
          storeId,
          lastModified: parsedConfig.lastModified || new Date().toISOString()
        })
      } else {
        setConfig({
          ...DEFAULT_CONFIG,
          storeId,
          lastModified: new Date().toISOString()
        })
      }
    } catch (err) {
      setError('Failed to load store configuration')
      console.error('Store config load error:', err)
    } finally {
      setIsLoading(false)
    }
  }, [storeId])

  // Save configuration to localStorage
  const saveConfig = useCallback((newConfig: Partial<StoreConfiguration>) => {
    try {
      const updatedConfig = {
        ...config,
        ...newConfig,
        storeId,
        lastModified: new Date().toISOString()
      }
      
      localStorage.setItem(`${STORAGE_KEY}_${storeId}`, JSON.stringify(updatedConfig))
      setConfig(updatedConfig)
      setError(null)
      return true
    } catch (err) {
      setError('Failed to save store configuration')
      console.error('Store config save error:', err)
      return false
    }
  }, [config, storeId])

  // Update theme
  const updateTheme = useCallback((theme: StoreTheme) => {
    return saveConfig({ theme })
  }, [saveConfig])

  // Apply preset theme
  const applyPresetTheme = useCallback((themeId: string) => {
    const presetTheme = DEFAULT_THEMES[themeId]
    if (presetTheme) {
      return updateTheme(presetTheme)
    }
    return false
  }, [updateTheme])

  // Update features
  const updateFeatures = useCallback((features: Partial<StoreFeatures>) => {
    return saveConfig({ 
      features: { ...config.features, ...features }
    })
  }, [saveConfig, config.features])

  // Update branding
  const updateBranding = useCallback((branding: Partial<StoreBranding>) => {
    return saveConfig({ 
      branding: { ...config.branding, ...branding }
    })
  }, [saveConfig, config.branding])

  // Update custom CSS
  const updateCustomCSS = useCallback((customCSS: string) => {
    return saveConfig({ customCSS })
  }, [saveConfig])

  // Reset to default
  const resetToDefault = useCallback(() => {
    return saveConfig(DEFAULT_CONFIG)
  }, [saveConfig])

  // Export configuration
  const exportConfig = useCallback(() => {
    try {
      const dataStr = JSON.stringify(config, null, 2)
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr)
      
      const exportFileDefaultName = `store-config-${storeId}-${Date.now()}.json`
      
      const linkElement = document.createElement('a')
      linkElement.setAttribute('href', dataUri)
      linkElement.setAttribute('download', exportFileDefaultName)
      linkElement.click()
      
      return true
    } catch (err) {
      setError('Failed to export configuration')
      return false
    }
  }, [config, storeId])

  // Import configuration
  const importConfig = useCallback((file: File) => {
    return new Promise<boolean>((resolve) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const imported = JSON.parse(e.target?.result as string)
          const success = saveConfig({
            ...imported,
            storeId,
            lastModified: new Date().toISOString()
          })
          resolve(success)
        } catch (err) {
          setError('Failed to import configuration')
          resolve(false)
        }
      }
      reader.readAsText(file)
    })
  }, [saveConfig, storeId])

  // Generate CSS variables from theme
  const generateCSSVariables = useCallback(() => {
    const { colors, fonts, layout, effects } = config.theme
    return {
      '--store-primary': colors.primary,
      '--store-secondary': colors.secondary,
      '--store-accent': colors.accent,
      '--store-background': colors.background,
      '--store-surface': colors.surface,
      '--store-text': colors.text,
      '--store-text-secondary': colors.textSecondary,
      '--store-border': colors.border,
      '--store-font-heading': fonts.heading,
      '--store-font-body': fonts.body,
      '--store-font-button': fonts.button,
      '--store-border-radius': layout.borderRadius,
      '--store-shadow': effects.shadows ? '0 4px 6px -1px rgba(0, 0, 0, 0.1)' : 'none',
      '--store-transition': effects.transitions ? 'all 0.3s ease' : 'none'
    }
  }, [config.theme])

  return {
    config,
    isLoading,
    error,
    saveConfig,
    updateTheme,
    applyPresetTheme,
    updateFeatures,
    updateBranding,
    updateCustomCSS,
    resetToDefault,
    exportConfig,
    importConfig,
    generateCSSVariables,
    availableThemes: Object.values(DEFAULT_THEMES)
  }
}

// Hook for store visitors (read-only)
export function useStoreTheme(storeId: string) {
  const [theme, setTheme] = useState<StoreTheme>(DEFAULT_THEMES.light)
  const [features, setFeatures] = useState(DEFAULT_FEATURES)
  const [branding, setBranding] = useState(DEFAULT_BRANDING)
  const [customCSS, setCustomCSS] = useState('')
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY}_${storeId}`)
      if (stored) {
        const config = JSON.parse(stored)
        setTheme(config.theme || DEFAULT_THEMES.light)
        setFeatures(config.features || DEFAULT_FEATURES)
        setBranding(config.branding || DEFAULT_BRANDING)
        setCustomCSS(config.customCSS || '')
      }
    } catch (err) {
      console.error('Failed to load store theme:', err)
    } finally {
      setIsLoading(false)
    }
  }, [storeId])

  return {
    theme,
    features,
    branding,
    customCSS,
    isLoading,
    cssVariables: {
      '--store-primary': theme.colors.primary,
      '--store-secondary': theme.colors.secondary,
      '--store-accent': theme.colors.accent,
      '--store-background': theme.colors.background,
      '--store-surface': theme.colors.surface,
      '--store-text': theme.colors.text,
      '--store-text-secondary': theme.colors.textSecondary,
      '--store-border': theme.colors.border,
      '--store-font-heading': theme.fonts.heading,
      '--store-font-body': theme.fonts.body,
      '--store-font-button': theme.fonts.button,
      '--store-border-radius': theme.layout.borderRadius,
      '--store-shadow': theme.effects.shadows ? '0 4px 6px -1px rgba(0, 0, 0, 0.1)' : 'none',
      '--store-transition': theme.effects.transitions ? 'all 0.3s ease' : 'none'
    }
  }
}