'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { productService } from '@/lib/products'

export interface CartItem {
  id: string
  productId: string
  name: string
  price: number
  image: string
  quantity: number
  slug: string
  comparePrice?: number
  stock: number
}

interface CartStore {
  items: CartItem[]
  addItem: (item: Omit<CartItem, 'id'>) => { success: boolean; message: string }
  removeItem: (productId: string) => void
  updateQuantity: (productId: string, quantity: number) => { success: boolean; message: string }
  clearCart: () => void
  getTotalItems: () => number
  getTotalPrice: () => number
  getSubtotal: () => number
  getDiscountAmount: () => number
  getFinalTotal: () => number
  isInCart: (productId: string) => boolean
  getItemQuantity: (productId: string) => number
  getCartSummary: () => {
    totalItems: number
    subtotal: number
    discount: number
    total: number
    totalWeight: number
  }
  validateCart: () => { isValid: boolean; invalidItems: CartItem[]; message: string }
  syncWithProductData: () => void
}

export const useCart = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      
      addItem: (newItem) => {
        const { items } = get()
        const product = productService.getProductById(newItem.productId)
        
        // Check if product exists and is active
        if (!product) {
          return { success: false, message: 'Produk tidak ditemukan' }
        }
        
        // Check if product is in stock
        if (!productService.isInStock(newItem.productId, newItem.quantity)) {
          return { success: false, message: 'Stok produk tidak mencukupi' }
        }
        
        const existingItem = items.find(item => item.productId === newItem.productId)
        
        if (existingItem) {
          const newQuantity = existingItem.quantity + newItem.quantity
          
          // Check stock for existing item
          if (!productService.isInStock(newItem.productId, newQuantity)) {
            return { success: false, message: 'Stok produk tidak mencukupi' }
          }
          
          set({
            items: items.map(item =>
              item.productId === newItem.productId
                ? { 
                    ...item, 
                    quantity: newQuantity,
                    price: product.price,
                    comparePrice: product.comparePrice,
                    stock: product.stock
                  }
                : item
            )
          })
        } else {
          set({
            items: [...items, { 
              ...newItem, 
              id: Date.now().toString(),
              price: product.price,
              comparePrice: product.comparePrice,
              stock: product.stock
            }]
          })
        }
        
        return { success: true, message: 'Produk berhasil ditambahkan ke keranjang' }
      },
      
      removeItem: (productId) => {
        set({
          items: get().items.filter(item => item.productId !== productId)
        })
      },
      
      updateQuantity: (productId, quantity) => {
        if (quantity <= 0) {
          get().removeItem(productId)
          return { success: true, message: 'Produk dihapus dari keranjang' }
        }
        
        const product = productService.getProductById(productId)
        if (!product) {
          return { success: false, message: 'Produk tidak ditemukan' }
        }
        
        if (!productService.isInStock(productId, quantity)) {
          return { success: false, message: 'Stok produk tidak mencukupi' }
        }
        
        set({
          items: get().items.map(item =>
            item.productId === productId
              ? { 
                  ...item, 
                  quantity,
                  price: product.price,
                  comparePrice: product.comparePrice,
                  stock: product.stock
                }
              : item
          )
        })
        
        return { success: true, message: 'Jumlah produk diperbarui' }
      },
      
      clearCart: () => {
        set({ items: [] })
      },
      
      getTotalItems: () => {
        return get().items.reduce((total, item) => total + item.quantity, 0)
      },
      
      getSubtotal: () => {
        return get().items.reduce((total, item) => total + (item.price * item.quantity), 0)
      },
      
      getDiscountAmount: () => {
        return get().items.reduce((total, item) => {
          if (item.comparePrice && item.comparePrice > item.price) {
            return total + ((item.comparePrice - item.price) * item.quantity)
          }
          return total
        }, 0)
      },
      
      getTotalPrice: () => {
        return get().items.reduce((total, item) => total + (item.price * item.quantity), 0)
      },
      
      getFinalTotal: () => {
        const subtotal = get().getSubtotal()
        const discount = get().getDiscountAmount()
        return subtotal - discount
      },
      
      isInCart: (productId) => {
        return get().items.some(item => item.productId === productId)
      },
      
      getItemQuantity: (productId) => {
        const item = get().items.find(item => item.productId === productId)
        return item ? item.quantity : 0
      },
      
      getCartSummary: () => {
        const items = get().items
        const totalItems = items.reduce((total, item) => total + item.quantity, 0)
        const subtotal = items.reduce((total, item) => total + (item.price * item.quantity), 0)
        const discount = items.reduce((total, item) => {
          if (item.comparePrice && item.comparePrice > item.price) {
            return total + ((item.comparePrice - item.price) * item.quantity)
          }
          return total
        }, 0)
        const total = subtotal - discount
        const totalWeight = items.reduce((total, item) => {
          const product = productService.getProductById(item.productId)
          return total + (product ? product.weight * item.quantity : 0)
        }, 0)
        
        return {
          totalItems,
          subtotal,
          discount,
          total,
          totalWeight
        }
      },
      
      validateCart: () => {
        const items = get().items
        const invalidItems: CartItem[] = []
        
        for (const item of items) {
          const product = productService.getProductById(item.productId)
          
          if (!product || !product.isActive) {
            invalidItems.push(item)
            continue
          }
          
          if (!productService.isInStock(item.productId, item.quantity)) {
            invalidItems.push(item)
          }
        }
        
        if (invalidItems.length > 0) {
          return {
            isValid: false,
            invalidItems,
            message: `${invalidItems.length} produk dalam keranjang tidak lagi tersedia atau stok tidak mencukupi`
          }
        }
        
        return { isValid: true, invalidItems: [], message: 'Keranjang valid' }
      },
      
      syncWithProductData: () => {
        const items = get().items
        const updatedItems = items.map(item => {
          const product = productService.getProductById(item.productId)
          if (product) {
            return {
              ...item,
              price: product.price,
              comparePrice: product.comparePrice,
              stock: product.stock
            }
          }
          return item
        }).filter(item => {
          const product = productService.getProductById(item.productId)
          return product && product.isActive
        })
        
        set({ items: updatedItems })
      }
    }),
    {
      name: 'cart-storage',
      onRehydrateStorage: () => (state) => {
        if (state) {
          state.syncWithProductData()
        }
      }
    }
  )
)