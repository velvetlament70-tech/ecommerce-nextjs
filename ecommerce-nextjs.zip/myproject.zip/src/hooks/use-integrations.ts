'use client'

import { useState, useEffect, useCallback } from 'react'
import { 
  IntegrationConfig, 
  DEFAULT_INTEGRATIONS,
  GoogleMapsConfig,
  RajaOngkirConfig,
  WhatsAppConfig,
  TelegramConfig,
  MarketplaceConfig,
  ShippingRate,
  GeocodeResult,
  MarketplaceProduct,
  MarketplaceOrder
} from '@/lib/integrations'

const STORAGE_KEY = 'shophub_integrations'

export function useIntegrations() {
  const [integrations, setIntegrations] = useState<IntegrationConfig[]>(DEFAULT_INTEGRATIONS)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Load integrations from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      if (stored) {
        const parsed = JSON.parse(stored)
        setIntegrations(parsed)
      }
    } catch (err) {
      setError('Failed to load integrations')
      console.error('Integrations load error:', err)
    } finally {
      setIsLoading(false)
    }
  }, [])

  // Save integrations to localStorage
  const saveIntegrations = useCallback((newIntegrations: IntegrationConfig[]) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newIntegrations))
      setIntegrations(newIntegrations)
      setError(null)
      return true
    } catch (err) {
      setError('Failed to save integrations')
      console.error('Integrations save error:', err)
      return false
    }
  }, [])

  // Update integration
  const updateIntegration = useCallback((id: string, updates: Partial<IntegrationConfig>) => {
    const newIntegrations = integrations.map(integration => 
      integration.id === id 
        ? { ...integration, ...updates, lastSync: new Date().toISOString() }
        : integration
    )
    return saveIntegrations(newIntegrations)
  }, [integrations, saveIntegrations])

  // Get integration by ID
  const getIntegration = useCallback((id: string) => {
    return integrations.find(integration => integration.id === id)
  }, [integrations])

  // Get integrations by category
  const getIntegrationsByCategory = useCallback((category: string) => {
    return integrations.filter(integration => integration.category === category)
  }, [integrations])

  // Test integration
  const testIntegration = useCallback(async (id: string) => {
    const integration = getIntegration(id)
    if (!integration) return false

    try {
      updateIntegration(id, { status: 'testing' })
      
      // Simulate API test
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Mock test result
      const success = Math.random() > 0.3 // 70% success rate for demo
      
      updateIntegration(id, { 
        status: success ? 'active' : 'error',
        error: success ? undefined : 'Connection failed'
      })
      
      return success
    } catch (err) {
      updateIntegration(id, { 
        status: 'error', 
        error: 'Test failed'
      })
      return false
    }
  }, [getIntegration, updateIntegration])

  return {
    integrations,
    isLoading,
    error,
    updateIntegration,
    getIntegration,
    getIntegrationsByCategory,
    testIntegration,
    saveIntegrations
  }
}

// Google Maps Integration
export function useGoogleMaps() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const geocodeAddress = useCallback(async (address: string): Promise<GeocodeResult | null> => {
    setIsLoading(true)
    setError(null)

    try {
      // Mock implementation - replace with actual Google Maps API
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // Mock geocoding result
      const mockResult: GeocodeResult = {
        address_components: [
          { long_name: 'Jakarta', short_name: 'JKT', types: ['locality'] },
          { long_name: 'Indonesia', short_name: 'ID', types: ['country'] }
        ],
        formatted_address: address,
        geometry: {
          location: { lat: -6.2088, lng: 106.8456 }
        },
        place_id: 'mock_place_id',
        types: ['establishment']
      }
      
      return mockResult
    } catch (err) {
      setError('Failed to geocode address')
      return null
    } finally {
      setIsLoading(false)
    }
  }, [])

  const calculateDistance = useCallback(async (
    origin: { lat: number; lng: number },
    destination: { lat: number; lng: number }
  ): Promise<number> => {
    setIsLoading(true)
    setError(null)

    try {
      // Mock implementation
      await new Promise(resolve => setTimeout(resolve, 500))
      
      // Mock distance calculation (in km)
      const distance = Math.random() * 50 + 5 // 5-55 km
      return Math.round(distance * 100) / 100
    } catch (err) {
      setError('Failed to calculate distance')
      return 0
    } finally {
      setIsLoading(false)
    }
  }, [])

  return {
    geocodeAddress,
    calculateDistance,
    isLoading,
    error
  }
}

// RajaOngkir Integration
export function useRajaOngkir() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const getShippingRates = useCallback(async (
    origin: string,
    destination: string,
    weight: number,
    courier: string[] = ['jne', 'tiki', 'pos']
  ): Promise<ShippingRate[]> => {
    setIsLoading(true)
    setError(null)

    try {
      // Mock implementation - replace with actual RajaOngkir API
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      // Mock shipping rates
      const mockRates: ShippingRate[] = [
        {
          service: 'REG',
          description: 'Layanan Reguler',
          cost: 15000,
          etd: '2-3 hari',
          courier: 'JNE'
        },
        {
          service: 'YES',
          description: 'Yakin Esok Sampai',
          cost: 25000,
          etd: '1-2 hari',
          courier: 'JNE'
        },
        {
          service: 'ECO',
          description: 'Ekonomis',
          cost: 10000,
          etd: '4-7 hari',
          courier: 'POS Indonesia'
        },
        {
          service: 'SDS',
          description: 'Same Day Service',
          cost: 35000,
          etd: 'Hari ini',
          courier: 'TIKI'
        }
      ]
      
      return mockRates.filter(rate => courier.some(c => rate.courier.toLowerCase().includes(c.toLowerCase())))
    } catch (err) {
      setError('Failed to fetch shipping rates')
      return []
    } finally {
      setIsLoading(false)
    }
  }, [])

  const getProvinces = useCallback(async (): Promise<Array<{ id: string; province: string }>> => {
    try {
      // Mock provinces
      return [
        { id: '1', province: 'DKI Jakarta' },
        { id: '2', province: 'Jawa Barat' },
        { id: '3', province: 'Jawa Tengah' },
        { id: '4', province: 'Jawa Timur' },
        { id: '5', province: 'Bali' },
        { id: '6', province: 'Sumatera Utara' },
        { id: '7', province: 'Sumatera Barat' },
        { id: '8', province: 'Sulawesi Selatan' }
      ]
    } catch (err) {
      setError('Failed to fetch provinces')
      return []
    }
  }, [])

  const getCities = useCallback(async (provinceId: string): Promise<Array<{ id: string; city: string; type: string }>> => {
    try {
      // Mock cities
      return [
        { id: '1', city: 'Jakarta Pusat', type: 'Kota' },
        { id: '2', city: 'Jakarta Utara', type: 'Kota' },
        { id: '3', city: 'Jakarta Selatan', type: 'Kota' },
        { id: '4', city: 'Bandung', type: 'Kota' },
        { id: '5', city: 'Surabaya', type: 'Kota' },
        { id: '6', city: 'Medan', type: 'Kota' },
        { id: '7', city: 'Semarang', type: 'Kota' },
        { id: '8', city: 'Denpasar', type: 'Kota' }
      ]
    } catch (err) {
      setError('Failed to fetch cities')
      return []
    }
  }, [])

  return {
    getShippingRates,
    getProvinces,
    getCities,
    isLoading,
    error
  }
}

// WhatsApp Integration
export function useWhatsApp() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const sendMessage = useCallback(async (
    phoneNumber: string,
    message: string,
    config: WhatsAppConfig
  ): Promise<boolean> => {
    setIsLoading(true)
    setError(null)

    try {
      // Mock implementation - replace with actual WhatsApp API
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // Mock send message
      console.log('Sending WhatsApp message:', {
        to: phoneNumber,
        message,
        from: config.phoneNumber
      })
      
      return true
    } catch (err) {
      setError('Failed to send WhatsApp message')
      return false
    } finally {
      setIsLoading(false)
    }
  }, [])

  const generateWhatsAppLink = useCallback((phoneNumber: string, message: string): string => {
    const cleanPhone = phoneNumber.replace(/[^\d+]/g, '')
    const encodedMessage = encodeURIComponent(message)
    return `https://wa.me/${cleanPhone}?text=${encodedMessage}`
  }, [])

  return {
    sendMessage,
    generateWhatsAppLink,
    isLoading,
    error
  }
}

// Telegram Integration
export function useTelegram() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const sendMessage = useCallback(async (
    chatId: string,
    message: string,
    config: TelegramConfig
  ): Promise<boolean> => {
    setIsLoading(true)
    setError(null)

    try {
      // Mock implementation - replace with actual Telegram Bot API
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // Mock send message
      console.log('Sending Telegram message:', {
        chatId,
        message,
        parseMode: config.parseMode
      })
      
      return true
    } catch (err) {
      setError('Failed to send Telegram message')
      return false
    } finally {
      setIsLoading(false)
    }
  }, [])

  return {
    sendMessage,
    isLoading,
    error
  }
}

// Marketplace Integration
export function useMarketplace() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const syncProducts = useCallback(async (
    platform: string,
    config: MarketplaceConfig
  ): Promise<MarketplaceProduct[]> => {
    setIsLoading(true)
    setError(null)

    try {
      // Mock implementation - replace with actual marketplace API
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Mock products
      const mockProducts: MarketplaceProduct[] = [
        {
          id: '1',
          name: 'Laptop Gaming Pro',
          price: 15000000,
          stock: 10,
          description: 'Laptop gaming high performance',
          images: ['laptop1.jpg'],
          category: 'Electronics',
          status: 'active',
          url: `https://${platform}.com/p/1`,
          platform
        },
        {
          id: '2',
          name: 'Smartphone Premium',
          price: 8000000,
          stock: 25,
          description: 'Smartphone flagship terbaru',
          images: ['phone1.jpg'],
          category: 'Electronics',
          status: 'active',
          url: `https://${platform}.com/p/2`,
          platform
        }
      ]
      
      return mockProducts
    } catch (err) {
      setError('Failed to sync products')
      return []
    } finally {
      setIsLoading(false)
    }
  }, [])

  const syncOrders = useCallback(async (
    platform: string,
    config: MarketplaceConfig
  ): Promise<MarketplaceOrder[]> => {
    setIsLoading(true)
    setError(null)

    try {
      // Mock implementation
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      // Mock orders
      const mockOrders: MarketplaceOrder[] = [
        {
          id: '1',
          orderNumber: 'INV/2024/001',
          customerName: 'John Doe',
          customerPhone: '+62812345678',
          customerAddress: 'Jakarta, Indonesia',
          items: [
            { productId: '1', quantity: 1, price: 15000000 }
          ],
          totalAmount: 15000000,
          status: 'pending',
          platform,
          createdAt: new Date().toISOString()
        }
      ]
      
      return mockOrders
    } catch (err) {
      setError('Failed to sync orders')
      return []
    } finally {
      setIsLoading(false)
    }
  }, [])

  return {
    syncProducts,
    syncOrders,
    isLoading,
    error
  }
}