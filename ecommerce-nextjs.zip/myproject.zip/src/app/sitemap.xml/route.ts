import { NextResponse } from 'next/server'

export async function GET() {
  const baseUrl = 'https://shophub.com'
  
  const staticPages = [
    '',
    '/auth/signin',
    '/auth/signup',
    '/produk',
    '/keranjang',
    '/checkout',
    '/buat-toko',
    '/unauthorized'
  ]

  const adminPages = [
    '/admin/dashboard',
    '/admin/products',
    '/admin/orders',
    '/admin/customers',
    '/admin/settings'
  ]

  const sellerPages = [
    '/seller/dashboard'
  ]

  const productPages = [
    '/produk/laptop-premium-x1',
    '/produk/smartphone-pro-5g',
    '/produk/headphone-wless',
    '/produk/smartwatch-series',
    '/produk/tablet-pro-12',
    '/produk/camera-4k-professional',
    '/produk/gaming-keyboard',
    '/produk/monitor-4k-ultra',
    '/produk/speaker-bluetooth',
    '/produk/powerbank-20000mah'
  ]

  const allPages = [
    ...staticPages.map(page => ({
      url: `${baseUrl}${page}`,
      lastModified: new Date().toISOString(),
      changeFrequency: 'daily' as const,
      priority: page === '' ? 1.0 : 0.8
    })),
    ...adminPages.map(page => ({
      url: `${baseUrl}${page}`,
      lastModified: new Date().toISOString(),
      changeFrequency: 'weekly' as const,
      priority: 0.7
    })),
    ...sellerPages.map(page => ({
      url: `${baseUrl}${page}`,
      lastModified: new Date().toISOString(),
      changeFrequency: 'weekly' as const,
      priority: 0.7
    })),
    ...productPages.map(page => ({
      url: `${baseUrl}${page}`,
      lastModified: new Date().toISOString(),
      changeFrequency: 'weekly' as const,
      priority: 0.6
    }))
  ]

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${allPages.map(page => `  <url>
    <loc>${page.url}</loc>
    <lastmod>${page.lastModified}</lastmod>
    <changefreq>${page.changeFrequency}</changefreq>
    <priority>${page.priority}</priority>
  </url>`).join('\n')}
</urlset>`

  return new NextResponse(sitemap, {
    status: 200,
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600, s-maxage=3600'
    }
  })
}