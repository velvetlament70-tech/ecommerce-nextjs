import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    if (session.user.role !== "SELLER") {
      return NextResponse.json(
        { error: "Only sellers can create stores" },
        { status: 403 }
      )
    }

    const storeData = await request.json()

    // Check if user already has a store
    const existingStore = await db.store.findUnique({
      where: { ownerId: session.user.id }
    })

    if (existingStore) {
      return NextResponse.json(
        { error: "You already have a store" },
        { status: 400 }
      )
    }

    // Check if slug is already taken
    const existingSlug = await db.store.findUnique({
      where: { slug: storeData.slug }
    })

    if (existingSlug) {
      return NextResponse.json(
        { error: "Store name is already taken" },
        { status: 400 }
      )
    }

    // Create store
    const store = await db.store.create({
      data: {
        name: storeData.name,
        slug: storeData.slug,
        description: storeData.description,
        email: storeData.email,
        phone: storeData.phone,
        address: storeData.address,
        website: storeData.website,
        instagram: storeData.instagram,
        facebook: storeData.facebook,
        twitter: storeData.twitter,
        ownerId: session.user.id
      }
    })

    return NextResponse.json({
      message: "Store created successfully",
      store
    })

  } catch (error) {
    console.error("Store creation error:", error)
    return NextResponse.json(
      { error: "Failed to create store" },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const slug = searchParams.get("slug")
    const ownerId = searchParams.get("ownerId")

    if (slug) {
      // Get store by slug
      const store = await db.store.findUnique({
        where: { slug },
        include: {
          owner: {
            select: {
              id: true,
              name: true,
              email: true
            }
          },
          _count: {
            select: {
              products: true
            }
          }
        }
      })

      if (!store) {
        return NextResponse.json(
          { error: "Store not found" },
          { status: 404 }
        )
      }

      return NextResponse.json(store)
    }

    if (ownerId) {
      // Get store by owner
      const store = await db.store.findUnique({
        where: { ownerId },
        include: {
          _count: {
            select: {
              products: true,
              orders: true
            }
          }
        }
      })

      return NextResponse.json(store)
    }

    // Get all stores (for admin)
    const session = await getServerSession(authOptions)
    
    if (!session || session.user.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    const stores = await db.store.findMany({
      include: {
        owner: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        _count: {
          select: {
            products: true,
            orders: true
          }
        }
      },
      orderBy: {
        createdAt: "desc"
      }
    })

    return NextResponse.json(stores)

  } catch (error) {
    console.error("Store fetch error:", error)
    return NextResponse.json(
      { error: "Failed to fetch stores" },
      { status: 500 }
    )
  }
}