import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const { productId, productName, category } = await request.json();

    if (!productId && !productName) {
      return NextResponse.json(
        { error: 'Product ID or name is required' },
        { status: 400 }
      );
    }

    // Get current product details if not provided
    let currentProduct = null;
    if (productName) {
      currentProduct = { name: productName, categoryId: category };
    } else {
      currentProduct = await db.product.findUnique({
        where: { id: productId },
        select: { name: true, categoryId: true }
      });
    }

    if (!currentProduct) {
      return NextResponse.json(
        { error: 'Product not found' },
        { status: 404 }
      );
    }

    // Get all products except the current one
    const allProducts = await db.product.findMany({
      where: {
        id: productId ? { not: productId } : undefined,
        name: productName ? { not: productName } : undefined
      },
      select: {
        id: true,
        name: true,
        price: true,
        images: true,
        categoryId: true,
        description: true
      }
    });

    if (allProducts.length === 0) {
      return NextResponse.json({
        success: true,
        recommendations: []
      });
    }

    // Use AI to find similar products
    const zai = await ZAI.create();

    const productsText = allProducts.map(p => {
      let images = [];
      try {
        images = JSON.parse(p.images || '[]');
      } catch (e) {
        images = [];
      }
      const firstImage = images.length > 0 ? images[0] : 'https://via.placeholder.com/400x400?text=No+Image';
      
      return `ID: ${p.id}, Nama: ${p.name}, Kategori: ${p.categoryId}, Harga: ${p.price}, Deskripsi: ${p.description?.substring(0, 100) || ''}, Gambar: ${firstImage}`;
    }).join('\n');

    const prompt = `Diberikan produk saat ini:
Nama: ${currentProduct.name}
Kategori: ${currentProduct.categoryId}

Dan daftar produk lainnya:
${productsText}

Analisis dan pilih 5 produk yang paling mirip atau relevan dengan produk saat ini berdasarkan:
1. Kategori yang sama
2. Kisaran harga yang serupa
3. Fungsi atau kegunaan yang mirip
4. Target pasar yang sama

Kembalikan hanya ID produk yang dipisahkan dengan koma, tanpa teks tambahan.`;

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an AI assistant specialized in product recommendation analysis. Always return only comma-separated product IDs.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.3,
      max_tokens: 100,
    });

    const recommendedIds = completion.choices[0]?.message?.content
      ?.split(',')
      .map(id => id.trim())
      .filter(id => id) || [];

    // Get recommended products details
    const recommendations = await db.product.findMany({
      where: {
        id: { in: recommendedIds }
      },
      select: {
        id: true,
        name: true,
        price: true,
        images: true,
        categoryId: true,
        description: true
      }
    });

    // If AI doesn't return valid recommendations, fallback to category-based
    if (recommendations.length === 0 && currentProduct.categoryId) {
      const fallbackRecommendations = await db.product.findMany({
        where: {
          categoryId: currentProduct.categoryId,
          id: productId ? { not: productId } : undefined,
          name: productName ? { not: productName } : undefined
        },
        take: 5,
        select: {
          id: true,
          name: true,
          price: true,
          images: true,
          categoryId: true,
          description: true
        }
      });
      
      const formattedFallback = fallbackRecommendations.map(product => {
        let images = [];
        try {
          images = JSON.parse(product.images || '[]');
        } catch (e) {
          images = [];
        }
        const firstImage = images.length > 0 ? images[0] : 'https://via.placeholder.com/400x400?text=No+Image';
        
        return {
          ...product,
          image: firstImage,
          category: product.categoryId
        };
      });
      
      return NextResponse.json({
        success: true,
        recommendations: formattedFallback
      });
    }

    return NextResponse.json({
      success: true,
      recommendations: recommendations.slice(0, 5).map(product => {
        let images = [];
        try {
          images = JSON.parse(product.images || '[]');
        } catch (e) {
          images = [];
        }
        const firstImage = images.length > 0 ? images[0] : 'https://via.placeholder.com/400x400?text=No+Image';
        
        return {
          ...product,
          image: firstImage,
          category: product.categoryId
        };
      })
    });

  } catch (error: any) {
    console.error('Error getting recommendations:', error);
    
    // Fallback to simple category-based recommendations
    try {
      const { category } = await request.json();
      if (category) {
        const fallbackRecommendations = await db.product.findMany({
          where: {
            categoryId: category,
            ...(productId && { id: { not: productId } }),
            ...(productName && { name: { not: productName } })
          },
          take: 5,
          select: {
            id: true,
            name: true,
            price: true,
            images: true,
            categoryId: true,
            description: true
          }
        });
        
        const formattedFallback = fallbackRecommendations.map(product => {
          let images = [];
          try {
            images = JSON.parse(product.images || '[]');
          } catch (e) {
            images = [];
          }
          const firstImage = images.length > 0 ? images[0] : 'https://via.placeholder.com/400x400?text=No+Image';
          
          return {
            ...product,
            image: firstImage,
            category: product.categoryId
          };
        });
        
        return NextResponse.json({
          success: true,
          recommendations: formattedFallback
        });
      }
    } catch (fallbackError) {
      console.error('Fallback also failed:', fallbackError);
    }

    return NextResponse.json(
      { 
        error: 'Failed to get product recommendations',
        details: error.message 
      },
      { status: 500 }
    );
  }
}