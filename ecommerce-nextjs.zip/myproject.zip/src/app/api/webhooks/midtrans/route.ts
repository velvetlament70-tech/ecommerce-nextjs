import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import crypto from 'crypto';

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const signature = request.headers.get('x-signature-key');
    
    // Verify webhook signature (in real implementation)
    const isValidSignature = verifyMidtransSignature(body, signature);
    
    if (!isValidSignature) {
      return NextResponse.json(
        { error: 'Invalid signature' },
        { status: 401 }
      );
    }

    const notification = JSON.parse(body);
    
    // Handle different notification types
    switch (notification.transaction_status) {
      case 'capture':
      case 'settlement':
        await handleSuccessfulPayment(notification);
        break;
      case 'pending':
        await handlePendingPayment(notification);
        break;
      case 'deny':
      case 'cancel':
      case 'expire':
        await handleFailedPayment(notification);
        break;
      case 'refund':
        await handleRefund(notification);
        break;
    }

    return NextResponse.json({ success: true });

  } catch (error: any) {
    console.error('Midtrans webhook error:', error);
    return NextResponse.json(
      { error: 'Webhook processing failed' },
      { status: 500 }
    );
  }
}

function verifyMidtransSignature(body: string, signature: string): boolean {
  // In real implementation, verify with Midtrans server key
  const serverKey = process.env.MIDTRANS_SERVER_KEY || 'mock-server-key';
  const expectedSignature = crypto
    .createHash('sha512')
    .update(`${body}${serverKey}`)
    .digest('hex');
  
  return signature === expectedSignature;
}

async function handleSuccessfulPayment(notification: any) {
  const orderId = notification.order_id;
  const transactionId = notification.transaction_id;
  const grossAmount = notification.gross_amount;

  // Find transaction by external ID
  const transaction = await db.transaction.findFirst({
    where: {
      externalId: transactionId,
      paymentGateway: 'midtrans'
    },
    include: {
      order: true
    }
  });

  if (!transaction) {
    console.error('Transaction not found for Midtrans notification:', transactionId);
    return;
  }

  // Update transaction status
  await db.transaction.update({
    where: { id: transaction.id },
    data: {
      status: 'SUCCESS',
      processedAt: new Date(),
      paymentDetails: JSON.stringify(notification)
    }
  });

  // Update order status
  await db.order.update({
    where: { id: transaction.orderId },
    data: {
      paymentStatus: 'PAID',
      status: 'CONFIRMED',
      paidAt: new Date()
    }
  });

  console.log(`Payment successful for order ${orderId}`);
}

async function handlePendingPayment(notification: any) {
  const transactionId = notification.transaction_id;

  const transaction = await db.transaction.findFirst({
    where: {
      externalId: transactionId,
      paymentGateway: 'midtrans'
    }
  });

  if (transaction) {
    await db.transaction.update({
      where: { id: transaction.id },
      data: {
        status: 'PENDING',
        paymentDetails: JSON.stringify(notification)
      }
    });
  }
}

async function handleFailedPayment(notification: any) {
  const transactionId = notification.transaction_id;

  const transaction = await db.transaction.findFirst({
    where: {
      externalId: transactionId,
      paymentGateway: 'midtrans'
    },
    include: {
      order: true
    }
  });

  if (transaction) {
    await db.transaction.update({
      where: { id: transaction.id },
      data: {
        status: 'FAILED',
        failureReason: notification.transaction_status,
        paymentDetails: JSON.stringify(notification)
      }
    });

    await db.order.update({
      where: { id: transaction.orderId },
      data: {
        paymentStatus: 'FAILED'
      }
    });
  }
}

async function handleRefund(notification: any) {
  const transactionId = notification.transaction_id;

  const transaction = await db.transaction.findFirst({
    where: {
      externalId: transactionId,
      paymentGateway: 'midtrans'
    },
    include: {
      order: true
    }
  });

  if (transaction) {
    await db.transaction.update({
      where: { id: transaction.id },
      data: {
        status: 'REFUNDED',
        paymentDetails: JSON.stringify(notification)
      }
    });

    await db.order.update({
      where: { id: transaction.orderId },
      data: {
        paymentStatus: 'REFUNDED',
        status: 'REFUNDED'
      }
    });
  }
}