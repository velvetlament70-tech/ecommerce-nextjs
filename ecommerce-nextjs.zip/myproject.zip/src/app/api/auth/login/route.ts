import { NextRequest, NextResponse } from "next/server"
import { JWTManager } from "@/lib/jwt-manager"
import { db } from "@/lib/db"
import { UserRole } from "@prisma/client"

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    // Validate input
    if (!email || !password) {
      return NextResponse.json(
        { error: "Email and password are required" },
        { status: 400 }
      )
    }

    // Find user in database
    const user = await db.user.findUnique({
      where: { email },
      include: {
        store: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    if (!user) {
      return NextResponse.json(
        { error: "Invalid email or password" },
        { status: 401 }
      )
    }

    // For demo purposes, accept any password
    // In production, you would hash and verify the password
    const isValidPassword = password === "password123" || password.length >= 6

    if (!isValidPassword) {
      return NextResponse.json(
        { error: "Invalid email or password" },
        { status: 401 }
      )
    }

    // Generate JWT token
    const token = JWTManager.generateToken({
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      storeId: user.store?.id,
      storeName: user.store?.name
    })

    // Prepare user data for response
    const userData = {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      storeId: user.store?.id,
      storeName: user.store?.name
    }

    return NextResponse.json({
      message: "Login successful",
      user: userData,
      token
    })

  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}