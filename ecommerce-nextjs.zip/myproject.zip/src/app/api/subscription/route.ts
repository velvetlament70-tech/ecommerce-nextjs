import { NextRequest, NextResponse } from 'next/server'
import { headers } from 'next/headers'
import Stripe from 'stripe'
import { db } from '@/lib/db'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
})

export async function POST(request: NextRequest) {
  try {
    const { planId, userId } = await request.json()

    if (!planId || !userId) {
      return NextResponse.json(
        { error: 'Plan ID and User ID are required' },
        { status: 400 }
      )
    }

    // Get user from database
    const user = await db.user.findUnique({
      where: { id: userId },
      include: { subscription: true }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Define subscription plans
    const plans = {
      starter: {
        name: 'Starter',
        price: 9.99,
        interval: 'month',
        features: ['Up to 100 products', 'Basic analytics', 'Email support']
      },
      professional: {
        name: 'Professional',
        price: 29.99,
        interval: 'month',
        features: ['Up to 1000 products', 'Advanced analytics', 'Priority support', 'Custom themes']
      },
      enterprise: {
        name: 'Enterprise',
        price: 99.99,
        interval: 'month',
        features: ['Unlimited products', 'Full analytics', '24/7 support', 'White label', 'API access']
      }
    }

    const plan = plans[planId as keyof typeof plans]
    if (!plan) {
      return NextResponse.json(
        { error: 'Invalid plan' },
        { status: 400 }
      )
    }

    // Create or get Stripe customer
    let customerId = user.email // In production, store stripeCustomerId in user model

    // Create Stripe checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: plan.name,
              description: plan.features.join(', '),
            },
            unit_amount: Math.round(plan.price * 100),
            recurring: {
              interval: plan.interval as Stripe.Price.Recurring.Interval,
            },
          },
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/subscription/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/subscription/cancel`,
      metadata: {
        userId,
        planId,
      },
    })

    // Create subscription record in database
    const subscription = await db.subscription.upsert({
      where: { userId },
      update: {
        plan: planId.toUpperCase() as any,
        status: 'PENDING',
        startDate: new Date(),
        stripeSubscriptionId: session.id,
      },
      create: {
        userId,
        plan: planId.toUpperCase() as any,
        status: 'PENDING',
        startDate: new Date(),
        stripeSubscriptionId: session.id,
      },
    })

    return NextResponse.json({
      sessionId: session.id,
      url: session.url,
      subscription,
    })
  } catch (error) {
    console.error('Subscription creation error:', error)
    return NextResponse.json(
      { error: 'Failed to create subscription' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const subscription = await db.subscription.findUnique({
      where: { userId },
      include: { user: true }
    })

    return NextResponse.json({ subscription })
  } catch (error) {
    console.error('Get subscription error:', error)
    return NextResponse.json(
      { error: 'Failed to get subscription' },
      { status: 500 }
    )
  }
}