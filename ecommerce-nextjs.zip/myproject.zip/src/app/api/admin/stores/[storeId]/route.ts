import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function PATCH(
  request: NextRequest,
  { params }: { params: { storeId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || session.user.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      )
    }

    const { isActive, isVerified } = await request.json()
    const storeId = params.storeId

    // Build update data object
    const updateData: any = {}
    if (typeof isActive === "boolean") {
      updateData.isActive = isActive
    }
    if (typeof isVerified === "boolean") {
      updateData.isVerified = isVerified
    }

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json(
        { error: "No valid fields to update" },
        { status: 400 }
      )
    }

    // Update store
    const store = await db.store.update({
      where: { id: storeId },
      data: updateData
    })

    return NextResponse.json({
      message: "Store updated successfully",
      store
    })

  } catch (error) {
    console.error("Store update error:", error)
    return NextResponse.json(
      { error: "Failed to update store" },
      { status: 500 }
    )
  }
}