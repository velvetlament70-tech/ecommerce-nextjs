import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const { productName, category } = await request.json();

    if (!productName) {
      return NextResponse.json(
        { error: 'Product name is required' },
        { status: 400 }
      );
    }

    const zai = await ZAI.create();

    const prompt = `Buatkan deskripsi produk yang menarik dan profesional untuk produk dengan nama "${productName}"${category ? ` dalam kategori ${category}` : ''}. 

Deskripsi harus:
1. Singkat namun informatif (2-3 paragraf)
2. Menonjolkan fitur dan keunggulan utama
3. Menggunakan bahasa yang persuasif
4. SEO friendly dengan keyword yang relevan
5. Format dalam bahasa Indonesia yang baik dan benar

Berikan hanya deskripsi produk tanpa tambahan teks lain.`;

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a professional copywriter specializing in e-commerce product descriptions. Always create compelling, SEO-friendly product descriptions in Indonesian.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 500,
    });

    const description = completion.choices[0]?.message?.content;

    if (!description) {
      throw new Error('Failed to generate description');
    }

    return NextResponse.json({
      success: true,
      description: description.trim()
    });

  } catch (error: any) {
    console.error('Error generating description:', error);
    return NextResponse.json(
      { 
        error: 'Failed to generate product description',
        details: error.message 
      },
      { status: 500 }
    );
  }
}