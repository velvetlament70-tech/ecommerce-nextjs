import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const transactionId = searchParams.get('transactionId');
    const orderId = searchParams.get('orderId');

    if (!transactionId && !orderId) {
      return NextResponse.json(
        { error: 'Transaction ID or Order ID is required' },
        { status: 400 }
      );
    }

    // Get transaction details
    let transaction;
    if (transactionId) {
      transaction = await db.transaction.findUnique({
        where: { id: transactionId },
        include: {
          order: {
            include: {
              items: true
            }
          }
        }
      });
    } else if (orderId) {
      transaction = await db.transaction.findFirst({
        where: { orderId },
        include: {
          order: {
            include: {
              items: true
            }
          }
        },
        orderBy: { createdAt: 'desc' }
      });
    }

    if (!transaction) {
      return NextResponse.json(
        { error: 'Transaction not found' },
        { status: 404 }
      );
    }

    // Check with payment gateway for real-time status
    const gatewayStatus = await checkPaymentGatewayStatus(transaction);
    
    // Update transaction status if changed
    if (gatewayStatus.status !== transaction.status) {
      await db.transaction.update({
        where: { id: transaction.id },
        data: {
          status: gatewayStatus.status,
          paymentDetails: JSON.stringify(gatewayStatus.details),
          processedAt: gatewayStatus.status === 'SUCCESS' ? new Date() : null,
          failureReason: gatewayStatus.failureReason
        }
      });

      // Update order payment status if payment is successful
      if (gatewayStatus.status === 'SUCCESS') {
        await db.order.update({
          where: { id: transaction.orderId },
          data: {
            paymentStatus: 'PAID',
            status: 'CONFIRMED',
            paidAt: new Date()
          }
        });
      } else if (gatewayStatus.status === 'FAILED') {
        await db.order.update({
          where: { id: transaction.orderId },
          data: {
            paymentStatus: 'FAILED'
          }
        });
      }
    }

    // Get updated transaction
    const updatedTransaction = await db.transaction.findUnique({
      where: { id: transaction.id },
      include: {
        order: {
          include: {
            items: true
          }
        }
      }
    });

    return NextResponse.json({
      success: true,
      transaction: updatedTransaction
    });

  } catch (error: any) {
    console.error('Payment status check error:', error);
    return NextResponse.json(
      { 
        error: 'Failed to check payment status',
        details: error.message 
      },
      { status: 500 }
    );
  }
}

// Mock payment gateway status check
async function checkPaymentGatewayStatus(transaction: any) {
  // In real implementation, this would call the respective payment gateway APIs
  
  // Simulate random payment status for demo purposes
  const randomStatus = Math.random();
  let status = 'PENDING';
  let failureReason = null;
  
  if (randomStatus > 0.7) {
    status = 'SUCCESS';
  } else if (randomStatus > 0.5) {
    status = 'FAILED';
    failureReason = 'Payment declined by bank';
  } else if (randomStatus > 0.3) {
    status = 'EXPIRED';
    failureReason = 'Payment expired';
  }

  const mockResponse = {
    status,
    failureReason,
    details: {
      external_id: transaction.externalId,
      payment_gateway: transaction.paymentGateway,
      payment_method: transaction.paymentMethod,
      amount: transaction.amount,
      updated_at: new Date().toISOString(),
      ...(status === 'SUCCESS' && {
        paid_at: new Date().toISOString(),
        payment_channel: 'MOBILE_BANKING'
      })
    }
  };

  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return mockResponse;
}