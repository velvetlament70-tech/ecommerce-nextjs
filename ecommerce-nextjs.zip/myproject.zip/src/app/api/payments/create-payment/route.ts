import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Mock payment gateway configurations
const PAYMENT_GATEWAYS = {
  midtrans: {
    name: 'Midtrans',
    serverKey: process.env.MIDTRANS_SERVER_KEY || 'mock-server-key',
    clientKey: process.env.MIDTRANS_CLIENT_KEY || 'mock-client-key',
    apiUrl: process.env.MIDTRANS_API_URL || 'https://api.sandbox.midtrans.com/v2',
    enabled: true
  },
  xendit: {
    name: 'Xendit',
    secretKey: process.env.XENDIT_SECRET_KEY || 'mock-secret-key',
    apiUrl: process.env.XENDIT_API_URL || 'https://api.xendit.co',
    enabled: true
  },
  stripe: {
    name: 'Stripe',
    secretKey: process.env.STRIPE_SECRET_KEY || 'sk_test_mock_key',
    publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || 'pk_test_mock_key',
    apiUrl: 'https://api.stripe.com/v1',
    enabled: true
  }
};

export async function POST(request: NextRequest) {
  try {
    const { orderId, paymentMethod, paymentGateway, amount, customerDetails } = await request.json();

    if (!orderId || !paymentMethod || !paymentGateway || !amount) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Get order details
    const order = await db.order.findUnique({
      where: { id: orderId },
      include: {
        items: true
      }
    });

    if (!order) {
      return NextResponse.json(
        { error: 'Order not found' },
        { status: 404 }
      );
    }

    // Check if payment gateway is enabled
    const gateway = PAYMENT_GATEWAYS[paymentGateway as keyof typeof PAYMENT_GATEWAYS];
    if (!gateway || !gateway.enabled) {
      return NextResponse.json(
        { error: 'Payment gateway not available' },
        { status: 400 }
      );
    }

    // Create transaction record
    const transactionNumber = `TRX-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    
    const transaction = await db.transaction.create({
      data: {
        orderId,
        transactionNumber,
        amount,
        paymentMethod,
        paymentGateway,
        status: 'PENDING',
        externalId: null,
        paymentUrl: null,
        paymentDetails: null
      }
    });

    // Process payment based on gateway
    let paymentResponse;
    
    switch (paymentGateway) {
      case 'midtrans':
        paymentResponse = await createMidtransPayment(order, transaction, customerDetails);
        break;
      case 'xendit':
        paymentResponse = await createXenditPayment(order, transaction, customerDetails);
        break;
      case 'stripe':
        paymentResponse = await createStripePayment(order, transaction, customerDetails);
        break;
      default:
        return NextResponse.json(
          { error: 'Unsupported payment gateway' },
          { status: 400 }
        );
    }

    // Update transaction with payment details
    await db.transaction.update({
      where: { id: transaction.id },
      data: {
        externalId: paymentResponse.externalId,
        paymentUrl: paymentResponse.paymentUrl,
        paymentDetails: JSON.stringify(paymentResponse.details)
      }
    });

    // Update order with payment gateway info
    await db.order.update({
      where: { id: orderId },
      data: {
        paymentGateway,
        paymentMethod,
        externalPaymentId: paymentResponse.externalId,
        paymentDetails: JSON.stringify(paymentResponse.details),
        expiredAt: paymentResponse.expiredAt
      }
    });

    return NextResponse.json({
      success: true,
      transaction: {
        id: transaction.id,
        transactionNumber,
        paymentUrl: paymentResponse.paymentUrl,
        expiredAt: paymentResponse.expiredAt,
        paymentMethod,
        paymentGateway
      }
    });

  } catch (error: any) {
    console.error('Payment creation error:', error);
    return NextResponse.json(
      { 
        error: 'Failed to create payment',
        details: error.message 
      },
      { status: 500 }
    );
  }
}

// Mock Midtrans payment implementation
async function createMidtransPayment(order: any, transaction: any, customerDetails: any) {
  // In real implementation, this would call Midtrans API
  const mockResponse = {
    externalId: `midtrans-${transaction.id}`,
    paymentUrl: `https://app.sandbox.midtrans.com/payment/${transaction.id}`,
    expiredAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
    details: {
      transaction_id: transaction.id,
      order_id: order.orderNumber,
      gross_amount: order.total,
      payment_type: transaction.paymentMethod.toLowerCase(),
      customer_details: {
        first_name: customerDetails?.firstName || order.shippingName.split(' ')[0],
        last_name: customerDetails?.lastName || order.shippingName.split(' ').slice(1).join(' '),
        email: order.shippingEmail,
        phone: order.shippingPhone
      },
      item_details: order.items.map((item: any) => ({
        id: item.id,
        price: item.price,
        quantity: item.quantity,
        name: item.productName
      }))
    }
  };

  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  return mockResponse;
}

// Mock Xendit payment implementation
async function createXenditPayment(order: any, transaction: any, customerDetails: any) {
  // In real implementation, this would call Xendit API
  const mockResponse = {
    externalId: `xendit-${transaction.id}`,
    paymentUrl: `https://checkout.xendit.co/web/${transaction.id}`,
    expiredAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
    details: {
      id: transaction.id,
      external_id: `order-${order.orderNumber}`,
      amount: order.total,
      payment_method: transaction.paymentMethod.toLowerCase(),
      status: 'PENDING',
      payer_email: order.shippingEmail,
      description: `Payment for order ${order.orderNumber}`,
      created: new Date().toISOString()
    }
  };

  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  return mockResponse;
}

// Mock Stripe payment implementation
async function createStripePayment(order: any, transaction: any, customerDetails: any) {
  // In real implementation, this would call Stripe API
  const mockResponse = {
    externalId: `stripe-${transaction.id}`,
    paymentUrl: `https://checkout.stripe.com/pay/${transaction.id}`,
    expiredAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
    details: {
      payment_intent_id: `pi_${transaction.id}`,
      checkout_session_id: `cs_${transaction.id}`,
      amount: order.total * 100, // Stripe uses cents
      currency: 'idr',
      payment_method_types: [transaction.paymentMethod.toLowerCase()],
      customer_email: order.shippingEmail,
      metadata: {
        order_id: order.id,
        order_number: order.orderNumber
      }
    }
  };

  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1200));
  
  return mockResponse;
}