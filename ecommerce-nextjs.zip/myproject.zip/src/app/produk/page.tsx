'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Checkbox } from '@/components/ui/checkbox'
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { 
  Search, 
  ShoppingCart, 
  Heart, 
  SlidersHorizontal,
  Star,
  Filter,
  Grid,
  List,
  ChevronDown
} from 'lucide-react'
import { useCart } from '@/hooks/use-cart'

// Mock data for demonstration
const allProducts = [
  {
    id: '1',
    name: 'Laptop Gaming Pro Max',
    price: 15999000,
    comparePrice: 18999000,
    image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=300&fit=crop',
    rating: 4.5,
    reviews: 128,
    slug: 'laptop-gaming-pro-max',
    category: 'Elektronik',
    badge: 'Best Seller'
  },
  {
    id: '2', 
    name: 'Smartphone Premium 5G',
    price: 8999000,
    comparePrice: 10999000,
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=300&fit=crop',
    rating: 4.8,
    reviews: 89,
    slug: 'smartphone-premium-5g',
    category: 'Elektronik',
    badge: 'Hot Deal'
  },
  {
    id: '3',
    name: 'Wireless Headphone Pro',
    price: 2499000,
    comparePrice: 2999000,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=300&fit=crop',
    rating: 4.6,
    reviews: 203,
    slug: 'wireless-headphone-pro',
    category: 'Elektronik'
  },
  {
    id: '4',
    name: 'Smart Watch Ultra',
    price: 4999000,
    comparePrice: 5999000,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=300&fit=crop',
    rating: 4.7,
    reviews: 156,
    slug: 'smart-watch-ultra',
    category: 'Elektronik',
    badge: 'New'
  },
  {
    id: '5',
    name: 'Kemeja Pria Premium',
    price: 299000,
    comparePrice: 399000,
    image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&h=300&fit=crop',
    rating: 4.3,
    reviews: 67,
    slug: 'kemeja-pria-premium',
    category: 'Fashion Pria'
  },
  {
    id: '6',
    name: 'Sepatu Running Professional',
    price: 1299000,
    comparePrice: 1599000,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=300&fit=crop',
    rating: 4.6,
    reviews: 234,
    slug: 'sepatu-running-professional',
    category: 'Olahraga'
  },
  {
    id: '7',
    name: 'Tas Wanita Elegant',
    price: 899000,
    comparePrice: 1199000,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=300&fit=crop',
    rating: 4.4,
    reviews: 145,
    slug: 'tas-wanita-elegant',
    category: 'Fashion Wanita'
  },
  {
    id: '8',
    name: 'Vitamin C Premium',
    price: 149000,
    comparePrice: 199000,
    image: 'https://images.unsplash.com/photo-1594026112284-02bb6fb3d543?w=400&h=300&fit=crop',
    rating: 4.7,
    reviews: 89,
    slug: 'vitamin-c-premium',
    category: 'Kesehatan'
  }
]

const categories = [
  'Semua',
  'Elektronik',
  'Fashion Pria',
  'Fashion Wanita',
  'Kesehatan',
  'Olahraga',
  'Rumah Tangga'
]

const sortOptions = [
  { value: 'featured', label: 'Unggulan' },
  { value: 'price-low', label: 'Harga Terendah' },
  { value: 'price-high', label: 'Harga Tertinggi' },
  { value: 'rating', label: 'Rating Tertinggi' },
  { value: 'newest', label: 'Terbaru' },
  { value: 'discount', label: 'Diskon Terbesar' }
]

export default function ProductsPage() {
  const { addItem } = useCart()
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('Semua')
  const [sortBy, setSortBy] = useState('featured')
  const [priceRange, setPriceRange] = useState([0, 20000000])
  const [selectedRatings, setSelectedRatings] = useState<number[]>([])
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [currentPage, setCurrentPage] = useState(1)
  const [isFilterOpen, setIsFilterOpen] = useState(false)

  const itemsPerPage = 12

  // Filter products
  const filteredProducts = allProducts.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'Semua' || product.category === selectedCategory
    const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1]
    const matchesRating = selectedRatings.length === 0 || selectedRatings.includes(Math.floor(product.rating))
    
    return matchesSearch && matchesCategory && matchesPrice && matchesRating
  })

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'price-low':
        return a.price - b.price
      case 'price-high':
        return b.price - a.price
      case 'rating':
        return b.rating - a.rating
      case 'newest':
        return b.id.localeCompare(a.id)
      case 'discount':
        const discountA = a.comparePrice ? ((a.comparePrice - a.price) / a.comparePrice) * 100 : 0
        const discountB = b.comparePrice ? ((b.comparePrice - b.price) / b.comparePrice) * 100 : 0
        return discountB - discountA
      default:
        return 0
    }
  })

  // Pagination
  const totalPages = Math.ceil(sortedProducts.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedProducts = sortedProducts.slice(startIndex, startIndex + itemsPerPage)

  const handleAddToCart = (product: any) => {
    addItem({
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
      slug: product.slug
    })
  }

  const handleRatingChange = (rating: number, checked: boolean) => {
    if (checked) {
      setSelectedRatings([...selectedRatings, rating])
    } else {
      setSelectedRatings(selectedRatings.filter(r => r !== rating))
    }
  }

  const ProductCard = ({ product }: { product: any }) => (
    <Card className="group hover:shadow-lg transition-all duration-300 overflow-hidden">
      <div className="relative">
        <Link href={`/produk/${product.slug}`}>
          <div className="aspect-square overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          </div>
        </Link>
        {product.badge && (
          <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-600">
            {product.badge}
          </Badge>
        )}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 bg-white/80 hover:bg-white"
        >
          <Heart className="w-4 h-4" />
        </Button>
      </div>
      <CardContent className="p-4">
        <Link href={`/produk/${product.slug}`}>
          <h3 className="font-semibold text-sm mb-2 line-clamp-2 hover:text-primary transition-colors">
            {product.name}
          </h3>
        </Link>
        <div className="flex items-center gap-1 mb-2">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-3 h-3 ${
                  i < Math.floor(product.rating)
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="text-xs text-gray-500">({product.reviews})</span>
        </div>
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="text-lg font-bold text-primary">
              Rp{product.price.toLocaleString('id-ID')}
            </div>
            {product.comparePrice && (
              <div className="text-sm text-gray-500 line-through">
                Rp{product.comparePrice.toLocaleString('id-ID')}
              </div>
            )}
          </div>
        </div>
        <Button
          onClick={() => handleAddToCart(product)}
          className="w-full"
          size="sm"
        >
          <ShoppingCart className="w-4 h-4 mr-2" />
          Tambah ke Keranjang
        </Button>
      </CardContent>
    </Card>
  )

  const ProductListItem = ({ product }: { product: any }) => (
    <Card className="hover:shadow-lg transition-all duration-300">
      <CardContent className="p-4">
        <div className="flex gap-4">
          <div className="relative w-32 h-32 flex-shrink-0">
            <Link href={`/produk/${product.slug}`}>
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover rounded-lg"
              />
            </Link>
            {product.badge && (
              <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-600">
                {product.badge}
              </Badge>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <Link href={`/produk/${product.slug}`}>
              <h3 className="font-semibold text-lg mb-2 hover:text-primary transition-colors">
                {product.name}
              </h3>
            </Link>
            <div className="flex items-center gap-1 mb-2">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.floor(product.rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-500">({product.reviews} ulasan)</span>
            </div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-xl font-bold text-primary">
                  Rp{product.price.toLocaleString('id-ID')}
                </div>
                {product.comparePrice && (
                  <div className="text-sm text-gray-500 line-through">
                    Rp{product.comparePrice.toLocaleString('id-ID')}
                  </div>
                )}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="icon">
                  <Heart className="w-4 h-4" />
                </Button>
                <Button onClick={() => handleAddToCart(product)}>
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Tambah
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Semua Produk</h1>
        <p className="text-gray-600">Temukan produk yang Anda butuhkan dari berbagai kategori</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filters Sidebar */}
        <aside className="w-full lg:w-64 flex-shrink-0">
          {/* Mobile Filter Button */}
          <div className="lg:hidden mb-4">
            <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" className="w-full">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80">
                <div className="mt-8 space-y-6">
                  {/* Filter content here */}
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Desktop Filters */}
          <div className="hidden lg:block space-y-6">
            {/* Search */}
            <div>
              <h3 className="font-semibold mb-3">Cari Produk</h3>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Cari produk..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Categories */}
            <div>
              <h3 className="font-semibold mb-3">Kategori</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <label key={category} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="category"
                      checked={selectedCategory === category}
                      onChange={() => setSelectedCategory(category)}
                      className="text-primary"
                    />
                    <span className="text-sm">{category}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div>
              <h3 className="font-semibold mb-3">Rentang Harga</h3>
              <div className="space-y-3">
                <Slider
                  value={priceRange}
                  onValueChange={setPriceRange}
                  max={20000000}
                  step={100000}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-600">
                  <span>Rp{priceRange[0].toLocaleString('id-ID')}</span>
                  <span>Rp{priceRange[1].toLocaleString('id-ID')}</span>
                </div>
              </div>
            </div>

            {/* Rating */}
            <div>
              <h3 className="font-semibold mb-3">Rating</h3>
              <div className="space-y-2">
                {[5, 4, 3, 2, 1].map((rating) => (
                  <label key={rating} className="flex items-center space-x-2 cursor-pointer">
                    <Checkbox
                      checked={selectedRatings.includes(rating)}
                      onCheckedChange={(checked) => handleRatingChange(rating, checked as boolean)}
                    />
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3 h-3 ${
                            i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                          }`}
                        />
                      ))}
                      <span className="text-sm ml-1">& ke atas</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1">
          {/* Toolbar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <div className="text-sm text-gray-600">
              Menampilkan {paginatedProducts.length} dari {filteredProducts.length} produk
            </div>
            <div className="flex items-center gap-4">
              {/* View Mode */}
              <div className="flex border rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>

              {/* Sort */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Urutkan" />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Products Grid/List */}
          {paginatedProducts.length > 0 ? (
            <div className={viewMode === 'grid' 
              ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6' 
              : 'space-y-4'
            }>
              {paginatedProducts.map((product) => (
                viewMode === 'grid' ? (
                  <ProductCard key={product.id} product={product} />
                ) : (
                  <ProductListItem key={product.id} product={product} />
                )
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="text-gray-500 mb-4">
                <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">Tidak ada produk ditemukan</h3>
                <p>Coba ubah filter atau kata kunci pencarian Anda</p>
              </div>
              <Button
                onClick={() => {
                  setSearchTerm('')
                  setSelectedCategory('Semua')
                  setPriceRange([0, 20000000])
                  setSelectedRatings([])
                }}
                variant="outline"
              >
                Reset Filter
              </Button>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-8">
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious 
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      className={currentPage === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                  {[...Array(totalPages)].map((_, i) => (
                    <PaginationItem key={i + 1}>
                      <PaginationLink
                        onClick={() => setCurrentPage(i + 1)}
                        isActive={currentPage === i + 1}
                        className="cursor-pointer"
                      >
                        {i + 1}
                      </PaginationLink>
                    </PaginationItem>
                  ))}
                  <PaginationItem>
                    <PaginationNext 
                      onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                      className={currentPage === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}