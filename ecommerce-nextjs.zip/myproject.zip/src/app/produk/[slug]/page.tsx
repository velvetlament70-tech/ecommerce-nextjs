'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { ProductCarousel } from '@/components/product-carousel'
import { 
  ShoppingCart, 
  Heart, 
  Share2, 
  Star, 
  Truck, 
  Shield, 
  RefreshCw,
  Minus,
  Plus,
  ChevronLeft,
  ChevronRight,
  Loader2
} from 'lucide-react'
import { useCart } from '@/hooks/use-cart'

// Mock product data
const product = {
  id: '1',
  name: 'Laptop Gaming Pro Max',
  slug: 'laptop-gaming-pro-max',
  price: 15999000,
  comparePrice: 18999000,
  description: 'Laptop gaming high-end dengan performa maksimal untuk pengalaman bermain game terbaik. Dilengkapi dengan processor terbaru dan grafis card dedicated.',
  images: [
    'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=800&h=600&fit=crop'
  ],
  category: 'Elektronik',
  brand: 'GamingTech',
  sku: 'LTP-GM-001',
  rating: 4.5,
  reviews: 128,
  stock: 15,
  badge: 'Best Seller',
  specifications: {
    'Processor': 'Intel Core i9-13900HX',
    'RAM': '32GB DDR5',
    'Storage': '1TB NVMe SSD',
    'GPU': 'NVIDIA RTX 4080',
    'Display': '17.3" QHD 165Hz',
    'Battery': '90Wh',
    'Weight': '2.8kg',
    'OS': 'Windows 11 Pro'
  },
  features: [
    'RGB Keyboard with per-key lighting',
    'Advanced cooling system',
    'Thunderbolt 4 support',
    'Wi-Fi 6E connectivity',
    'HD Webcam with privacy shutter',
    'Dolby Atmos speakers'
  ]
}

const relatedProducts = [
  {
    id: '2',
    name: 'Smartphone Premium 5G',
    price: 8999000,
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=300&fit=crop',
    rating: 4.8,
    reviews: 89,
    slug: 'smartphone-premium-5g'
  },
  {
    id: '3',
    name: 'Wireless Headphone Pro',
    price: 2499000,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=300&fit=crop',
    rating: 4.6,
    reviews: 203,
    slug: 'wireless-headphone-pro'
  },
  {
    id: '4',
    name: 'Smart Watch Ultra',
    price: 4999000,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=300&fit=crop',
    rating: 4.7,
    reviews: 156,
    slug: 'smart-watch-ultra'
  }
]

const reviews = [
  {
    id: '1',
    name: 'Budi Santoso',
    rating: 5,
    date: '2 hari yang lalu',
    title: 'Laptop gaming terbaik!',
    content: 'Performa sangat memuaskan, bisa main game AAA dengan setting ultra tanpa lag. Cooling system juga bagus, tidak overheat.',
    verified: true,
    helpful: 23
  },
  {
    id: '2',
    name: 'Siti Nurhaliza',
    rating: 4,
    date: '1 minggu yang lalu',
    title: 'Bagus tapi agak berat',
    content: 'Kualitas build premium, performa oke. Cuma agak berat untuk dibawa-bawa. Overall puas dengan pembelian.',
    verified: true,
    helpful: 15
  },
  {
    id: '3',
    name: 'Ahmad Fauzi',
    rating: 5,
    date: '2 minggu yang lalu',
    title: 'Worth the money',
    content: 'Harga sebanding dengan kualitas. Recommended untuk serious gamer. Keyboard RGB-nya keren banget!',
    verified: false,
    helpful: 8
  }
]

export default function ProductDetailPage() {
  const { addItem } = useCart()
  const [selectedImage, setSelectedImage] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [selectedTab, setSelectedTab] = useState('description')
  const [recommendations, setRecommendations] = useState([])
  const [isLoadingRecommendations, setIsLoadingRecommendations] = useState(false)

  useEffect(() => {
    fetchRecommendations()
  }, [])

  const fetchRecommendations = async () => {
    setIsLoadingRecommendations(true)
    try {
      const response = await fetch('/api/recommend-products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          productId: product.id,
          productName: product.name,
          category: product.category
        }),
      })

      const data = await response.json()
      if (data.success) {
        setRecommendations(data.recommendations)
      }
    } catch (error) {
      console.error('Error fetching recommendations:', error)
      // Fallback to mock related products if API fails
      setRecommendations(relatedProducts.map(rp => ({
        id: rp.id,
        name: rp.name,
        price: rp.price,
        image: rp.image,
        category: product.category,
        rating: rp.rating,
        description: `Produk berkualitas tinggi dari kategori ${product.category}`
      })))
    } finally {
      setIsLoadingRecommendations(false)
    }
  }

  const handleAddToCart = () => {
    addItem({
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      quantity: quantity,
      slug: product.slug
    })
  }

  const handleQuantityChange = (type: 'increase' | 'decrease') => {
    if (type === 'increase') {
      setQuantity(Math.min(product.stock, quantity + 1))
    } else {
      setQuantity(Math.max(1, quantity - 1))
    }
  }

  const discountPercentage = product.comparePrice 
    ? Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100)
    : 0

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-gray-600 mb-8">
        <a href="/" className="hover:text-primary">Beranda</a>
        <span>/</span>
        <a href="/produk" className="hover:text-primary">Produk</a>
        <span>/</span>
        <a href={`/kategori/${product.category.toLowerCase().replace(' ', '-')}`} className="hover:text-primary">
          {product.category}
        </a>
        <span>/</span>
        <span className="text-gray-900">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
        {/* Product Images */}
        <div className="space-y-4">
          {/* Main Image */}
          <div className="relative aspect-square overflow-hidden rounded-lg bg-gray-100">
            <img
              src={product.images[selectedImage]}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {product.badge && (
              <Badge className="absolute top-4 left-4 bg-red-500 hover:bg-red-600">
                {product.badge}
              </Badge>
            )}
            <div className="absolute top-4 right-4 flex gap-2">
              <Button variant="ghost" size="icon" className="bg-white/80 hover:bg-white">
                <Heart className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" className="bg-white/80 hover:bg-white">
                <Share2 className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Thumbnail Images */}
          <div className="flex gap-2">
            {product.images.map((image, index) => (
              <button
                key={index}
                onClick={() => setSelectedImage(index)}
                className={`relative aspect-square w-20 overflow-hidden rounded-lg border-2 transition-all ${
                  selectedImage === index ? 'border-primary' : 'border-gray-200'
                }`}
              >
                <img
                  src={image}
                  alt={`${product.name} ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          {/* Title and Price */}
          <div>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span>Brand: {product.brand}</span>
                  <span>SKU: {product.sku}</span>
                </div>
              </div>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < Math.floor(product.rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="font-semibold">{product.rating}</span>
              <span className="text-gray-600">({product.reviews} ulasan)</span>
              <span className="text-green-600">• Stok: {product.stock}</span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-4 mb-6">
              <div className="text-3xl font-bold text-primary">
                Rp{product.price.toLocaleString('id-ID')}
              </div>
              {product.comparePrice && (
                <>
                  <div className="text-xl text-gray-500 line-through">
                    Rp{product.comparePrice.toLocaleString('id-ID')}
                  </div>
                  <Badge className="bg-green-500 hover:bg-green-600">
                    Hemat {discountPercentage}%
                  </Badge>
                </>
              )}
            </div>
          </div>

          {/* Quantity and Add to Cart */}
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <span className="font-semibold">Jumlah:</span>
              <div className="flex items-center border rounded-lg">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleQuantityChange('decrease')}
                  disabled={quantity <= 1}
                  className="rounded-r-none"
                >
                  <Minus className="w-4 h-4" />
                </Button>
                <div className="w-16 text-center font-semibold">
                  {quantity}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleQuantityChange('increase')}
                  disabled={quantity >= product.stock}
                  className="rounded-l-none"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="flex gap-4">
              <Button
                onClick={handleAddToCart}
                className="flex-1"
                size="lg"
                disabled={product.stock === 0}
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Tambah ke Keranjang
              </Button>
              <Button variant="outline" size="lg">
                <Heart className="w-5 h-5 mr-2" />
                Wishlist
              </Button>
            </div>
          </div>

          <Separator />

          {/* Features */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="flex items-center gap-3">
              <Truck className="w-5 h-5 text-primary" />
              <div>
                <div className="font-semibold text-sm">Gratis Ongkir</div>
                <div className="text-xs text-gray-600">Minimal Rp50.000</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-primary" />
              <div>
                <div className="font-semibold text-sm">Garansi 1 Tahun</div>
                <div className="text-xs text-gray-600">Service center</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <RefreshCw className="w-5 h-5 text-primary" />
              <div>
                <div className="font-semibold text-sm">30 Hari</div>
                <div className="text-xs text-gray-600">Pengembalian</div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Key Features */}
          <div>
            <h3 className="font-semibold mb-3">Fitur Utama</h3>
            <ul className="space-y-2">
              {product.features.map((feature, index) => (
                <li key={index} className="flex items-center gap-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                  {feature}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Product Details Tabs */}
      <div className="mb-12">
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="description">Deskripsi</TabsTrigger>
            <TabsTrigger value="specifications">Spesifikasi</TabsTrigger>
            <TabsTrigger value="reviews">Ulasan ({reviews.length})</TabsTrigger>
            <TabsTrigger value="shipping">Pengiriman</TabsTrigger>
          </TabsList>

          <TabsContent value="description" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <p className="text-gray-700 leading-relaxed">
                  {product.description}
                </p>
                <div className="mt-6">
                  <h4 className="font-semibold mb-3">Mengapa memilih produk ini?</h4>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <span>Performa maksimal untuk gaming dan produktivitas</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <span>Build quality premium dengan desain modern</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <span>Sistem pendingin advanced untuk performa stabil</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <span>Garansi resmi dan support teknis 24/7</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="specifications" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between py-3 border-b">
                      <span className="font-medium">{key}</span>
                      <span className="text-gray-600">{value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reviews" className="mt-6">
            <Card>
              <CardContent className="p-6">
                {/* Review Summary */}
                <div className="flex items-start gap-8 mb-8">
                  <div className="text-center">
                    <div className="text-4xl font-bold mb-2">{product.rating}</div>
                    <div className="flex items-center justify-center mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-5 h-5 ${
                            i < Math.floor(product.rating)
                              ? 'fill-yellow-400 text-yellow-400'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <div className="text-sm text-gray-600">{product.reviews} ulasan</div>
                  </div>
                  <div className="flex-1">
                    {[5, 4, 3, 2, 1].map((rating) => (
                      <div key={rating} className="flex items-center gap-3 mb-2">
                        <span className="text-sm w-8">{rating}</span>
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-yellow-400 h-2 rounded-full" 
                            style={{ 
                              width: `${rating === 5 ? 60 : rating === 4 ? 25 : rating === 3 ? 10 : rating === 2 ? 3 : 2}%` 
                            }}
                          />
                        </div>
                        <span className="text-sm text-gray-600 w-8">
                          {rating === 5 ? 60 : rating === 4 ? 25 : rating === 3 ? 10 : rating === 2 ? 3 : 2}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator className="mb-6" />

                {/* Reviews List */}
                <div className="space-y-6">
                  {reviews.map((review) => (
                    <div key={review.id} className="border-b pb-6 last:border-b-0">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center gap-3 mb-2">
                            <span className="font-semibold">{review.name}</span>
                            {review.verified && (
                              <Badge variant="secondary" className="text-xs">
                                Terverifikasi
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex items-center">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`w-4 h-4 ${
                                    i < review.rating
                                      ? 'fill-yellow-400 text-yellow-400'
                                      : 'text-gray-300'
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-sm text-gray-600">{review.date}</span>
                          </div>
                        </div>
                      </div>
                      <h4 className="font-semibold mb-2">{review.title}</h4>
                      <p className="text-gray-700 mb-3">{review.content}</p>
                      <div className="flex items-center gap-4">
                        <Button variant="ghost" size="sm" className="text-gray-600">
                          Helpful ({review.helpful})
                        </Button>
                        <Button variant="ghost" size="sm" className="text-gray-600">
                          Laporkan
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="shipping" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold mb-3">Opsi Pengiriman</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center p-3 border rounded-lg">
                        <div>
                          <div className="font-medium">Reguler</div>
                          <div className="text-sm text-gray-600">3-5 hari kerja</div>
                        </div>
                        <span className="font-semibold">Gratis</span>
                      </div>
                      <div className="flex justify-between items-center p-3 border rounded-lg">
                        <div>
                          <div className="font-medium">Express</div>
                          <div className="text-sm text-gray-600">1-2 hari kerja</div>
                        </div>
                        <span className="font-semibold">Rp15.000</span>
                      </div>
                      <div className="flex justify-between items-center p-3 border rounded-lg">
                        <div>
                          <div className="font-medium">Same Day</div>
                          <div className="text-sm text-gray-600">Pengiriman hari yang sama</div>
                        </div>
                        <span className="font-semibold">Rp25.000</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-3">Informasi Pengiriman</h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Pengiriman tersedia untuk seluruh Indonesia</li>
                      <li>• Gratis ongkir untuk pembelian minimal Rp50.000</li>
                      <li>• Nomor resi akan dikirimkan via email/SMS</li>
                      <li>• Estimasi pengiriman dapat berubah tergantung lokasi</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      <div>
        {isLoadingRecommendations ? (
          <div className="flex flex-col items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-purple-600 mb-4" />
            <p className="text-gray-600">Memuat rekomendasi produk...</p>
          </div>
        ) : recommendations.length > 0 ? (
          <ProductCarousel 
            products={recommendations}
            title="Rekomendasi Produk Untuk Anda"
            subtitle="Produk serupa yang mungkin Anda suka"
          />
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-600">Tidak ada rekomendasi produk saat ini</p>
          </div>
        )}
      </div>
    </div>
  )
}