'use client'

import { useTranslation } from 'react-i18next'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Shield, Users, Gavel, AlertCircle } from 'lucide-react'

export default function TermsPage() {
  const { t } = useTranslation()

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Terms of Service
          </h1>
          <p className="text-xl text-gray-600">
            Last updated: {new Date().toLocaleDateString()}
          </p>
        </div>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Gavel className="w-5 h-5 mr-2" />
                Agreement to Terms
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                By accessing and using ShopHub ("the Service"), you agree to be bound by these Terms of Service ("Terms"). 
                If you disagree with any part of these terms, then you may not access the Service.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                Accounts and Registration
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-lg mb-2">Account Creation</h3>
                  <p>
                    To access certain features of the Service, you must register for an account. 
                    You agree to provide accurate, current, and complete information during registration.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-semibold text-lg mb-2">Account Security</h3>
                  <p>
                    You are responsible for safeguarding the password that you use to access the Service 
                    and for any activities or actions under your password. You agree not to disclose your 
                    password to any third party.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-semibold text-lg mb-2">Account Termination</h3>
                  <p>
                    ShopHub may terminate or suspend your account immediately, without prior notice or 
                    liability, for any reason whatsoever, including without limitation if you breach the Terms.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Products and Services
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-lg mb-2">Product Listings</h3>
                  <p>
                    Sellers are responsible for the accuracy and legality of their product listings. 
                    ShopHub does not guarantee the quality, safety, or legality of products listed on the platform.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-semibold text-lg mb-2">Prohibited Items</h3>
                  <p>
                    The following items are prohibited from being sold on ShopHub:
                  </p>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>Illegal products or services</li>
                    <li>Counterfeit goods</li>
                    <li>Weapons and explosives</li>
                    <li>Hazardous materials</li>
                    <li>Stolen goods</li>
                    <li>Digital goods that violate intellectual property rights</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="font-semibold text-lg mb-2">Pricing and Payments</h3>
                  <p>
                    All prices are displayed in the selected currency and are inclusive of applicable taxes 
                    unless otherwise stated. Payment processing is handled through secure third-party payment processors.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertCircle className="w-5 h-5 mr-2" />
                Intellectual Property
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                The Service and its original content, features and functionality are and will remain the 
                exclusive property of ShopHub and its licensors. The Service is protected by copyright, 
                trademark, and other laws.
              </p>
              <p className="mt-4">
                You may not modify, reproduce, distribute, create derivative works, publicly display, 
                publicly perform, republish, download, store, or transmit any of the material on our Service, 
                except as permitted by law or with our prior written consent.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Privacy Policy</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                Your privacy is important to us. Our Privacy Policy explains how we collect, use, 
                and protect your information when you use our Service. By using ShopHub, you agree to 
                the collection and use of information in accordance with our Privacy Policy.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Limitation of Liability</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                In no event shall ShopHub, its directors, employees, partners, agents, suppliers, 
                or affiliates be liable for any indirect, incidental, special, consequential, or punitive 
                damages, including without limitation, loss of profits, data, use, goodwill, or other 
                intangible losses, resulting from your use of the Service.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Governing Law</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                These Terms shall be interpreted and governed by the laws of the jurisdiction in which 
                ShopHub operates, without regard to its conflict of law provisions.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Changes to Terms</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                We reserve the right, at our sole discretion, to modify or replace these Terms at any time. 
                If a revision is material, we will try to provide at least 30 days notice prior to any 
                new terms taking effect.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                If you have any questions about these Terms, please contact us at:
              </p>
              <div className="mt-4 space-y-2">
                <p><strong>Email:</strong> legal@shophub.com</p>
                <p><strong>Address:</strong> 123 Business Street, Commerce City, CC 12345</p>
                <p><strong>Phone:</strong> +1 (555) 123-4567</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}