'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { 
  ShoppingCart, 
  Plus, 
  Minus, 
  Trash2, 
  ArrowLeft,
  Truck,
  Shield,
  RefreshCw,
  ChevronRight
} from 'lucide-react'
import { useCart } from '@/hooks/use-cart'

export default function CartPage() {
  const { items, updateQuantity, removeItem, clearCart, getTotalPrice, getTotalItems } = useCart()
  const [promoCode, setPromoCode] = useState('')
  const [promoApplied, setPromoApplied] = useState(false)

  const subtotal = getTotalPrice()
  const shipping = subtotal >= 500000 ? 0 : 15000
  const tax = subtotal * 0.11 // 11% tax
  const discount = promoApplied ? subtotal * 0.1 : 0 // 10% discount
  const total = subtotal + shipping + tax - discount

  const handleQuantityChange = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(productId)
    } else {
      updateQuantity(productId, newQuantity)
    }
  }

  const handleApplyPromo = () => {
    if (promoCode.toLowerCase() === 'diskon10') {
      setPromoApplied(true)
    }
  }

  const handleRemovePromo = () => {
    setPromoApplied(false)
    setPromoCode('')
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingCart className="w-12 h-12 text-gray-400" />
          </div>
          <h1 className="text-3xl font-bold mb-4">Keranjang Belanja Kosong</h1>
          <p className="text-gray-600 mb-8">
            Belum ada produk di keranjang Anda. Mulai belanja sekarang!
          </p>
          <Link href="/produk">
            <Button size="lg">
              Mulai Belanja
              <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link href="/">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold">Keranjang Belanja</h1>
          <p className="text-gray-600">{getTotalItems()} produk</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => (
            <Card key={item.id}>
              <CardContent className="p-6">
                <div className="flex gap-4">
                  {/* Product Image */}
                  <div className="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Product Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start mb-2">
                      <Link href={`/produk/${item.slug}`}>
                        <h3 className="font-semibold hover:text-primary transition-colors line-clamp-2">
                          {item.name}
                        </h3>
                      </Link>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeItem(item.productId)}
                        className="text-red-500 hover:text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    <div className="text-lg font-bold text-primary mb-3">
                      Rp{item.price.toLocaleString('id-ID')}
                    </div>

                    {/* Quantity Controls */}
                    <div className="flex items-center gap-4">
                      <span className="text-sm font-medium">Jumlah:</span>
                      <div className="flex items-center border rounded-lg">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleQuantityChange(item.productId, item.quantity - 1)}
                          className="rounded-r-none"
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        <div className="w-12 text-center font-semibold">
                          {item.quantity}
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleQuantityChange(item.productId, item.quantity + 1)}
                          className="rounded-l-none"
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="text-sm text-gray-600">
                        Total: Rp{(item.price * item.quantity).toLocaleString('id-ID')}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {/* Cart Actions */}
          <div className="flex justify-between items-center pt-4">
            <Button
              variant="outline"
              onClick={clearCart}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Kosongkan Keranjang
            </Button>
            <Link href="/produk">
              <Button variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Tambah Produk Lain
              </Button>
            </Link>
          </div>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <Card className="sticky top-4">
            <CardHeader>
              <CardTitle>Ringkasan Pesanan</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Subtotal */}
              <div className="flex justify-between">
                <span>Subtotal ({getTotalItems()} produk)</span>
                <span className="font-semibold">Rp{subtotal.toLocaleString('id-ID')}</span>
              </div>

              {/* Shipping */}
              <div className="flex justify-between">
                <span>Biaya Pengiriman</span>
                <span className="font-semibold">
                  {shipping === 0 ? (
                    <span className="text-green-600">Gratis</span>
                  ) : (
                    `Rp${shipping.toLocaleString('id-ID')}`
                  )}
                </span>
              </div>

              {shipping > 0 && (
                <div className="text-sm text-green-600">
                  🎉 Gratis ongkir untuk pembelian minimal Rp500.000
                </div>
              )}

              {/* Tax */}
              <div className="flex justify-between">
                <span>Pajak (11%)</span>
                <span className="font-semibold">Rp{tax.toLocaleString('id-ID')}</span>
              </div>

              {/* Promo Code */}
              <div className="space-y-2">
                <div className="flex gap-2">
                  <Input
                    placeholder="Kode promo"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    disabled={promoApplied}
                  />
                  {promoApplied ? (
                    <Button variant="outline" onClick={handleRemovePromo}>
                      Hapus
                    </Button>
                  ) : (
                    <Button onClick={handleApplyPromo} disabled={!promoCode}>
                      Terapkan
                    </Button>
                  )}
                </div>
                {promoApplied && (
                  <div className="text-sm text-green-600">
                    ✅ Promo diskon 10% berhasil diterapkan
                  </div>
                )}
              </div>

              {/* Discount */}
              {discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Diskon</span>
                  <span className="font-semibold">-Rp{discount.toLocaleString('id-ID')}</span>
                </div>
              )}

              <Separator />

              {/* Total */}
              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span className="text-primary">Rp{total.toLocaleString('id-ID')}</span>
              </div>

              {/* Features */}
              <div className="space-y-2 pt-4">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Truck className="w-4 h-4 text-primary" />
                  <span>Pengiriman ke seluruh Indonesia</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Shield className="w-4 h-4 text-primary" />
                  <span>Pembayaran 100% aman</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <RefreshCw className="w-4 h-4 text-primary" />
                  <span>Pengembalian 30 hari</span>
                </div>
              </div>

              {/* Checkout Button */}
              <Link href="/checkout">
                <Button className="w-full" size="lg">
                  Checkout
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>

              {/* Security Badge */}
              <div className="text-center text-xs text-gray-500 pt-2">
                🔒 Pembayaran aman dan terenkripsi
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recommended Products */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6">Produk Rekomendasi</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Mock recommended products */}
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="group hover:shadow-lg transition-all duration-300">
              <CardContent className="p-4">
                <div className="aspect-square bg-gray-100 rounded-lg mb-4 overflow-hidden">
                  <img
                    src={`https://images.unsplash.com/photo-${1500000000000 + i}?w=400&h=400&fit=crop`}
                    alt={`Produk ${i}`}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <h3 className="font-semibold mb-2 line-clamp-2">Produk Rekomendasi {i}</h3>
                <div className="text-lg font-bold text-primary mb-3">
                  Rp{(999000 * i).toLocaleString('id-ID')}
                </div>
                <Button className="w-full" size="sm">
                  Tambah ke Keranjang
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}