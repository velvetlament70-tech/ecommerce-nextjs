"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { FormValidator } from "@/lib/form-validation"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Eye, EyeOff, Store, User, Shield } from "lucide-react"

export default function SignInPage() {
  const { login, isLoading } = useAuth()
  const router = useRouter()
  const [formData, setFormData] = useState({
    email: "",
    password: ""
  })
  const [errors, setErrors] = useState<Record<string, string[]>>({})
  const [touched, setTouched] = useState<Record<string, boolean>>({})
  const [showPassword, setShowPassword] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const validationRules = {
    email: FormValidator.COMMON_RULES.email,
    password: {
      required: true,
      minLength: 6,
      maxLength: 100
    }
  }

  const validateField = (fieldName: string, value: string) => {
    const fieldErrors = FormValidator.validateField(value, validationRules[fieldName], formData)
    setErrors(prev => ({
      ...prev,
      [fieldName]: fieldErrors
    }))
    return fieldErrors
  }

  const handleChange = (fieldName: string, value: string) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }))
    if (touched[fieldName]) {
      validateField(fieldName, value)
    }
  }

  const handleBlur = (fieldName: string) => {
    setTouched(prev => ({ ...prev, [fieldName]: true }))
    validateField(fieldName, formData[fieldName])
  }

  const getFieldError = (fieldName: string) => {
    if (touched[fieldName] && errors[fieldName]) {
      return errors[fieldName][0]
    }
    return ""
  }

  const hasFieldError = (fieldName: string) => {
    return touched[fieldName] && errors[fieldName] && errors[fieldName].length > 0
  }

  const isFormValid = () => {
    const validation = FormValidator.validateForm(formData, validationRules)
    return validation.isValid
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validate all fields
    const validation = FormValidator.validateForm(formData, validationRules)
    setErrors(validation.errors)
    
    // Mark all fields as touched
    const allTouched = Object.keys(validationRules).reduce((acc, key) => {
      acc[key] = true
      return acc
    }, {} as Record<string, boolean>)
    setTouched(allTouched)

    if (!validation.isValid) {
      return
    }

    setIsSubmitting(true)
    try {
      const success = await login(formData.email, formData.password)
      if (!success) {
        // Error handling is done in the auth context
      }
    } catch (error) {
      console.error("Login error:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <Store className="mx-auto h-12 w-12 text-primary" />
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
            Sign In to Your Account
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Or{" "}
            <Link href="/auth/signup" className="font-medium text-primary hover:text-primary/80">
              create a new account
            </Link>
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Welcome Back</CardTitle>
            <CardDescription>
              Enter your credentials to access your account
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange("email", e.target.value)}
                  onBlur={() => handleBlur("email")}
                  placeholder="Enter your email"
                  className={hasFieldError("email") ? "border-red-500" : ""}
                  disabled={isLoading || isSubmitting}
                  required
                />
                {hasFieldError("email") && (
                  <p className="text-sm text-red-500">{getFieldError("email")}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    value={formData.password}
                    onChange={(e) => handleChange("password", e.target.value)}
                    onBlur={() => handleBlur("password")}
                    placeholder="Enter your password"
                    className={hasFieldError("password") ? "border-red-500 pr-10" : "pr-10"}
                    disabled={isLoading || isSubmitting}
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading || isSubmitting}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                {hasFieldError("password") && (
                  <p className="text-sm text-red-500">{getFieldError("password")}</p>
                )}
              </div>

              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-sm text-blue-800">
                  <strong>Demo Accounts:</strong><br />
                  Customer: customer@example.com<br />
                  Seller: seller@example.com<br />
                  Admin: admin@example.com<br />
                  Password: password123
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                type="submit" 
                className="w-full" 
                disabled={!isFormValid() || isLoading || isSubmitting}
              >
                {(isLoading || isSubmitting) ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing In...
                  </>
                ) : (
                  "Sign In"
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>

        <div className="grid grid-cols-3 gap-3 text-center">
          <div className="bg-white p-3 rounded-lg shadow">
            <User className="mx-auto h-6 w-6 text-green-600 mb-1" />
            <p className="text-xs font-medium">Customer</p>
            <p className="text-xs text-gray-500">Shop products</p>
          </div>
          <div className="bg-white p-3 rounded-lg shadow">
            <Store className="mx-auto h-6 w-6 text-blue-600 mb-1" />
            <p className="text-xs font-medium">Seller</p>
            <p className="text-xs text-gray-500">Sell products</p>
          </div>
          <div className="bg-white p-3 rounded-lg shadow">
            <Shield className="mx-auto h-6 w-6 text-purple-600 mb-1" />
            <p className="text-xs font-medium">Admin</p>
            <p className="text-xs text-gray-500">Manage system</p>
          </div>
        </div>
      </div>
    </div>
  )
}