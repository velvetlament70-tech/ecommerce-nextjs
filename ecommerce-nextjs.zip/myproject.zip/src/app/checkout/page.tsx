'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useCart } from '@/hooks/use-cart'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { PaymentMethodSelector } from '@/components/payment/payment-method-selector'
import { 
  MapPin, 
  Phone, 
  Mail, 
  CreditCard, 
  Smartphone, 
  Truck,
  Shield,
  ChevronRight,
  Check,
  AlertCircle,
  User,
  ExternalLink,
  Clock
} from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

interface CheckoutFormData {
  firstName: string
  lastName: string
  email: string
  phone: string
  address: string
  city: string
  province: string
  postalCode: string
  paymentMethod: string
  notes: string
}

interface PaymentState {
  orderId?: string
  transactionId?: string
  paymentUrl?: string
  expiredAt?: string
  isProcessing: boolean
  paymentCompleted: boolean
}

export default function CheckoutPage() {
  const router = useRouter()
  const { items, getTotalPrice, getTotalItems, clearCart } = useCart()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errors, setErrors] = useState<Partial<CheckoutFormData>>({})
  const [orderSuccess, setOrderSuccess] = useState(false)
  const [orderNumber, setOrderNumber] = useState('')
  const [paymentState, setPaymentState] = useState<PaymentState>({
    isProcessing: false,
    paymentCompleted: false
  })

  const [formData, setFormData] = useState<CheckoutFormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    province: '',
    postalCode: '',
    paymentMethod: 'transfer',
    notes: ''
  })

  // Redirect if cart is empty
  useEffect(() => {
    if (items.length === 0 && !orderSuccess) {
      router.push('/cart')
    }
  }, [items, router, orderSuccess])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
    // Clear error when user starts typing
    if (errors[name as keyof CheckoutFormData]) {
      setErrors(prev => ({ ...prev, [name]: undefined }))
    }
  }

  const validateForm = (): boolean => {
    const newErrors: Partial<CheckoutFormData> = {}

    if (!formData.firstName.trim()) newErrors.firstName = 'Nama depan wajib diisi'
    if (!formData.lastName.trim()) newErrors.lastName = 'Nama belakang wajib diisi'
    if (!formData.email.trim()) {
      newErrors.email = 'Email wajib diisi'
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Format email tidak valid'
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Nomor HP wajib diisi'
    } else if (!/^[0-9+\-\s()]+$/.test(formData.phone)) {
      newErrors.phone = 'Format nomor HP tidak valid'
    }
    if (!formData.address.trim()) newErrors.address = 'Alamat wajib diisi'
    if (!formData.city.trim()) newErrors.city = 'Kota wajib diisi'
    if (!formData.province.trim()) newErrors.province = 'Provinsi wajib diisi'
    if (!formData.postalCode.trim()) {
      newErrors.postalCode = 'Kode pos wajib diisi'
    } else if (!/^[0-9]{5}$/.test(formData.postalCode.replace(/\s/g, ''))) {
      newErrors.postalCode = 'Kode pos harus 5 digit angka'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const generateOrderNumber = (): string => {
    const date = new Date()
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const day = String(date.getDate()).padStart(2, '0')
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0')
    return `ORD-${year}${month}${day}-${random}`
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)
    setPaymentState(prev => ({ ...prev, isProcessing: true }))

    try {
      // Step 1: Create order first
      const orderData = {
        shippingName: `${formData.firstName} ${formData.lastName}`,
        shippingEmail: formData.email,
        shippingPhone: formData.phone,
        shippingAddress: JSON.stringify({
          street: formData.address,
          city: formData.city,
          province: formData.province,
          postalCode: formData.postalCode
        }),
        shippingCity: formData.city,
        shippingState: formData.province,
        shippingCountry: 'Indonesia',
        shippingZip: formData.postalCode,
        billingName: `${formData.firstName} ${formData.lastName}`,
        billingEmail: formData.email,
        billingPhone: formData.phone,
        billingAddress: JSON.stringify({
          street: formData.address,
          city: formData.city,
          province: formData.province,
          postalCode: formData.postalCode
        }),
        billingCity: formData.city,
        billingState: formData.province,
        billingCountry: 'Indonesia',
        billingZip: formData.postalCode,
        notes: formData.notes,
        items: items.map(item => ({
          productId: item.id,
          productName: item.name,
          productSku: `SKU-${item.id}`,
          price: item.price,
          quantity: item.quantity
        })),
        subtotal,
        shipping,
        tax,
        total,
        currency: 'IDR'
      }

      // Create order
      const orderResponse = await fetch('/api/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderData),
      })

      const orderResult = await orderResponse.json()

      if (!orderResponse.ok) {
        throw new Error(orderResult.error || 'Failed to create order')
      }

      const orderId = orderResult.orderId

      // Step 2: Create payment
      const paymentData = {
        orderId,
        paymentMethod: formData.paymentMethod,
        paymentGateway: 'midtrans', // Default to midtrans for now
        amount: total,
        customerDetails: {
          firstName: formData.firstName,
          lastName: formData.lastName,
          email: formData.email,
          phone: formData.phone
        }
      }

      const paymentResponse = await fetch('/api/payments/create-payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(paymentData),
      })

      const paymentResult = await paymentResponse.json()

      if (!paymentResponse.ok) {
        throw new Error(paymentResult.error || 'Failed to create payment')
      }

      // Update payment state
      setPaymentState({
        orderId,
        transactionId: paymentResult.transaction.id,
        paymentUrl: paymentResult.transaction.paymentUrl,
        expiredAt: paymentResult.transaction.expiredAt,
        isProcessing: false,
        paymentCompleted: false
      })

      setOrderNumber(orderResult.orderNumber)
      
      // For COD, mark as completed immediately
      if (formData.paymentMethod === 'cod') {
        setPaymentState(prev => ({ ...prev, paymentCompleted: true }))
        setOrderSuccess(true)
        setTimeout(() => {
          clearCart()
        }, 1000)
      }

    } catch (error) {
      console.error('Checkout error:', error)
      setPaymentState(prev => ({ ...prev, isProcessing: false }))
      // You could show an error toast here
    } finally {
      setIsSubmitting(false)
    }
  }

  const subtotal = getTotalPrice()
  const shipping = subtotal > 500000 ? 0 : 15000
  const tax = subtotal * 0.11 // 11% tax
  const total = subtotal + shipping + tax

  // Check payment status
  const checkPaymentStatus = async () => {
    if (!paymentState.transactionId) return

    try {
      const response = await fetch(`/api/payments/status?transactionId=${paymentState.transactionId}`)
      const result = await response.json()

      if (result.success && result.transaction.status === 'SUCCESS') {
        setPaymentState(prev => ({ ...prev, paymentCompleted: true }))
        setOrderSuccess(true)
        setTimeout(() => {
          clearCart()
        }, 1000)
      }
    } catch (error) {
      console.error('Error checking payment status:', error)
    }
  }

  // Check payment status periodically when payment is pending
  useEffect(() => {
    if (paymentState.transactionId && !paymentState.paymentCompleted) {
      const interval = setInterval(checkPaymentStatus, 5000) // Check every 5 seconds
      return () => clearInterval(interval)
    }
  }, [paymentState.transactionId, paymentState.paymentCompleted])

  // Handle payment redirect
  const handlePaymentRedirect = () => {
    if (paymentState.paymentUrl) {
      window.open(paymentState.paymentUrl, '_blank')
    }
  }

  if (orderSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-2xl mx-auto px-4">
          <Card className="text-center">
            <CardContent className="pt-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              
              <h1 className="text-2xl font-bold text-gray-900 mb-2">
                Pesanan Berhasil Dibuat!
              </h1>
              
              <p className="text-gray-600 mb-6">
                Terima kasih telah berbelanja di toko kami
              </p>
              
              <div className="bg-gray-50 rounded-lg p-6 mb-6 text-left">
                <h3 className="font-semibold mb-4">Detail Pesanan</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Nomor Pesanan:</span>
                    <span className="font-medium">{orderNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tanggal:</span>
                    <span className="font-medium">{new Date().toLocaleDateString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Pembayaran:</span>
                    <span className="font-medium text-lg">{formatCurrency(total)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Metode Pembayaran:</span>
                    <span className="font-medium">
                      {formData.paymentMethod === 'transfer' && 'Transfer Bank'}
                      {formData.paymentMethod === 'ewallet' && 'E-Wallet'}
                      {formData.paymentMethod === 'cod' && 'COD (Bayar di Tempat)'}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <div className="flex items-start space-x-2">
                  <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div className="text-sm text-blue-800 text-left">
                    <p className="font-medium mb-1">Instruksi Selanjutnya:</p>
                    {formData.paymentMethod === 'transfer' && (
                      <p>Silakan lakukan pembayaran ke rekening yang telah ditentukan. Konfirmasi pembayaran akan dikirim melalui email.</p>
                    )}
                    {formData.paymentMethod === 'ewallet' && (
                      <p>Link pembayaran akan dikirim ke nomor HP Anda. Silakan selesaikan pembayaran dalam 24 jam.</p>
                    )}
                    {formData.paymentMethod === 'cod' && (
                      <p>Pesanan akan dikirim ke alamat Anda. Pembayaran dilakukan saat barang diterima.</p>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3">
                <Button 
                  onClick={() => router.push('/')}
                  className="flex-1"
                >
                  Kembali ke Beranda
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => window.print()}
                  className="flex-1"
                >
                  Cetak Struk
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Checkout</h1>
          <p className="text-gray-600">Lengkapi data pengiriman dan pembayaran Anda</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Form Section */}
          <div className="lg:col-span-2 space-y-6">
            {/* Contact Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Informasi Kontak
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">Nama Depan *</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      className={errors.firstName ? 'border-red-500' : ''}
                      placeholder="John"
                    />
                    {errors.firstName && (
                      <p className="text-sm text-red-500 mt-1">{errors.firstName}</p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="lastName">Nama Belakang *</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      className={errors.lastName ? 'border-red-500' : ''}
                      placeholder="Doe"
                    />
                    {errors.lastName && (
                      <p className="text-sm text-red-500 mt-1">{errors.lastName}</p>
                    )}
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className={errors.email ? 'border-red-500' : ''}
                    placeholder="john.doe@example.com"
                  />
                  {errors.email && (
                    <p className="text-sm text-red-500 mt-1">{errors.email}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="phone">Nomor HP *</Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className={errors.phone ? 'border-red-500' : ''}
                    placeholder="+62 812-3456-7890"
                  />
                  {errors.phone && (
                    <p className="text-sm text-red-500 mt-1">{errors.phone}</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Shipping Address */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="w-5 h-5" />
                  Alamat Pengiriman
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="address">Alamat Lengkap *</Label>
                  <Input
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    className={errors.address ? 'border-red-500' : ''}
                    placeholder="Jl. Sudirman No. 123, RT 04/RW 05"
                  />
                  {errors.address && (
                    <p className="text-sm text-red-500 mt-1">{errors.address}</p>
                  )}
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="city">Kota *</Label>
                    <Input
                      id="city"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      className={errors.city ? 'border-red-500' : ''}
                      placeholder="Jakarta"
                    />
                    {errors.city && (
                      <p className="text-sm text-red-500 mt-1">{errors.city}</p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="province">Provinsi *</Label>
                    <Input
                      id="province"
                      name="province"
                      value={formData.province}
                      onChange={handleInputChange}
                      className={errors.province ? 'border-red-500' : ''}
                      placeholder="DKI Jakarta"
                    />
                    {errors.province && (
                      <p className="text-sm text-red-500 mt-1">{errors.province}</p>
                    )}
                  </div>
                </div>

                <div className="sm:w-1/2">
                  <Label htmlFor="postalCode">Kode Pos *</Label>
                  <Input
                    id="postalCode"
                    name="postalCode"
                    value={formData.postalCode}
                    onChange={handleInputChange}
                    className={errors.postalCode ? 'border-red-500' : ''}
                    placeholder="12345"
                  />
                  {errors.postalCode && (
                    <p className="text-sm text-red-500 mt-1">{errors.postalCode}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="notes">Catatan (Opsional)</Label>
                  <Input
                    id="notes"
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    placeholder="Contoh: Rumah warna biru, depan toko kelontong"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Payment Method */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5" />
                  Metode Pembayaran
                </CardTitle>
              </CardHeader>
              <CardContent>
                <PaymentMethodSelector
                  selectedMethod={formData.paymentMethod}
                  onMethodChange={(value) => setFormData(prev => ({ ...prev, paymentMethod: value }))}
                  amount={total}
                />
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-8 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Ringkasan Pesanan</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Products */}
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {items.map((item) => (
                      <div key={item.id} className="flex gap-3">
                        <div className="w-16 h-16 bg-gray-100 rounded-lg flex-shrink-0 overflow-hidden">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm truncate">{item.name}</h4>
                          <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                          <p className="text-sm font-medium text-primary">
                            {formatCurrency(item.price * item.quantity)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  {/* Price Details */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Subtotal ({getTotalItems()} items)</span>
                      <span>{formatCurrency(subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Biaya Pengiriman</span>
                      <span>
                        {shipping === 0 ? (
                          <Badge variant="secondary" className="text-xs">Gratis</Badge>
                        ) : (
                          formatCurrency(shipping)
                        )}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Pajak (11%)</span>
                      <span>{formatCurrency(tax)}</span>
                    </div>
                    {shipping === 0 && (
                      <Alert className="py-2">
                        <AlertDescription className="text-xs">
                          🎉 Gratis ongkir untuk pembelian di atas {formatCurrency(500000)}
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>

                  <Separator />

                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span className="text-primary">{formatCurrency(total)}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Security Badge */}
              <Card className="bg-green-50 border-green-200">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 text-green-800">
                    <Shield className="w-5 h-5" />
                    <span className="text-sm font-medium">Pembayaran Aman</span>
                  </div>
                  <p className="text-xs text-green-700 mt-1">
                    Data Anda dilindungi dengan enkripsi SSL
                  </p>
                </CardContent>
              </Card>

              {/* Payment Processing State */}
              {paymentState.transactionId && !paymentState.paymentCompleted && (
                <Card className="bg-blue-50 border-blue-200">
                  <CardContent className="pt-6">
                    <div className="text-center space-y-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                        <Clock className="w-6 h-6 text-blue-600 animate-spin" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-blue-900 mb-1">Menunggu Pembayaran</h3>
                        <p className="text-sm text-blue-700 mb-3">
                          Pesanan Anda telah dibuat. Silakan selesaikan pembayaran.
                        </p>
                        <div className="bg-white rounded-lg p-3 text-left">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm text-gray-600">No. Pesanan:</span>
                            <span className="font-medium">{orderNumber}</span>
                          </div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm text-gray-600">Total:</span>
                            <span className="font-medium">{formatCurrency(total)}</span>
                          </div>
                          {paymentState.expiredAt && (
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">Kadaluarsa:</span>
                              <span className="text-sm text-orange-600">
                                {new Date(paymentState.expiredAt).toLocaleString('id-ID')}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Button
                          onClick={handlePaymentRedirect}
                          className="w-full"
                          size="sm"
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Bayar Sekarang
                        </Button>
                        <Button
                          onClick={checkPaymentStatus}
                          variant="outline"
                          size="sm"
                          className="w-full"
                        >
                          Cek Status Pembayaran
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Submit Button */}
              {!paymentState.transactionId && (
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting || items.length === 0}
                  className="w-full"
                  size="lg"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      Memproses...
                    </>
                  ) : (
                    <>
                      Buat Pesanan
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              )}

              <p className="text-xs text-gray-500 text-center">
                Dengan melakukan checkout, Anda menyetujui syarat dan ketentuan yang berlaku
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}