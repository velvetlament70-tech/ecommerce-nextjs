'use client'

import { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useToast } from '@/hooks/use-toast'
import { 
  Shield, 
  Download, 
  Eye, 
  Trash2, 
  Mail, 
  CheckCircle, 
  Clock,
  User,
  FileText,
  Search,
  AlertTriangle,
  Settings
} from 'lucide-react'

interface DataRequest {
  id: string
  type: 'access' | 'deletion' | 'correction' | 'portability'
  status: 'pending' | 'processing' | 'completed' | 'rejected'
  createdAt: string
  completedAt?: string
  description: string
}

interface ConsentRecord {
  id: string
  type: string
  description: string
  date: string
  status: 'active' | 'withdrawn'
}

export default function GDPRPage() {
  const { t } = useTranslation()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState<'rights' | 'requests' | 'consent' | 'contact'>('rights')
  const [requests, setRequests] = useState<DataRequest[]>([])
  const [consents, setConsents] = useState<ConsentRecord[]>([])
  const [loading, setLoading] = useState(false)

  // Form states
  const [requestType, setRequestType] = useState<'access' | 'deletion' | 'correction' | 'portability'>('access')
  const [requestDescription, setRequestDescription] = useState('')
  const [contactEmail, setContactEmail] = useState('')
  const [contactSubject, setContactSubject] = useState('')
  const [contactMessage, setContactMessage] = useState('')

  useEffect(() => {
    // Load user's data requests and consents
    loadDataRequests()
    loadConsents()
  }, [])

  const loadDataRequests = async () => {
    // Mock data - in real app, this would come from API
    setRequests([
      {
        id: '1',
        type: 'access',
        status: 'completed',
        createdAt: '2024-01-15T10:00:00Z',
        completedAt: '2024-01-17T14:30:00Z',
        description: 'Request for copy of personal data'
      }
    ])
  }

  const loadConsents = async () => {
    // Mock data - in real app, this would come from API
    setConsents([
      {
        id: '1',
        type: 'Marketing Communications',
        description: 'Consent to receive marketing emails and notifications',
        date: '2024-01-01T00:00:00Z',
        status: 'active'
      },
      {
        id: '2',
        type: 'Analytics Cookies',
        description: 'Consent for analytics and performance cookies',
        date: '2024-01-01T00:00:00Z',
        status: 'active'
      }
    ])
  }

  const submitDataRequest = async () => {
    if (!requestDescription.trim()) {
      toast({
        title: "Error",
        description: "Please provide a description for your request",
        variant: "destructive"
      })
      return
    }

    setLoading(true)
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const newRequest: DataRequest = {
        id: Date.now().toString(),
        type: requestType,
        status: 'pending',
        createdAt: new Date().toISOString(),
        description: requestDescription
      }

      setRequests(prev => [newRequest, ...prev])
      setRequestDescription('')
      
      toast({
        title: "Request Submitted",
        description: "Your data request has been submitted successfully. We'll process it within 30 days.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit request. Please try again.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const withdrawConsent = async (consentId: string) => {
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 500))
      
      setConsents(prev => 
        prev.map(consent => 
          consent.id === consentId 
            ? { ...consent, status: 'withdrawn' as const }
            : consent
        )
      )
      
      toast({
        title: "Consent Withdrawn",
        description: "Your consent has been successfully withdrawn.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to withdraw consent. Please try again.",
        variant: "destructive"
      })
    }
  }

  const downloadData = async () => {
    setLoading(true)
    try {
      // Mock API call to generate data export
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Create and download a mock data file
      const userData = {
        personalInfo: {
          name: "John Doe",
          email: "john@example.com",
          phone: "+1234567890"
        },
        preferences: {
          language: "en",
          currency: "USD",
          marketing: true
        },
        activity: {
          lastLogin: "2024-01-20T10:00:00Z",
          orders: 5,
          wishlistItems: 3
        }
      }

      const blob = new Blob([JSON.stringify(userData, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'my-data-export.json'
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      
      toast({
        title: "Data Exported",
        description: "Your personal data has been downloaded successfully.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export data. Please try again.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const deleteAccount = async () => {
    const confirmed = window.confirm(
      "Are you sure you want to delete your account? This action cannot be undone and will permanently delete all your data."
    )
    
    if (!confirmed) return

    setLoading(true)
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      toast({
        title: "Account Deletion Requested",
        description: "Your account deletion request has been submitted. We'll process it within 30 days.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit deletion request. Please try again.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const submitContact = async () => {
    if (!contactEmail || !contactSubject || !contactMessage) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      })
      return
    }

    setLoading(true)
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setContactEmail('')
      setContactSubject('')
      setContactMessage('')
      
      toast({
        title: "Message Sent",
        description: "Your message has been sent to our data protection team.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800'
      case 'pending': return 'bg-yellow-100 text-yellow-800'
      case 'processing': return 'bg-blue-100 text-blue-800'
      case 'rejected': return 'bg-red-100 text-red-800'
      case 'active': return 'bg-green-100 text-green-800'
      case 'withdrawn': return 'bg-gray-100 text-gray-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Data Protection & Privacy Rights
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Manage your personal data and exercise your privacy rights under GDPR, PDPA, and other data protection regulations.
          </p>
        </div>

        {/* Alert for EU Users */}
        <Alert className="mb-8 border-blue-200 bg-blue-50">
          <Shield className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800">
            <strong>EU Residents:</strong> You have comprehensive rights under GDPR to control your personal data. 
            Learn more about your rights and how to exercise them below.
          </AlertDescription>
        </Alert>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          <Button
            variant={activeTab === 'rights' ? 'default' : 'outline'}
            onClick={() => setActiveTab('rights')}
          >
            <Shield className="w-4 h-4 mr-2" />
            Your Rights
          </Button>
          <Button
            variant={activeTab === 'requests' ? 'default' : 'outline'}
            onClick={() => setActiveTab('requests')}
          >
            <FileText className="w-4 h-4 mr-2" />
            Data Requests
          </Button>
          <Button
            variant={activeTab === 'consent' ? 'default' : 'outline'}
            onClick={() => setActiveTab('consent')}
          >
            <CheckCircle className="w-4 h-4 mr-2" />
            Consents
          </Button>
          <Button
            variant={activeTab === 'contact' ? 'default' : 'outline'}
            onClick={() => setActiveTab('contact')}
          >
            <Mail className="w-4 h-4 mr-2" />
            Contact DPO
          </Button>
        </div>

        {/* Your Rights Tab */}
        {activeTab === 'rights' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="w-5 h-5 mr-2" />
                  Your Data Protection Rights
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="border rounded-lg p-4">
                    <h3 className="font-semibold mb-2 flex items-center">
                      <Eye className="w-4 h-4 mr-2 text-blue-600" />
                      Right to Access
                    </h3>
                    <p className="text-sm text-gray-600">
                      Request a copy of all personal data we hold about you.
                    </p>
                    <Button size="sm" className="mt-3" onClick={downloadData} disabled={loading}>
                      <Download className="w-4 h-4 mr-2" />
                      Download My Data
                    </Button>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h3 className="font-semibold mb-2 flex items-center">
                      <Trash2 className="w-4 h-4 mr-2 text-red-600" />
                      Right to Erasure
                    </h3>
                    <p className="text-sm text-gray-600">
                      Request deletion of your personal data.
                    </p>
                    <Button size="sm" variant="destructive" className="mt-3" onClick={deleteAccount} disabled={loading}>
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete Account
                    </Button>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h3 className="font-semibold mb-2 flex items-center">
                      <FileText className="w-4 h-4 mr-2 text-green-600" />
                      Right to Rectification
                    </h3>
                    <p className="text-sm text-gray-600">
                      Request correction of inaccurate personal data.
                    </p>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h3 className="font-semibold mb-2 flex items-center">
                      <Download className="w-4 h-4 mr-2 text-purple-600" />
                      Right to Portability
                    </h3>
                    <p className="text-sm text-gray-600">
                      Request your data in a machine-readable format.
                    </p>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h3 className="font-semibold mb-4">Additional Rights</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <h4 className="font-medium mb-1">Right to Object</h4>
                      <p className="text-gray-600">
                        Object to processing of your personal data for direct marketing or other legitimate interests.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">Right to Restrict Processing</h4>
                      <p className="text-gray-600">
                        Restrict processing of your personal data in certain circumstances.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">Right to Withdraw Consent</h4>
                      <p className="text-gray-600">
                        Withdraw consent at any time where processing is based on consent.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">Right to Lodge a Complaint</h4>
                      <p className="text-gray-600">
                        Complain to a supervisory authority about our processing of your data.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Data Requests Tab */}
        {activeTab === 'requests' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Submit New Data Request</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="requestType">Request Type</Label>
                  <Select value={requestType} onValueChange={(value: any) => setRequestType(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="access">Data Access Request</SelectItem>
                      <SelectItem value="deletion">Data Deletion Request</SelectItem>
                      <SelectItem value="correction">Data Correction Request</SelectItem>
                      <SelectItem value="portability">Data Portability Request</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Please describe your request in detail..."
                    value={requestDescription}
                    onChange={(e) => setRequestDescription(e.target.value)}
                    rows={4}
                  />
                </div>

                <Button onClick={submitDataRequest} disabled={loading}>
                  {loading ? 'Submitting...' : 'Submit Request'}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Your Previous Requests</CardTitle>
              </CardHeader>
              <CardContent>
                {requests.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No previous requests found.</p>
                ) : (
                  <div className="space-y-4">
                    {requests.map((request) => (
                      <div key={request.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-medium capitalize">{request.type} Request</h4>
                            <p className="text-sm text-gray-600 mt-1">{request.description}</p>
                            <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                              <span>Created: {new Date(request.createdAt).toLocaleDateString()}</span>
                              {request.completedAt && (
                                <span>Completed: {new Date(request.completedAt).toLocaleDateString()}</span>
                              )}
                            </div>
                          </div>
                          <Badge className={getStatusColor(request.status)}>
                            {request.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Consents Tab */}
        {activeTab === 'consent' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Your Active Consents</CardTitle>
              </CardHeader>
              <CardContent>
                {consents.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No active consents found.</p>
                ) : (
                  <div className="space-y-4">
                    {consents.map((consent) => (
                      <div key={consent.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-medium">{consent.type}</h4>
                            <p className="text-sm text-gray-600 mt-1">{consent.description}</p>
                            <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                              <span>Given: {new Date(consent.date).toLocaleDateString()}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={getStatusColor(consent.status)}>
                              {consent.status}
                            </Badge>
                            {consent.status === 'active' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => withdrawConsent(consent.id)}
                              >
                                Withdraw
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cookie Preferences</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Manage your cookie preferences for analytics, marketing, and functional cookies.
                </p>
                <Button variant="outline">
                  <Settings className="w-4 h-4 mr-2" />
                  Manage Cookie Settings
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Contact DPO Tab */}
        {activeTab === 'contact' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Contact Our Data Protection Officer</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold mb-3">Contact Information</h3>
                    <div className="space-y-2 text-sm">
                      <p><strong>Email:</strong> dpo@shophub.com</p>
                      <p><strong>Phone:</strong> +1 (555) 123-4567 ext. 999</p>
                      <p><strong>Address:</strong> 123 Business Street, Commerce City, CC 12345</p>
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-3">Response Times</h3>
                    <div className="space-y-2 text-sm">
                      <p><strong>Standard Requests:</strong> Within 30 days</p>
                      <p><strong>Urgent Requests:</strong> Within 7 days</p>
                      <p><strong>Complex Requests:</strong> Up to 90 days</p>
                    </div>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h3 className="font-semibold mb-4">Send us a Message</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="contactEmail">Email *</Label>
                        <Input
                          id="contactEmail"
                          type="email"
                          value={contactEmail}
                          onChange={(e) => setContactEmail(e.target.value)}
                          placeholder="your@email.com"
                        />
                      </div>
                      <div>
                        <Label htmlFor="contactSubject">Subject *</Label>
                        <Input
                          id="contactSubject"
                          value={contactSubject}
                          onChange={(e) => setContactSubject(e.target.value)}
                          placeholder="Subject of your message"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="contactMessage">Message *</Label>
                      <Textarea
                        id="contactMessage"
                        value={contactMessage}
                        onChange={(e) => setContactMessage(e.target.value)}
                        placeholder="Please describe your request or concern..."
                        rows={6}
                      />
                    </div>

                    <Button onClick={submitContact} disabled={loading}>
                      {loading ? 'Sending...' : 'Send Message'}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Important:</strong> For data subject requests, please provide sufficient information 
                to verify your identity. We may request additional documentation to prevent unauthorized 
                disclosure of personal information.
              </AlertDescription>
            </Alert>
          </div>
        )}
      </div>
    </div>
  )
}