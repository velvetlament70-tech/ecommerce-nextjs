'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { 
  Upload, 
  FileText, 
  Code, 
  CheckCircle, 
  AlertCircle, 
  Info,
  ArrowLeft,
  ArrowRight,
  Package,
  Zap,
  Shield,
  Globe
} from 'lucide-react';
import Link from 'next/link';

export default function SubmitPlugin() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    // Basic Information
    name: '',
    version: '',
    description: '',
    category: '',
    author: '',
    email: '',
    website: '',
    
    // Plugin Details
    features: [] as string[],
    compatibility: [] as string[],
    documentation: '',
    changelog: '',
    
    // Pricing
    pricingModel: 'free',
    price: '',
    
    // Files
    pluginFile: null as File | null,
    screenshots: [] as File[],
    documentationFile: null as File | null,
    
    // Terms
    agreeToTerms: false,
    agreeToGuidelines: false
  });

  const [uploadProgress, setUploadProgress] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const categories = [
    'Payment Processing',
    'Shipping & Delivery',
    'Marketing & SEO',
    'Analytics & Reporting',
    'Customer Support',
    'Inventory Management',
    'Social Media',
    'Email Marketing',
    'Security',
    'Design & Display',
    'Other'
  ];

  const compatibilityOptions = [
    'ShopHub v4.0+',
    'ShopHub v3.5+',
    'ShopHub v3.0+',
    'All Versions'
  ];

  const featureOptions = [
    'Multi-language Support',
    'Real-time Sync',
    'Mobile Responsive',
    'API Integration',
    'Customizable',
    'Analytics Dashboard',
    'Automated Workflows',
    'Third-party Integrations'
  ];

  const steps = [
    { id: 1, title: 'Basic Information', icon: Package },
    { id: 2, title: 'Plugin Details', icon: Code },
    { id: 3, title: 'Pricing & Files', icon: Upload },
    { id: 4, title: 'Review & Submit', icon: CheckCircle }
  ];

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleFeatureToggle = (feature: string) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.includes(feature)
        ? prev.features.filter(f => f !== feature)
        : [...prev.features, feature]
    }));
  };

  const handleCompatibilityToggle = (compat: string) => {
    setFormData(prev => ({
      ...prev,
      compatibility: prev.compatibility.includes(compat)
        ? prev.compatibility.filter(c => c !== compat)
        : [...prev.compatibility, compat]
    }));
  };

  const handleFileUpload = (field: string, file: File | null) => {
    setFormData(prev => ({ ...prev, [field]: file }));
  };

  const handleScreenshotUpload = (files: FileList) => {
    setFormData(prev => ({
      ...prev,
      screenshots: [...prev.screenshots, ...Array.from(files)]
    }));
  };

  const removeScreenshot = (index: number) => {
    setFormData(prev => ({
      ...prev,
      screenshots: prev.screenshots.filter((_, i) => i !== index)
    }));
  };

  const validateStep = (step: number): boolean => {
    const newErrors: Record<string, string> = {};

    if (step === 1) {
      if (!formData.name.trim()) newErrors.name = 'Plugin name is required';
      if (!formData.version.trim()) newErrors.version = 'Version is required';
      if (!formData.description.trim()) newErrors.description = 'Description is required';
      if (!formData.category) newErrors.category = 'Category is required';
      if (!formData.author.trim()) newErrors.author = 'Author name is required';
      if (!formData.email.trim()) newErrors.email = 'Email is required';
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
        newErrors.email = 'Invalid email format';
      }
    }

    if (step === 2) {
      if (formData.features.length === 0) newErrors.features = 'Select at least one feature';
      if (formData.compatibility.length === 0) newErrors.compatibility = 'Select compatibility options';
      if (!formData.documentation.trim()) newErrors.documentation = 'Documentation URL is required';
    }

    if (step === 3) {
      if (!formData.pluginFile) newErrors.pluginFile = 'Plugin file is required';
      if (formData.pricingModel === 'paid' && (!formData.price || parseFloat(formData.price) <= 0)) {
        newErrors.price = 'Valid price is required for paid plugins';
      }
    }

    if (step === 4) {
      if (!formData.agreeToTerms) newErrors.agreeToTerms = 'You must agree to the terms';
      if (!formData.agreeToGuidelines) newErrors.agreeToGuidelines = 'You must agree to the guidelines';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, steps.length));
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = async () => {
    if (!validateStep(4)) return;

    setIsSubmitting(true);
    setUploadProgress(0);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + 10;
      });
    }, 200);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 3000));
      setUploadProgress(100);
      
      // Show success message or redirect
      setTimeout(() => {
        alert('Plugin submitted successfully! We will review it within 3-5 business days.');
        // Reset form or redirect
      }, 1000);
    } catch (error) {
      console.error('Submission failed:', error);
    } finally {
      setIsSubmitting(false);
      clearInterval(interval);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="name">Plugin Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="My Awesome Plugin"
                  className={errors.name ? 'border-red-500' : ''}
                />
                {errors.name && <p className="text-sm text-red-500">{errors.name}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="version">Version *</Label>
                <Input
                  id="version"
                  value={formData.version}
                  onChange={(e) => handleInputChange('version', e.target.value)}
                  placeholder="1.0.0"
                  className={errors.version ? 'border-red-500' : ''}
                />
                {errors.version && <p className="text-sm text-red-500">{errors.version}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder="Describe your plugin and its features..."
                rows={4}
                className={errors.description ? 'border-red-500' : ''}
              />
              {errors.description && <p className="text-sm text-red-500">{errors.description}</p>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
                  <SelectTrigger className={errors.category ? 'border-red-500' : ''}>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.category && <p className="text-sm text-red-500">{errors.category}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="author">Author Name *</Label>
                <Input
                  id="author"
                  value={formData.author}
                  onChange={(e) => handleInputChange('author', e.target.value)}
                  placeholder="Your Name or Company"
                  className={errors.author ? 'border-red-500' : ''}
                />
                {errors.author && <p className="text-sm text-red-500">{errors.author}</p>}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="email">Contact Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="contact@example.com"
                  className={errors.email ? 'border-red-500' : ''}
                />
                {errors.email && <p className="text-sm text-red-500">{errors.email}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  value={formData.website}
                  onChange={(e) => handleInputChange('website', e.target.value)}
                  placeholder="https://yourwebsite.com"
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div>
              <Label className="text-base font-medium">Features *</Label>
              <p className="text-sm text-gray-600 mb-3">Select all features that apply to your plugin</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {featureOptions.map(feature => (
                  <div key={feature} className="flex items-center space-x-2">
                    <Checkbox
                      id={feature}
                      checked={formData.features.includes(feature)}
                      onCheckedChange={() => handleFeatureToggle(feature)}
                    />
                    <Label htmlFor={feature} className="text-sm">{feature}</Label>
                  </div>
                ))}
              </div>
              {errors.features && <p className="text-sm text-red-500 mt-2">{errors.features}</p>}
            </div>

            <div>
              <Label className="text-base font-medium">Compatibility *</Label>
              <p className="text-sm text-gray-600 mb-3">Select ShopHub versions your plugin supports</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {compatibilityOptions.map(compat => (
                  <div key={compat} className="flex items-center space-x-2">
                    <Checkbox
                      id={compat}
                      checked={formData.compatibility.includes(compat)}
                      onCheckedChange={() => handleCompatibilityToggle(compat)}
                    />
                    <Label htmlFor={compat} className="text-sm">{compat}</Label>
                  </div>
                ))}
              </div>
              {errors.compatibility && <p className="text-sm text-red-500 mt-2">{errors.compatibility}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="documentation">Documentation URL *</Label>
              <Input
                id="documentation"
                value={formData.documentation}
                onChange={(e) => handleInputChange('documentation', e.target.value)}
                placeholder="https://docs.example.com/plugin"
                className={errors.documentation ? 'border-red-500' : ''}
              />
              {errors.documentation && <p className="text-sm text-red-500">{errors.documentation}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="changelog">Changelog</Label>
              <Textarea
                id="changelog"
                value={formData.changelog}
                onChange={(e) => handleInputChange('changelog', e.target.value)}
                placeholder="List the changes in this version..."
                rows={3}
              />
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div>
              <Label className="text-base font-medium">Plugin File *</Label>
              <p className="text-sm text-gray-600 mb-3">Upload your plugin (.zip format, max 50MB)</p>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                <input
                  type="file"
                  accept=".zip"
                  onChange={(e) => handleFileUpload('pluginFile', e.target.files?.[0] || null)}
                  className="hidden"
                  id="pluginFile"
                />
                <label htmlFor="pluginFile" className="cursor-pointer">
                  <span className="text-blue-600 hover:text-blue-700">Choose file</span> or drag and drop
                </label>
                {formData.pluginFile && (
                  <div className="mt-3 text-sm text-green-600">
                    <CheckCircle className="inline h-4 w-4 mr-1" />
                    {formData.pluginFile.name}
                  </div>
                )}
              </div>
              {errors.pluginFile && <p className="text-sm text-red-500 mt-2">{errors.pluginFile}</p>}
            </div>

            <div>
              <Label className="text-base font-medium">Screenshots</Label>
              <p className="text-sm text-gray-600 mb-3">Upload screenshots of your plugin (max 5 images)</p>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={(e) => e.target.files && handleScreenshotUpload(e.target.files)}
                  className="hidden"
                  id="screenshots"
                />
                <label htmlFor="screenshots" className="cursor-pointer">
                  <span className="text-blue-600 hover:text-blue-700">Choose images</span> or drag and drop
                </label>
              </div>
              {formData.screenshots.length > 0 && (
                <div className="mt-3 grid grid-cols-2 md:grid-cols-3 gap-3">
                  {formData.screenshots.map((file, index) => (
                    <div key={index} className="relative group">
                      <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                        <FileText className="h-8 w-8 text-gray-400" />
                      </div>
                      <button
                        type="button"
                        onClick={() => removeScreenshot(index)}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <AlertCircle className="h-3 w-3" />
                      </button>
                      <p className="text-xs text-gray-600 mt-1 truncate">{file.name}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <Label className="text-base font-medium">Pricing Model</Label>
              <Select value={formData.pricingModel} onValueChange={(value) => handleInputChange('pricingModel', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="free">Free</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="freemium">Freemium</SelectItem>
                  <SelectItem value="subscription">Subscription</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.pricingModel === 'paid' && (
              <div className="space-y-2">
                <Label htmlFor="price">Price (USD) *</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => handleInputChange('price', e.target.value)}
                  placeholder="29.99"
                  className={errors.price ? 'border-red-500' : ''}
                />
                {errors.price && <p className="text-sm text-red-500">{errors.price}</p>}
              </div>
            )}
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                Please review your plugin submission before submitting. Our team will review your plugin within 3-5 business days.
              </Alert>
            </Alert>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  Plugin Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <span className="text-sm font-medium text-gray-600">Name:</span>
                    <p className="font-medium">{formData.name || 'Not provided'}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Version:</span>
                    <p className="font-medium">{formData.version || 'Not provided'}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Category:</span>
                    <p className="font-medium">{formData.category || 'Not selected'}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Author:</span>
                    <p className="font-medium">{formData.author || 'Not provided'}</p>
                  </div>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600">Description:</span>
                  <p className="text-sm mt-1">{formData.description || 'Not provided'}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  Features & Compatibility
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <span className="text-sm font-medium text-gray-600">Features:</span>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.features.length > 0 ? (
                      formData.features.map(feature => (
                        <Badge key={feature} variant="secondary">{feature}</Badge>
                      ))
                    ) : (
                      <span className="text-sm text-gray-500">No features selected</span>
                    )}
                  </div>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600">Compatibility:</span>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.compatibility.length > 0 ? (
                      formData.compatibility.map(comp => (
                        <Badge key={comp} variant="outline">{comp}</Badge>
                      ))
                    ) : (
                      <span className="text-sm text-gray-500">No compatibility selected</span>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  Pricing & Files
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <span className="text-sm font-medium text-gray-600">Pricing Model:</span>
                    <p className="font-medium capitalize">{formData.pricingModel}</p>
                  </div>
                  {formData.pricingModel === 'paid' && (
                    <div>
                      <span className="text-sm font-medium text-gray-600">Price:</span>
                      <p className="font-medium">${formData.price || '0'}</p>
                    </div>
                  )}
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600">Files:</span>
                  <ul className="text-sm mt-1 space-y-1">
                    <li>• Plugin: {formData.pluginFile?.name || 'Not uploaded'}</li>
                    <li>• Screenshots: {formData.screenshots.length} image(s)</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Checkbox
                  id="agreeToTerms"
                  checked={formData.agreeToTerms}
                  onCheckedChange={(checked) => handleInputChange('agreeToTerms', checked)}
                />
                <div className="space-y-1">
                  <Label htmlFor="agreeToTerms" className="text-sm font-normal">
                    I agree to the ShopHub Plugin Terms of Service *
                  </Label>
                  {errors.agreeToTerms && <p className="text-sm text-red-500">{errors.agreeToTerms}</p>}
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Checkbox
                  id="agreeToGuidelines"
                  checked={formData.agreeToGuidelines}
                  onCheckedChange={(checked) => handleInputChange('agreeToGuidelines', checked)}
                />
                <div className="space-y-1">
                  <Label htmlFor="agreeToGuidelines" className="text-sm font-normal">
                    I agree to follow the Plugin Development Guidelines *
                  </Label>
                  {errors.agreeToGuidelines && <p className="text-sm text-red-500">{errors.agreeToGuidelines}</p>}
                </div>
              </div>
            </div>

            {isSubmitting && (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span>Uploading plugin...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="w-full" />
              </div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/developers" className="flex items-center text-gray-600 hover:text-gray-900">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Developer Portal
            </Link>
            <Badge variant="outline">Plugin Submission</Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Submit Your Plugin</h1>
            <p className="text-gray-600">Share your plugin with the ShopHub community</p>
          </div>

          {/* Progress Steps */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              {steps.map((step, index) => (
                <div key={step.id} className="flex items-center">
                  <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                    currentStep >= step.id
                      ? 'bg-blue-600 border-blue-600 text-white'
                      : 'bg-white border-gray-300 text-gray-500'
                  }`}>
                    <step.icon className="h-5 w-5" />
                  </div>
                  <div className="ml-3 hidden sm:block">
                    <p className={`text-sm font-medium ${
                      currentStep >= step.id ? 'text-blue-600' : 'text-gray-500'
                    }`}>
                      {step.title}
                    </p>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`hidden sm:block w-24 h-0.5 mx-4 ${
                      currentStep > step.id ? 'bg-blue-600' : 'bg-gray-300'
                    }`} />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Form Content */}
          <Card>
            <CardContent className="p-8">
              {renderStepContent()}

              {/* Navigation Buttons */}
              <div className="flex justify-between mt-8 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={handlePrevious}
                  disabled={currentStep === 1 || isSubmitting}
                >
                  Previous
                </Button>
                <div className="flex gap-3">
                  {currentStep === steps.length ? (
                    <Button
                      onClick={handleSubmit}
                      disabled={isSubmitting}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      {isSubmitting ? 'Submitting...' : 'Submit Plugin'}
                      <CheckCircle className="ml-2 h-4 w-4" />
                    </Button>
                  ) : (
                    <Button onClick={handleNext}>
                      Next
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}