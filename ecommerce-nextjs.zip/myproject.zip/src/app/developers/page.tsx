'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Code2, 
  BookOpen, 
  Plug, 
  Palette, 
  Key, 
  Globe, 
  Users, 
  TrendingUp,
  ArrowRight,
  CheckCircle,
  Clock,
  AlertCircle
} from 'lucide-react';
import Link from 'next/link';

export default function DeveloperPortal() {
  const [stats, setStats] = useState({
    totalDevelopers: 1247,
    activePlugins: 89,
    activeThemes: 34,
    apiCalls: 2847392
  });

  const [recentSubmissions, setRecentSubmissions] = useState([
    {
      id: '1',
      name: 'Payment Gateway Pro',
      type: 'plugin',
      author: 'DevTech Solutions',
      status: 'approved',
      submittedAt: '2024-01-15'
    },
    {
      id: '2',
      name: 'Modern Minimal Theme',
      type: 'theme',
      author: 'Design Studio',
      status: 'pending',
      submittedAt: '2024-01-14'
    },
    {
      id: '3',
      name: 'Inventory Manager',
      type: 'plugin',
      author: 'LogiCore',
      status: 'approved',
      submittedAt: '2024-01-13'
    }
  ]);

  const features = [
    {
      icon: Code2,
      title: 'RESTful API',
      description: 'Complete API access to all ShopHub features with comprehensive documentation',
      color: 'text-blue-600'
    },
    {
      icon: Plug,
      title: 'Plugin Development',
      description: 'Create and sell plugins to extend ShopHub functionality',
      color: 'text-green-600'
    },
    {
      icon: Palette,
      title: 'Theme Design',
      description: 'Design and sell custom themes for ShopHub stores',
      color: 'text-purple-600'
    },
    {
      icon: Key,
      title: 'API Keys',
      description: 'Secure API key management with granular permissions',
      color: 'text-orange-600'
    },
    {
      icon: Globe,
      title: 'Webhooks',
      description: 'Real-time event notifications to your applications',
      color: 'text-indigo-600'
    },
    {
      icon: Users,
      title: 'Developer Community',
      description: 'Connect with other developers and share knowledge',
      color: 'text-pink-600'
    }
  ];

  const quickActions = [
    {
      title: 'Get API Key',
      description: 'Generate a new API key for your application',
      href: '/developers/api-keys',
      icon: Key
    },
    {
      title: 'Submit Plugin',
      description: 'Submit your plugin for review and distribution',
      href: '/developers/submit-plugin',
      icon: Plug
    },
    {
      title: 'Submit Theme',
      description: 'Submit your theme for the marketplace',
      href: '/developers/submit-theme',
      icon: Palette
    },
    {
      title: 'View Documentation',
      description: 'Comprehensive API and development guides',
      href: '/developers/docs',
      icon: BookOpen
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" /> Approved</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" /> Pending</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800"><AlertCircle className="w-3 h-3 mr-1" /> Rejected</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              ShopHub Developer Portal
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 mb-8">
              Build, integrate, and extend the ShopHub e-commerce platform
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                View Documentation
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="container mx-auto px-4 -mt-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-white shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Developers</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalDevelopers.toLocaleString()}</p>
                </div>
                <Users className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Available Plugins</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.activePlugins}</p>
                </div>
                <Plug className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Available Themes</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.activeThemes}</p>
                </div>
                <Palette className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">API Calls Today</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.apiCalls.toLocaleString()}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="api">API</TabsTrigger>
            <TabsTrigger value="marketplace">Marketplace</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            {/* Features Grid */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
                Everything You Need to Build
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {features.map((feature, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <feature.icon className={`h-8 w-8 ${feature.color} mb-2`} />
                      <CardTitle className="text-xl">{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-gray-600">
                        {feature.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Quick Actions</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {quickActions.map((action, index) => (
                  <Link key={index} href={action.href}>
                    <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <action.icon className="h-8 w-8 text-blue-600" />
                            <div>
                              <h3 className="font-semibold text-gray-900 group-hover:text-blue-600">
                                {action.title}
                              </h3>
                              <p className="text-sm text-gray-600">{action.description}</p>
                            </div>
                          </div>
                          <ArrowRight className="h-5 w-5 text-gray-400 group-hover:text-blue-600" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="api" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>API Documentation</CardTitle>
                  <CardDescription>
                    Comprehensive documentation for all API endpoints
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold">Available Endpoints:</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• Products - CRUD operations</li>
                      <li>• Orders - Management and tracking</li>
                      <li>• Customers - Customer data management</li>
                      <li>• Analytics - Sales and performance data</li>
                      <li>• Webhooks - Real-time events</li>
                    </ul>
                  </div>
                  <Button className="w-full">
                    <BookOpen className="mr-2 h-4 w-4" />
                    View Full Documentation
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>SDK & Tools</CardTitle>
                  <CardDescription>
                    Official SDKs and development tools
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold">Available SDKs:</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• JavaScript/Node.js</li>
                      <li>• Python</li>
                      <li>• PHP</li>
                      <li>• Ruby</li>
                      <li>• Go</li>
                    </ul>
                  </div>
                  <Button className="w-full" variant="outline">
                    <Code2 className="mr-2 h-4 w-4" />
                    Download SDKs
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="marketplace" className="space-y-8">
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Recent Submissions</h2>
                <Button variant="outline">View All</Button>
              </div>
              <div className="space-y-4">
                {recentSubmissions.map((submission) => (
                  <Card key={submission.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className={`p-2 rounded-lg ${
                            submission.type === 'plugin' ? 'bg-green-100' : 'bg-purple-100'
                          }`}>
                            {submission.type === 'plugin' ? 
                              <Plug className="h-6 w-6 text-green-600" /> :
                              <Palette className="h-6 w-6 text-purple-600" />
                            }
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{submission.name}</h3>
                            <p className="text-sm text-gray-600">by {submission.author}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <span className="text-sm text-gray-500">{submission.submittedAt}</span>
                          {getStatusBadge(submission.status)}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="resources" className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Getting Started</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Link href="#" className="block hover:text-blue-600">
                    <h4 className="font-medium">API Quick Start Guide</h4>
                    <p className="text-sm text-gray-600">Get up and running in 5 minutes</p>
                  </Link>
                  <Link href="#" className="block hover:text-blue-600">
                    <h4 className="font-medium">Authentication Guide</h4>
                    <p className="text-sm text-gray-600">Learn about API keys and security</p>
                  </Link>
                  <Link href="#" className="block hover:text-blue-600">
                    <h4 className="font-medium">Rate Limiting</h4>
                    <p className="text-sm text-gray-600">Understanding API limits and quotas</p>
                  </Link>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Community</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Link href="#" className="block hover:text-blue-600">
                    <h4 className="font-medium">Developer Forum</h4>
                    <p className="text-sm text-gray-600">Connect with other developers</p>
                  </Link>
                  <Link href="#" className="block hover:text-blue-600">
                    <h4 className="font-medium">Discord Community</h4>
                    <p className="text-sm text-gray-600">Real-time chat and support</p>
                  </Link>
                  <Link href="#" className="block hover:text-blue-600">
                    <h4 className="font-medium">GitHub Repository</h4>
                    <p className="text-sm text-gray-600">View source code and examples</p>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}