import { NextResponse } from 'next/server'

export function GET() {
  const robots = `User-agent: *
Allow: /

# Sitemap
Sitemap: https://shophub.com/sitemap.xml

# Crawl-delay
Crawl-delay: 1

# Disallow specific admin routes (optional)
# Disallow: /admin/
# Disallow: /api/

# Allow product pages
Allow: /produk/
Allow: /auth/

# Disallow sensitive data
Disallow: /api/
Disallow: /_next/
Disallow: /admin/`

  return new NextResponse(robots, {
    status: 200,
    headers: {
      'Content-Type': 'text/plain',
      'Cache-Control': 'public, max-age=86400, s-maxage=86400'
    }
  })
}