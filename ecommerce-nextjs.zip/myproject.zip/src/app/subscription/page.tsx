'use client'

import { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { loadStripe } from '@stripe/stripe-js'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useToast } from '@/hooks/use-toast'
import { useUser } from '@/hooks/use-user'
import { Check, Star, Zap, Shield, Headphones, Crown, Rocket, Building } from 'lucide-react'
import Link from 'next/link'

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

const plans = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    yearlyPrice: 0,
    icon: Star,
    features: [
      'Up to 10 products',
      'Basic store customization',
      'Standard analytics',
      'Community support',
      'Mobile responsive',
      'Basic SEO tools'
    ],
    limitations: [
      'No custom domain',
      'ShopHub branding',
      'Limited storage'
    ],
    color: 'from-gray-500 to-gray-600',
    popular: false
  },
  {
    id: 'starter',
    name: 'Starter',
    price: 9.99,
    yearlyPrice: 99.99,
    icon: Rocket,
    features: [
      'Up to 100 products',
      'Advanced customization',
      'Detailed analytics',
      'Email support',
      'Custom domain',
      'No ShopHub branding',
      'Advanced SEO tools',
      'Product reviews',
      'Discount coupons'
    ],
    color: 'from-blue-500 to-blue-600',
    popular: true
  },
  {
    id: 'professional',
    name: 'Professional',
    price: 29.99,
    yearlyPrice: 299.99,
    icon: Zap,
    features: [
      'Up to 1,000 products',
      'Premium themes',
      'Real-time analytics',
      'Priority support',
      'Multi-language support',
      'Multi-currency support',
      'Advanced inventory',
      'API access',
      'Custom integrations',
      'Abandoned cart recovery'
    ],
    color: 'from-purple-500 to-purple-600',
    popular: false
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 99.99,
    yearlyPrice: 999.99,
    icon: Building,
    features: [
      'Unlimited products',
      'White-label solution',
      'Custom development',
      '24/7 phone support',
      'Dedicated account manager',
      'Advanced security',
      'Custom reporting',
      'SLA guarantee',
      'Training sessions',
      'Priority feature requests'
    ],
    color: 'from-orange-500 to-orange-600',
    popular: false
  }
]

export default function SubscriptionPage() {
  const { t } = useTranslation()
  const { user } = useUser()
  const { toast } = useToast()
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly')
  const [loading, setLoading] = useState<string | null>(null)
  const [currentSubscription, setCurrentSubscription] = useState<any>(null)

  useEffect(() => {
    if (user) {
      fetchCurrentSubscription()
    }
  }, [user])

  const fetchCurrentSubscription = async () => {
    try {
      const response = await fetch(`/api/subscription?userId=${user?.id}`)
      const data = await response.json()
      setCurrentSubscription(data.subscription)
    } catch (error) {
      console.error('Failed to fetch subscription:', error)
    }
  }

  const handleSubscribe = async (planId: string) => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please login to subscribe to a plan",
        variant: "destructive"
      })
      return
    }

    setLoading(planId)
    try {
      const response = await fetch('/api/subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          planId,
          userId: user.id,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        const stripe = await stripePromise
        if (stripe) {
          const { error } = await stripe.redirectToCheckout({
            sessionId: data.sessionId,
          })
          if (error) {
            throw error
          }
        }
      } else {
        throw new Error(data.error || 'Failed to create subscription')
      }
    } catch (error: any) {
      toast({
        title: "Subscription Failed",
        description: error.message || "Failed to create subscription",
        variant: "destructive"
      })
    } finally {
      setLoading(null)
    }
  }

  const getPlanPrice = (plan: any) => {
    return billingCycle === 'yearly' ? plan.yearlyPrice : plan.price
  }

  const getPlanDisplayPrice = (plan: any) => {
    const price = getPlanPrice(plan)
    if (price === 0) return 'Free'
    return `$${price}/${billingCycle === 'yearly' ? 'year' : 'month'}`
  }

  const getYearlySavings = (plan: any) => {
    if (plan.price === 0) return 0
    const monthlyTotal = plan.price * 12
    return monthlyTotal - plan.yearlyPrice
  }

  const isCurrentPlan = (planId: string) => {
    return currentSubscription?.plan?.toLowerCase() === planId.toLowerCase()
  }

  const isPlanActive = (planId: string) => {
    return isCurrentPlan(planId) && currentSubscription?.status === 'ACTIVE'
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              {t('subscription.plans')}
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Choose the perfect plan for your business. Start free and scale as you grow.
            </p>
          </div>
        </div>
      </div>

      {/* Current Subscription Alert */}
      {currentSubscription && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Alert className="bg-green-50 border-green-200">
            <Shield className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              You are currently on the <strong>{currentSubscription.plan}</strong> plan. 
              Status: <strong>{currentSubscription.status}</strong>
              {currentSubscription.endDate && (
                <> • Renews on {new Date(currentSubscription.endDate).toLocaleDateString()}</>
              )}
            </AlertDescription>
          </Alert>
        </div>
      )}

      {/* Billing Cycle Toggle */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-center mb-8">
          <Tabs value={billingCycle} onValueChange={(value) => setBillingCycle(value as 'monthly' | 'yearly')}>
            <TabsList>
              <TabsTrigger value="monthly">Monthly</TabsTrigger>
              <TabsTrigger value="yearly">
                Yearly
                <Badge variant="secondary" className="ml-2">
                  Save 17%
                </Badge>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {plans.map((plan) => {
            const Icon = plan.icon
            const isActive = isPlanActive(plan.id)
            const isCurrent = isCurrentPlan(plan.id)
            const savings = getYearlySavings(plan)

            return (
              <Card 
                key={plan.id} 
                className={`relative overflow-hidden transition-all duration-300 hover:shadow-xl ${
                  plan.popular ? 'ring-2 ring-blue-500 scale-105' : ''
                } ${isActive ? 'ring-2 ring-green-500' : ''}`}
              >
                {plan.popular && (
                  <div className="absolute top-0 right-0 bg-blue-500 text-white px-3 py-1 text-xs font-semibold rounded-bl-lg">
                    Most Popular
                  </div>
                )}
                
                {isActive && (
                  <div className="absolute top-0 right-0 bg-green-500 text-white px-3 py-1 text-xs font-semibold rounded-bl-lg">
                    Current Plan
                  </div>
                )}

                <CardHeader className="text-center pb-4">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${plan.color} flex items-center justify-center`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                  <CardDescription className="text-3xl font-bold text-gray-900">
                    {getPlanDisplayPrice(plan)}
                  </CardDescription>
                  {billingCycle === 'yearly' && savings > 0 && (
                    <p className="text-sm text-green-600">
                      Save ${savings}/year
                    </p>
                  )}
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{feature}</span>
                      </div>
                    ))}
                    
                    {plan.limitations && plan.limitations.length > 0 && (
                      <div className="mt-4 pt-4 border-t">
                        {plan.limitations.map((limitation, index) => (
                          <div key={index} className="flex items-center space-x-2 text-gray-500">
                            <span className="w-4 h-4 text-gray-400">×</span>
                            <span className="text-sm">{limitation}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <Button 
                    className={`w-full mt-6 ${
                      plan.popular ? 'bg-blue-500 hover:bg-blue-600' : ''
                    } ${isActive ? 'bg-green-500 hover:bg-green-600' : ''}`}
                    variant={plan.popular || isActive ? 'default' : 'outline'}
                    onClick={() => handleSubscribe(plan.id)}
                    disabled={loading === plan.id || isActive}
                  >
                    {loading === plan.id ? 'Processing...' : 
                     isActive ? 'Current Plan' : 
                     plan.price === 0 ? 'Get Started' : 'Subscribe'}
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Features Comparison */}
        <div className="bg-white rounded-lg shadow-lg p-8 mb-12">
          <h2 className="text-2xl font-bold text-center mb-8">Feature Comparison</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4">Feature</th>
                  {plans.map((plan) => (
                    <th key={plan.id} className="text-center py-3 px-4">
                      {plan.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-3 px-4">Products</td>
                  <td className="text-center py-3 px-4">10</td>
                  <td className="text-center py-3 px-4">100</td>
                  <td className="text-center py-3 px-4">1,000</td>
                  <td className="text-center py-3 px-4">Unlimited</td>
                </tr>
                <tr className="border-b">
                  <td className="py-3 px-4">Custom Domain</td>
                  <td className="text-center py-3 px-4">❌</td>
                  <td className="text-center py-3 px-4">✅</td>
                  <td className="text-center py-3 px-4">✅</td>
                  <td className="text-center py-3 px-4">✅</td>
                </tr>
                <tr className="border-b">
                  <td className="py-3 px-4">Multi-language</td>
                  <td className="text-center py-3 px-4">❌</td>
                  <td className="text-center py-3 px-4">❌</td>
                  <td className="text-center py-3 px-4">✅</td>
                  <td className="text-center py-3 px-4">✅</td>
                </tr>
                <tr className="border-b">
                  <td className="py-3 px-4">API Access</td>
                  <td className="text-center py-3 px-4">❌</td>
                  <td className="text-center py-3 px-4">❌</td>
                  <td className="text-center py-3 px-4">✅</td>
                  <td className="text-center py-3 px-4">✅</td>
                </tr>
                <tr className="border-b">
                  <td className="py-3 px-4">Support</td>
                  <td className="text-center py-3 px-4">Community</td>
                  <td className="text-center py-3 px-4">Email</td>
                  <td className="text-center py-3 px-4">Priority</td>
                  <td className="text-center py-3 px-4">24/7 Phone</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="text-center mb-12">
          <h2 className="text-2xl font-bold mb-8">Frequently Asked Questions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Can I change plans anytime?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Yes! You can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Is there a free trial?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  All paid plans come with a 14-day free trial. No credit card required to start.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">What payment methods do you accept?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  We accept all major credit cards, debit cards, and PayPal payments through our secure payment processor.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Can I cancel anytime?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Yes, you can cancel your subscription at any time. Your service will continue until the end of your billing period.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg p-8 text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to get started?</h2>
          <p className="text-xl mb-6">
            Join thousands of entrepreneurs who trust ShopHub for their online business.
          </p>
          <div className="space-x-4">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/register">Start Free Trial</Link>
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-blue-600" asChild>
              <Link href="/contact">Contact Sales</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}