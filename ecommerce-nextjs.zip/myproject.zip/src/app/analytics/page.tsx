'use client'

import React, { useState, useEffect } from 'react'
import { 
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  AreaChart, Area
} from 'recharts'
import { 
  TrendingUp, Users, DollarSign, ShoppingCart, Download, Calendar,
  Package, Eye, MousePointer, ChevronDown, Filter, RefreshCw,
  FileText, FileSpreadsheet, AlertCircle, CheckCircle
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useToast } from '@/hooks/use-toast'
import { format, subDays, startOfWeek, startOfMonth, endOfWeek, endOfMonth } from 'date-fns'
import { id } from 'date-fns/locale'

// Analytics data types
interface SalesData {
  date: string
  sales: number
  orders: number
  revenue: number
}

interface ProductData {
  name: string
  sales: number
  revenue: number
  category: string
}

interface TrafficSource {
  source: string
  visitors: number
  percentage: number
  conversion: number
}

interface UserStats {
  date: string
  active: number
  new: number
  returning: number
}

// Colors for charts
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D']

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState('7d')
  const [selectedChart, setSelectedChart] = useState('all')
  const [isLoading, setIsLoading] = useState(false)
  const [exportStatus, setExportStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const { toast } = useToast()

  // Generate dummy data
  const generateSalesData = (days: number): SalesData[] => {
    const data: SalesData[] = []
    for (let i = days - 1; i >= 0; i--) {
      const date = subDays(new Date(), i)
      data.push({
        date: format(date, 'dd MMM'),
        sales: Math.floor(Math.random() * 50) + 20,
        orders: Math.floor(Math.random() * 30) + 10,
        revenue: Math.floor(Math.random() * 5000000) + 1000000
      })
    }
    return data
  }

  const generateProductData = (): ProductData[] => {
    return [
      { name: 'Laptop Gaming ROG', sales: 145, revenue: 145000000, category: 'Electronics' },
      { name: 'iPhone 15 Pro', sales: 132, revenue: 198000000, category: 'Electronics' },
      { name: 'Sepatu Nike Air Max', sales: 98, revenue: 14700000, category: 'Fashion' },
      { name: 'Tas Backpack Premium', sales: 87, revenue: 8700000, category: 'Fashion' },
      { name: 'Smartwatch Samsung', sales: 76, revenue: 45600000, category: 'Electronics' },
      { name: 'Headphone Sony WH-1000XM5', sales: 65, revenue: 32500000, category: 'Electronics' }
    ]
  }

  const generateTrafficData = (): TrafficSource[] => {
    return [
      { source: 'Google Search', visitors: 3542, percentage: 35.4, conversion: 3.2 },
      { source: 'Social Media', visitors: 2891, percentage: 28.9, conversion: 2.8 },
      { source: 'Direct', visitors: 1876, percentage: 18.8, conversion: 4.1 },
      { source: 'Email Marketing', visitors: 1234, percentage: 12.3, conversion: 5.2 },
      { source: 'Referral', visitors: 457, percentage: 4.6, conversion: 3.8 }
    ]
  }

  const generateUserStats = (days: number): UserStats[] => {
    const data: UserStats[] = []
    for (let i = days - 1; i >= 0; i--) {
      const date = subDays(new Date(), i)
      data.push({
        date: format(date, 'dd MMM'),
        active: Math.floor(Math.random() * 500) + 200,
        new: Math.floor(Math.random() * 100) + 20,
        returning: Math.floor(Math.random() * 400) + 150
      })
    }
    return data
  }

  const [salesData, setSalesData] = useState<SalesData[]>(generateSalesData(7))
  const [productData, setProductData] = useState<ProductData[]>(generateProductData())
  const [trafficData, setTrafficData] = useState<TrafficSource[]>(generateTrafficData())
  const [userStats, setUserStats] = useState<UserStats[]>(generateUserStats(7))

  // Calculate total statistics
  const totalRevenue = salesData.reduce((sum, item) => sum + item.revenue, 0)
  const totalOrders = salesData.reduce((sum, item) => sum + item.orders, 0)
  const totalSales = salesData.reduce((sum, item) => sum + item.sales, 0)
  const activeUsers = userStats.reduce((sum, item) => sum + item.active, 0) / userStats.length

  // Update data when time range changes
  useEffect(() => {
    setIsLoading(true)
    setTimeout(() => {
      const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90
      setSalesData(generateSalesData(days))
      setUserStats(generateUserStats(days))
      setIsLoading(false)
    }, 500)
  }, [timeRange])

  // Export functions
  const exportToPDF = async () => {
    setExportStatus('loading')
    try {
      const { jsPDF } = await import('jspdf')
      const autoTable = await import('jspdf-autotable')
      
      const doc = new jsPDF()
      
      // Title
      doc.setFontSize(20)
      doc.text('ShopHub Analytics Report', 20, 20)
      
      // Date range
      doc.setFontSize(12)
      doc.text(`Period: ${timeRange === '7d' ? 'Last 7 Days' : timeRange === '30d' ? 'Last 30 Days' : 'Last 90 Days'}`, 20, 30)
      doc.text(`Generated: ${format(new Date(), 'PPP', { locale: id })}`, 20, 37)
      
      // Summary Statistics
      doc.setFontSize(14)
      doc.text('Summary Statistics', 20, 50)
      doc.setFontSize(10)
      doc.text(`Total Revenue: Rp ${totalRevenue.toLocaleString('id-ID')}`, 20, 60)
      doc.text(`Total Orders: ${totalOrders}`, 20, 67)
      doc.text(`Total Sales: ${totalSales}`, 20, 74)
      doc.text(`Active Users: ${Math.round(activeUsers)}`, 20, 81)
      
      // Top Products Table
      doc.setFontSize(14)
      doc.text('Top Products', 20, 95)
      
      const tableData = productData.slice(0, 5).map(product => [
        product.name,
        product.sales.toString(),
        `Rp ${product.revenue.toLocaleString('id-ID')}`
      ])
      
      autoTable.default(doc, {
        head: [['Product Name', 'Sales', 'Revenue']],
        body: tableData,
        startY: 105,
        theme: 'grid',
        styles: { fontSize: 9 }
      })
      
      // Traffic Sources
      const finalY = (doc as any).lastAutoTable.finalY + 10
      doc.setFontSize(14)
      doc.text('Traffic Sources', 20, finalY)
      
      const trafficTableData = trafficData.map(source => [
        source.source,
        source.visitors.toString(),
        `${source.percentage}%`,
        `${source.conversion}%`
      ])
      
      autoTable.default(doc, {
        head: [['Source', 'Visitors', 'Percentage', 'Conversion']],
        body: trafficTableData,
        startY: finalY + 10,
        theme: 'grid',
        styles: { fontSize: 9 }
      })
      
      doc.save('shophub-analytics-report.pdf')
      setExportStatus('success')
      toast({
        title: "Export Successful",
        description: "PDF report has been downloaded successfully",
      })
    } catch (error) {
      setExportStatus('error')
      toast({
        title: "Export Failed",
        description: "Failed to generate PDF report",
        variant: "destructive"
      })
    }
  }

  const exportToCSV = () => {
    setExportStatus('loading')
    try {
      // Simple CSV export without external library
      const csvData = [
        ...salesData.map(item => ({
          type: 'Sales',
          date: item.date,
          sales: item.sales,
          orders: item.orders,
          revenue: item.revenue
        })),
        ...productData.map(item => ({
          type: 'Product',
          name: item.name,
          sales: item.sales,
          revenue: item.revenue,
          category: item.category
        })),
        ...trafficData.map(item => ({
          type: 'Traffic',
          source: item.source,
          visitors: item.visitors,
          percentage: item.percentage,
          conversion: item.conversion
        }))
      ]
      
      const csv = csvData.map(row => Object.values(row).join(',')).join('\n')
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
      const link = document.createElement('a')
      const url = URL.createObjectURL(blob)
      link.setAttribute('href', url)
      link.setAttribute('download', 'shophub-analytics-data.csv')
      link.style.visibility = 'hidden'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      
      setExportStatus('success')
      toast({
        title: "Export Successful",
        description: "CSV data has been downloaded successfully",
      })
    } catch (error) {
      setExportStatus('error')
      toast({
        title: "Export Failed",
        description: "Failed to generate CSV file",
        variant: "destructive"
      })
    }
  }

  const refreshData = () => {
    setIsLoading(true)
    setTimeout(() => {
      const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90
      setSalesData(generateSalesData(days))
      setProductData(generateProductData())
      setTrafficData(generateTrafficData())
      setUserStats(generateUserStats(days))
      setIsLoading(false)
      toast({
        title: "Data Refreshed",
        description: "Analytics data has been updated",
      })
    }, 1000)
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Analytics Dashboard</h1>
            <p className="text-gray-600 mt-1">Monitor your store performance and insights</p>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[140px]">
                <Calendar className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 Days</SelectItem>
                <SelectItem value="30d">Last 30 Days</SelectItem>
                <SelectItem value="90d">Last 90 Days</SelectItem>
              </SelectContent>
            </Select>
            
            <Button variant="outline" onClick={refreshData} disabled={isLoading}>
              <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            
            <Button variant="outline" onClick={exportToCSV} disabled={exportStatus === 'loading'}>
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
            
            <Button onClick={exportToPDF} disabled={exportStatus === 'loading'}>
              <FileText className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
          </div>
        </div>

        {/* Export Status Alert */}
        {exportStatus !== 'idle' && (
          <Alert className={`mb-6 ${
            exportStatus === 'success' ? 'border-green-200 bg-green-50' : 
            exportStatus === 'error' ? 'border-red-200 bg-red-50' : 
            'border-blue-200 bg-blue-50'
          }`}>
            {exportStatus === 'loading' && <AlertCircle className="h-4 w-4 text-blue-600" />}
            {exportStatus === 'success' && <CheckCircle className="h-4 w-4 text-green-600" />}
            {exportStatus === 'error' && <AlertCircle className="h-4 w-4 text-red-600" />}
            <AlertDescription>
              {exportStatus === 'loading' && 'Generating report...'}
              {exportStatus === 'success' && 'Report exported successfully!'}
              {exportStatus === 'error' && 'Failed to export report. Please try again.'}
            </AlertDescription>
          </Alert>
        )}

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">Rp {totalRevenue.toLocaleString('id-ID')}</div>
              <p className="text-xs text-muted-foreground">
                +12.5% from last period
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalOrders}</div>
              <p className="text-xs text-muted-foreground">
                +8.2% from last period
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Math.round(activeUsers)}</div>
              <p className="text-xs text-muted-foreground">
                +18.1% from last period
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3.4%</div>
              <p className="text-xs text-muted-foreground">
                +0.8% from last period
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <Tabs value={selectedChart} onValueChange={setSelectedChart} className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all">All Charts</TabsTrigger>
            <TabsTrigger value="sales">Sales</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="traffic">Traffic</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Sales Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Sales & Revenue Trend</CardTitle>
                  <CardDescription>Daily sales performance over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis yAxisId="left" />
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Legend />
                      <Area yAxisId="left" type="monotone" dataKey="sales" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} name="Sales" />
                      <Area yAxisId="right" type="monotone" dataKey="revenue" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} name="Revenue" />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* User Activity Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>User Activity</CardTitle>
                  <CardDescription>Daily active, new, and returning users</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={userStats}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="active" stroke="#8884d8" strokeWidth={2} name="Active Users" />
                      <Line type="monotone" dataKey="new" stroke="#82ca9d" strokeWidth={2} name="New Users" />
                      <Line type="monotone" dataKey="returning" stroke="#ffc658" strokeWidth={2} name="Returning Users" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Top Products */}
              <Card>
                <CardHeader>
                  <CardTitle>Top Selling Products</CardTitle>
                  <CardDescription>Best performing products by revenue</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={productData.slice(0, 5)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="revenue" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Traffic Sources */}
              <Card>
                <CardHeader>
                  <CardTitle>Traffic Sources</CardTitle>
                  <CardDescription>Visitor distribution by source</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={trafficData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ source, percentage }) => `${source}: ${percentage}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="visitors"
                      >
                        {trafficData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="sales" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Sales Trend</CardTitle>
                  <CardDescription>Daily sales performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <LineChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="sales" stroke="#8884d8" strokeWidth={2} />
                      <Line type="monotone" dataKey="orders" stroke="#82ca9d" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Revenue Analysis</CardTitle>
                  <CardDescription>Daily revenue breakdown</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <AreaChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Area type="monotone" dataKey="revenue" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="products" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Product Performance</CardTitle>
                <CardDescription>Sales and revenue by product</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={500}>
                  <BarChart data={productData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Bar yAxisId="left" dataKey="sales" fill="#8884d8" name="Units Sold" />
                    <Bar yAxisId="right" dataKey="revenue" fill="#82ca9d" name="Revenue" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="traffic" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Traffic Sources</CardTitle>
                  <CardDescription>Visitor distribution</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <PieChart>
                      <Pie
                        data={trafficData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ source, percentage }) => `${source}: ${percentage}%`}
                        outerRadius={120}
                        fill="#8884d8"
                        dataKey="visitors"
                      >
                        {trafficData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Conversion Rates</CardTitle>
                  <CardDescription>Conversion by traffic source</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <BarChart data={trafficData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="source" angle={-45} textAnchor="end" height={100} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="conversion" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}