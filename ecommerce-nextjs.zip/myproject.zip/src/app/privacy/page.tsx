'use client'

import { useTranslation } from 'react-i18next'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Shield, Eye, Database, UserCheck, Cookie, Lock } from 'lucide-react'

export default function PrivacyPage() {
  const { t } = useTranslation()

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Privacy Policy
          </h1>
          <p className="text-xl text-gray-600">
            Last updated: {new Date().toLocaleDateString()}
          </p>
        </div>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Introduction
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                ShopHub ("we," "us," or "our") is committed to protecting your privacy. 
                This Privacy Policy explains how we collect, use, disclose, and safeguard your 
                information when you visit our website and use our services.
              </p>
              <p className="mt-4">
                By using ShopHub, you consent to the data practices described in this policy. 
                If you do not agree with the terms of this privacy policy, please do not access or use our website.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Database className="w-5 h-5 mr-2" />
                Information We Collect
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-lg mb-2">Personal Information</h3>
                  <p>
                    We may collect personal information that can be used to identify you, including:
                  </p>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>Name and contact information (email, phone, address)</li>
                    <li>Account credentials (username, password)</li>
                    <li>Payment information (processed securely through third parties)</li>
                    <li>Profile information and preferences</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="font-semibold text-lg mb-2">Usage Data</h3>
                  <p>
                    We automatically collect information about how you use our Service:
                  </p>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>Pages visited and time spent on each page</li>
                    <li>Click patterns and navigation paths</li>
                    <li>Device information and browser type</li>
                    <li>IP address and location data</li>
                    <li>Cookies and similar tracking technologies</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="font-semibold text-lg mb-2">Business Information</h3>
                  <p>
                    For sellers, we may collect additional business-related information:
                  </p>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>Business registration details</li>
                    <li>Product information and inventory</li>
                    <li>Sales and transaction data</li>
                    <li>Customer service interactions</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Eye className="w-5 h-5 mr-2" />
                How We Use Your Information
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>We use the information we collect for various purposes, including:</p>
              <ul className="list-disc pl-6 mt-4 space-y-2">
                <li><strong>Service Provision:</strong> To provide, maintain, and improve our services</li>
                <li><strong>Transaction Processing:</strong> To process orders, payments, and manage customer relationships</li>
                <li><strong>Personalization:</strong> To personalize your experience and show relevant content</li>
                <li><strong>Communication:</strong> To send you transactional emails, updates, and marketing communications</li>
                <li><strong>Analytics:</strong> To analyze usage patterns and improve our platform</li>
                <li><strong>Security:</strong> To detect and prevent fraud, abuse, and security threats</li>
                <li><strong>Legal Compliance:</strong> To comply with legal obligations and protect our rights</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Cookie className="w-5 h-5 mr-2" />
                Cookies and Tracking Technologies
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                We use cookies and similar tracking technologies to track activity on our Service 
                and hold certain information. You can instruct your browser to refuse all cookies 
                or to indicate when a cookie is being sent.
              </p>
              <p className="mt-4">
                Types of cookies we use:
              </p>
              <ul className="list-disc pl-6 mt-2 space-y-1">
                <li><strong>Essential Cookies:</strong> Required for the operation of our Service</li>
                <li><strong>Performance Cookies:</strong> Help us understand how visitors interact with our Service</li>
                <li><strong>Functional Cookies:</strong> Enable enhanced functionality and personalization</li>
                <li><strong>Targeting Cookies:</strong> Used to deliver relevant advertising content</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Lock className="w-5 h-5 mr-2" />
                Data Security
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                We implement appropriate technical and organizational measures to protect your 
                personal information against unauthorized access, alteration, disclosure, or destruction.
              </p>
              <p className="mt-4">
                Security measures we employ include:
              </p>
              <ul className="list-disc pl-6 mt-2 space-y-1">
                <li>SSL/TLS encryption for data transmission</li>
                <li>Secure data storage and processing</li>
                <li>Regular security audits and assessments</li>
                <li>Access controls and authentication systems</li>
                <li>Employee training on data protection</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <UserCheck className="w-5 h-5 mr-2" />
                Your Rights
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                Depending on your location, you may have the following rights regarding your personal information:
              </p>
              <ul className="list-disc pl-6 mt-4 space-y-2">
                <li><strong>Access:</strong> Request access to your personal information</li>
                <li><strong>Correction:</strong> Request correction of inaccurate information</li>
                <li><strong>Deletion:</strong> Request deletion of your personal information</li>
                <li><strong>Portability:</strong> Request transfer of your data to another service</li>
                <li><strong>Objection:</strong> Object to processing of your information</li>
                <li><strong>Restriction:</strong> Request restriction of processing</li>
              </ul>
              <p className="mt-4">
                To exercise these rights, please contact us at privacy@shophub.com.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Third-Party Services</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                Our Service may contain links to third-party websites or services. We are not 
                responsible for the privacy practices of these third parties. We encourage you 
                to review the privacy policies of any third-party services you use.
              </p>
              <p className="mt-4">
                Third-party services we use include:
              </p>
              <ul className="list-disc pl-6 mt-2 space-y-1">
                <li>Payment processors (Stripe, PayPal, etc.)</li>
                <li>Analytics services (Google Analytics)</li>
                <li>Marketing automation platforms</li>
                <li>Customer support tools</li>
                <li>Cloud hosting providers</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Children's Privacy</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                Our Service is not intended for use by children under the age of 13. 
                We do not knowingly collect personally identifiable information from children under 13. 
                If you are a parent or guardian and you are aware that your child has provided us 
                with personal information, please contact us.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>International Data Transfers</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                Your information may be transferred to, and maintained on, computers located 
                outside of your state, province, country or other governmental jurisdiction 
                where the data protection laws may differ from those of your jurisdiction.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Changes to This Privacy Policy</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                We may update our Privacy Policy from time to time. We will notify you of any 
                changes by posting the new Privacy Policy on this page and updating the 
                "Last updated" date at the top of this policy.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Contact Us</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                If you have any questions about this Privacy Policy, please contact us:
              </p>
              <div className="mt-4 space-y-2">
                <p><strong>Email:</strong> privacy@shophub.com</p>
                <p><strong>Address:</strong> 123 Business Street, Commerce City, CC 12345</p>
                <p><strong>Phone:</strong> +1 (555) 123-4567</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}