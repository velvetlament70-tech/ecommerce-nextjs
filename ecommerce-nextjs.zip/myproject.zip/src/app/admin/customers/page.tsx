'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { 
  Search, 
  Users, 
  Mail, 
  Phone, 
  Calendar,
  MapPin,
  Eye,
  MoreHorizontal,
  TrendingUp,
  UserPlus
} from 'lucide-react'
import { AdminLayout } from '@/components/admin/admin-layout'
import { formatCurrency } from '@/lib/utils'

interface Customer {
  id: string
  name: string
  email: string
  phone: string
  address: string
  joinDate: string
  totalOrders: number
  totalSpent: number
  status: 'active' | 'inactive'
  lastOrder: string
}

export default function AdminCustomers() {
  const [customers, setCustomers] = useState<Customer[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [filteredCustomers, setFilteredCustomers] = useState<Customer[]>([])

  useEffect(() => {
    loadCustomers()
  }, [])

  useEffect(() => {
    const filtered = customers.filter(customer =>
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.phone.includes(searchTerm)
    )
    setFilteredCustomers(filtered)
  }, [searchTerm, customers])

  const loadCustomers = () => {
    // Generate dummy customers
    const dummyCustomers: Customer[] = [
      {
        id: '1',
        name: 'John Doe',
        email: 'john.doe@example.com',
        phone: '+62 812-3456-7890',
        address: 'Jl. Sudirman No. 123, Jakarta Pusat',
        joinDate: '2024-01-15',
        totalOrders: 12,
        totalSpent: 45600000,
        status: 'active',
        lastOrder: '2024-01-15'
      },
      {
        id: '2',
        name: 'Jane Smith',
        email: 'jane.smith@example.com',
        phone: '+62 813-5678-9012',
        address: 'Jl. Gatot Subroto No. 456, Jakarta Selatan',
        joinDate: '2024-01-10',
        totalOrders: 8,
        totalSpent: 23400000,
        status: 'active',
        lastOrder: '2024-01-15'
      },
      {
        id: '3',
        name: 'Bob Johnson',
        email: 'bob.johnson@example.com',
        phone: '+62 814-7890-1234',
        address: 'Jl. Thamrin No. 789, Jakarta Pusat',
        joinDate: '2023-12-20',
        totalOrders: 15,
        totalSpent: 67800000,
        status: 'active',
        lastOrder: '2024-01-14'
      },
      {
        id: '4',
        name: 'Alice Brown',
        email: 'alice.brown@example.com',
        phone: '+62 815-9012-3456',
        address: 'Jl. Kemang No. 321, Jakarta Selatan',
        joinDate: '2023-11-15',
        totalOrders: 6,
        totalSpent: 12300000,
        status: 'inactive',
        lastOrder: '2024-01-14'
      },
      {
        id: '5',
        name: 'Charlie Wilson',
        email: 'charlie.wilson@example.com',
        phone: '+62 816-2345-6789',
        address: 'Jl. Sudirman No. 654, Jakarta Pusat',
        joinDate: '2023-10-10',
        totalOrders: 3,
        totalSpent: 8900000,
        status: 'active',
        lastOrder: '2024-01-13'
      }
    ]
    setCustomers(dummyCustomers)
  }

  const stats = {
    total: customers.length,
    active: customers.filter(c => c.status === 'active').length,
    newThisMonth: customers.filter(c => {
      const joinDate = new Date(c.joinDate)
      const thisMonth = new Date()
      return joinDate.getMonth() === thisMonth.getMonth() && 
             joinDate.getFullYear() === thisMonth.getFullYear()
    }).length,
    totalRevenue: customers.reduce((sum, c) => sum + c.totalSpent, 0)
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Manajemen Pelanggan</h1>
            <p className="text-gray-500">Kelola data pelanggan dan analisis perilaku</p>
          </div>
          <Button>
            <UserPlus className="w-4 h-4 mr-2" />
            Tambah Pelanggan
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Pelanggan</p>
                  <p className="text-2xl font-bold">{stats.total}</p>
                </div>
                <Users className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Pelanggan Aktif</p>
                  <p className="text-2xl font-bold text-green-600">{stats.active}</p>
                </div>
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <div className="w-4 h-4 bg-green-600 rounded-full"></div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Pelanggan Baru</p>
                  <p className="text-2xl font-bold text-purple-600">{stats.newThisMonth}</p>
                </div>
                <UserPlus className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                  <p className="text-lg font-bold">{formatCurrency(stats.totalRevenue)}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <Card>
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Cari pelanggan berdasarkan nama, email, atau nomor HP..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Customers Table */}
        <Card>
          <CardHeader>
            <CardTitle>Daftar Pelanggan ({filteredCustomers.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3 font-medium">Pelanggan</th>
                    <th className="text-left p-3 font-medium">Kontak</th>
                    <th className="text-left p-3 font-medium">Total Pesanan</th>
                    <th className="text-left p-3 font-medium">Total Belanja</th>
                    <th className="text-left p-3 font-medium">Status</th>
                    <th className="text-left p-3 font-medium">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCustomers.map((customer) => (
                    <tr key={customer.id} className="border-b hover:bg-gray-50">
                      <td className="p-3">
                        <div>
                          <p className="font-medium">{customer.name}</p>
                          <p className="text-sm text-gray-500">Bergabung: {customer.joinDate}</p>
                          <p className="text-sm text-gray-500">Terakhir order: {customer.lastOrder}</p>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-sm">
                            <Mail className="w-3 h-3 text-gray-400" />
                            <span className="truncate max-w-[200px]">{customer.email}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Phone className="w-3 h-3 text-gray-400" />
                            <span>{customer.phone}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <MapPin className="w-3 h-3 text-gray-400" />
                            <span className="truncate max-w-[200px]">{customer.address}</span>
                          </div>
                        </div>
                      </td>
                      <td className="p-3">
                        <p className="font-medium">{customer.totalOrders} pesanan</p>
                      </td>
                      <td className="p-3">
                        <p className="font-medium">{formatCurrency(customer.totalSpent)}</p>
                      </td>
                      <td className="p-3">
                        <Badge className={`text-xs ${
                          customer.status === 'active' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {customer.status === 'active' ? 'Aktif' : 'Tidak Aktif'}
                        </Badge>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="icon">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {filteredCustomers.length === 0 && (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Tidak ada pelanggan yang ditemukan</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  )
}