'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { 
  Store, 
  Mail, 
  Phone, 
  MapPin, 
  Globe, 
  Settings,
  Save,
  Bell,
  Shield,
  Database,
  Palette
} from 'lucide-react'
import { AdminLayout } from '@/components/admin/admin-layout'

export default function AdminSettings() {
  const [storeSettings, setStoreSettings] = useState({
    name: 'TokoKu',
    email: 'support@tokoku.com',
    phone: '+62 812-3456-7890',
    address: 'Jl. Sudirman No. 123, Jakarta Pusat',
    website: 'https://tokoku.com',
    description: 'Toko online terpercaya untuk semua kebutuhan Anda'
  })

  const [notificationSettings, setNotificationSettings] = useState({
    newOrderEmail: true,
    lowStockEmail: true,
    customerRegistrationEmail: true,
    newOrderSms: false,
    lowStockSms: false
  })

  const [systemSettings, setSystemSettings] = useState({
    maintenanceMode: false,
    enableRegistration: true,
    enableGuestCheckout: true,
    currency: 'IDR',
    timezone: 'Asia/Jakarta'
  })

  const handleSaveSettings = (section: string) => {
    // Simulate saving settings
    console.log(`Saving ${section} settings`)
    // Show success message
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Pengaturan</h1>
          <p className="text-gray-500">Kelola konfigurasi toko dan sistem</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Store Settings */}
          <div className="lg:col-span-2 space-y-6">
            {/* General Store Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Store className="w-5 h-5" />
                  Pengaturan Toko
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="storeName">Nama Toko</Label>
                    <Input
                      id="storeName"
                      value={storeSettings.name}
                      onChange={(e) => setStoreSettings(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="storeEmail">Email Toko</Label>
                    <Input
                      id="storeEmail"
                      type="email"
                      value={storeSettings.email}
                      onChange={(e) => setStoreSettings(prev => ({ ...prev, email: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="storePhone">Telepon</Label>
                    <Input
                      id="storePhone"
                      value={storeSettings.phone}
                      onChange={(e) => setStoreSettings(prev => ({ ...prev, phone: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="storeWebsite">Website</Label>
                    <Input
                      id="storeWebsite"
                      value={storeSettings.website}
                      onChange={(e) => setStoreSettings(prev => ({ ...prev, website: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="storeAddress">Alamat</Label>
                  <Textarea
                    id="storeAddress"
                    value={storeSettings.address}
                    onChange={(e) => setStoreSettings(prev => ({ ...prev, address: e.target.value }))}
                    rows={2}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="storeDescription">Deskripsi Toko</Label>
                  <Textarea
                    id="storeDescription"
                    value={storeSettings.description}
                    onChange={(e) => setStoreSettings(prev => ({ ...prev, description: e.target.value }))}
                    rows={3}
                  />
                </div>

                <div className="flex justify-end">
                  <Button onClick={() => handleSaveSettings('store')}>
                    <Save className="w-4 h-4 mr-2" />
                    Simpan Pengaturan Toko
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Notification Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Pengaturan Notifikasi
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-3">Notifikasi Email</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Pesanan Baru</p>
                        <p className="text-sm text-gray-500">Terima email saat ada pesanan baru</p>
                      </div>
                      <Switch
                        checked={notificationSettings.newOrderEmail}
                        onCheckedChange={(checked) => 
                          setNotificationSettings(prev => ({ ...prev, newOrderEmail: checked }))
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Stok Menipis</p>
                        <p className="text-sm text-gray-500">Terima email saat stok produk menipis</p>
                      </div>
                      <Switch
                        checked={notificationSettings.lowStockEmail}
                        onCheckedChange={(checked) => 
                          setNotificationSettings(prev => ({ ...prev, lowStockEmail: checked }))
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Pendaftaran Pelanggan Baru</p>
                        <p className="text-sm text-gray-500">Terima email saat ada pelanggan baru mendaftar</p>
                      </div>
                      <Switch
                        checked={notificationSettings.customerRegistrationEmail}
                        onCheckedChange={(checked) => 
                          setNotificationSettings(prev => ({ ...prev, customerRegistrationEmail: checked }))
                        }
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-3">Notifikasi SMS</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Pesanan Baru</p>
                        <p className="text-sm text-gray-500">Terima SMS saat ada pesanan baru</p>
                      </div>
                      <Switch
                        checked={notificationSettings.newOrderSms}
                        onCheckedChange={(checked) => 
                          setNotificationSettings(prev => ({ ...prev, newOrderSms: checked }))
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Stok Menipis</p>
                        <p className="text-sm text-gray-500">Terima SMS saat stok produk menipis</p>
                      </div>
                      <Switch
                        checked={notificationSettings.lowStockSms}
                        onCheckedChange={(checked) => 
                          setNotificationSettings(prev => ({ ...prev, lowStockSms: checked }))
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button onClick={() => handleSaveSettings('notifications')}>
                    <Save className="w-4 h-4 mr-2" />
                    Simpan Pengaturan Notifikasi
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* System Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Pengaturan Sistem
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Mode Maintenance</p>
                      <p className="text-sm text-gray-500">Tutup toko sementara untuk maintenance</p>
                    </div>
                    <Switch
                      checked={systemSettings.maintenanceMode}
                      onCheckedChange={(checked) => 
                        setSystemSettings(prev => ({ ...prev, maintenanceMode: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Pendaftaran Pengguna</p>
                      <p className="text-sm text-gray-500">Izinkan pengguna baru mendaftar</p>
                    </div>
                    <Switch
                      checked={systemSettings.enableRegistration}
                      onCheckedChange={(checked) => 
                        setSystemSettings(prev => ({ ...prev, enableRegistration: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Checkout untuk Tamu</p>
                      <p className="text-sm text-gray-500">Izinkan checkout tanpa login</p>
                    </div>
                    <Switch
                      checked={systemSettings.enableGuestCheckout}
                      onCheckedChange={(checked) => 
                        setSystemSettings(prev => ({ ...prev, enableGuestCheckout: checked }))
                      }
                    />
                  </div>
                </div>

                <Separator />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="currency">Mata Uang</Label>
                    <select
                      id="currency"
                      value={systemSettings.currency}
                      onChange={(e) => setSystemSettings(prev => ({ ...prev, currency: e.target.value }))}
                      className="w-full p-2 border rounded-md"
                    >
                      <option value="IDR">Indonesian Rupiah (IDR)</option>
                      <option value="USD">US Dollar (USD)</option>
                      <option value="EUR">Euro (EUR)</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timezone">Zona Waktu</Label>
                    <select
                      id="timezone"
                      value={systemSettings.timezone}
                      onChange={(e) => setSystemSettings(prev => ({ ...prev, timezone: e.target.value }))}
                      className="w-full p-2 border rounded-md"
                    >
                      <option value="Asia/Jakarta">Asia/Jakarta (WIB)</option>
                      <option value="Asia/Makassar">Asia/Makassar (WITA)</option>
                      <option value="Asia/Jayapura">Asia/Jayapura (WIT)</option>
                    </select>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button onClick={() => handleSaveSettings('system')}>
                    <Save className="w-4 h-4 mr-2" />
                    Simpan Pengaturan Sistem
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Statistik Cepat</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Versi Sistem</span>
                  <Badge variant="secondary">v1.0.0</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Status Server</span>
                  <Badge className="bg-green-100 text-green-800">Online</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Database</span>
                  <Badge className="bg-green-100 text-green-800">Connected</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Storage</span>
                  <span className="text-sm">2.3 GB / 10 GB</span>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Aksi Cepat</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <Database className="w-4 h-4 mr-2" />
                  Backup Database
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Shield className="w-4 h-4 mr-2" />
                  Security Check
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Palette className="w-4 h-4 mr-2" />
                  Customize Theme
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Globe className="w-4 h-4 mr-2" />
                  Clear Cache
                </Button>
              </CardContent>
            </Card>

            {/* System Info */}
            <Card>
              <CardHeader>
                <CardTitle>Informasi Sistem</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">PHP Version</span>
                  <span>8.2.0</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Node.js</span>
                  <span>18.17.0</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Next.js</span>
                  <span>15.0.0</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Uptime</span>
                  <span>99.9%</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}