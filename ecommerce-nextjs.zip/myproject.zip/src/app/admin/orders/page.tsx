'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Search, 
  Filter, 
  Eye, 
  Truck, 
  CheckCircle, 
  XCircle,
  Clock,
  Package,
  Calendar,
  User,
  Phone,
  MapPin,
  CreditCard,
  MoreHorizontal,
  Download
} from 'lucide-react'
import { AdminLayout } from '@/components/admin/admin-layout'
import { formatCurrency } from '@/lib/utils'
import { OrderDetailDialog } from '@/components/admin/order-detail-dialog'

interface OrderItem {
  id: string
  name: string
  price: number
  quantity: number
  image: string
}

interface Order {
  id: string
  orderNumber: string
  customerName: string
  customerEmail: string
  customerPhone: string
  customerAddress: string
  items: OrderItem[]
  subtotal: number
  shipping: number
  tax: number
  total: number
  paymentMethod: string
  status: 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled'
  createdAt: string
  notes?: string
}

export default function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>([])
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)

  useEffect(() => {
    loadOrders()
  }, [])

  useEffect(() => {
    let filtered = orders

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(order =>
        order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customerEmail.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Filter by status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(order => order.status === statusFilter)
    }

    setFilteredOrders(filtered)
  }, [searchTerm, statusFilter, orders])

  const loadOrders = () => {
    // Load from localStorage or use default data
    const savedOrders = localStorage.getItem('adminOrders')
    if (savedOrders) {
      setOrders(JSON.parse(savedOrders))
    } else {
      // Generate dummy orders
      const dummyOrders: Order[] = [
        {
          id: '1',
          orderNumber: 'ORD-20240115-1234',
          customerName: 'John Doe',
          customerEmail: 'john.doe@example.com',
          customerPhone: '+62 812-3456-7890',
          customerAddress: 'Jl. Sudirman No. 123, Jakarta Pusat',
          items: [
            {
              id: '1',
              name: 'Laptop Gaming ASUS ROG',
              price: 15000000,
              quantity: 1,
              image: 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=400'
            },
            {
              id: '2',
              name: 'Headphone Sony WH-1000XM4',
              price: 4500000,
              quantity: 1,
              image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400'
            }
          ],
          subtotal: 19500000,
          shipping: 0,
          tax: 2145000,
          total: 21645000,
          paymentMethod: 'transfer',
          status: 'completed',
          createdAt: '2024-01-15',
          notes: 'Harap dikirim sebelum jam 5 sore'
        },
        {
          id: '2',
          orderNumber: 'ORD-20240115-1235',
          customerName: 'Jane Smith',
          customerEmail: 'jane.smith@example.com',
          customerPhone: '+62 813-5678-9012',
          customerAddress: 'Jl. Gatot Subroto No. 456, Jakarta Selatan',
          items: [
            {
              id: '3',
              name: 'Smartphone Samsung Galaxy S24',
              price: 12000000,
              quantity: 1,
              image: 'https://images.unsplash.com/photo-1580910051074-3eb694886505?w=400'
            }
          ],
          subtotal: 12000000,
          shipping: 15000,
          tax: 1320000,
          total: 13335000,
          paymentMethod: 'ewallet',
          status: 'processing',
          createdAt: '2024-01-15'
        },
        {
          id: '3',
          orderNumber: 'ORD-20240114-1236',
          customerName: 'Bob Johnson',
          customerEmail: 'bob.johnson@example.com',
          customerPhone: '+62 814-7890-1234',
          customerAddress: 'Jl. Thamrin No. 789, Jakarta Pusat',
          items: [
            {
              id: '4',
              name: 'Smartwatch Apple Watch Series 9',
              price: 6500000,
              quantity: 2,
              image: 'https://images.unsplash.com/photo-1551816230-ef5deaed4a26?w=400'
            }
          ],
          subtotal: 13000000,
          shipping: 0,
          tax: 1430000,
          total: 14430000,
          paymentMethod: 'cod',
          status: 'pending',
          createdAt: '2024-01-14'
        },
        {
          id: '4',
          orderNumber: 'ORD-20240114-1237',
          customerName: 'Alice Brown',
          customerEmail: 'alice.brown@example.com',
          customerPhone: '+62 815-9012-3456',
          customerAddress: 'Jl. Kemang No. 321, Jakarta Selatan',
          items: [
            {
              id: '5',
              name: 'Tablet iPad Pro 12.9"',
              price: 18000000,
              quantity: 1,
              image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400'
            }
          ],
          subtotal: 18000000,
          shipping: 15000,
          tax: 1980000,
          total: 19995000,
          paymentMethod: 'transfer',
          status: 'shipped',
          createdAt: '2024-01-14'
        },
        {
          id: '5',
          orderNumber: 'ORD-20240113-1238',
          customerName: 'Charlie Wilson',
          customerEmail: 'charlie.wilson@example.com',
          customerPhone: '+62 816-2345-6789',
          customerAddress: 'Jl. Sudirman No. 654, Jakarta Pusat',
          items: [
            {
              id: '1',
              name: 'Laptop Gaming ASUS ROG',
              price: 15000000,
              quantity: 1,
              image: 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=400'
            }
          ],
          subtotal: 15000000,
          shipping: 15000,
          tax: 1650000,
          total: 16665000,
          paymentMethod: 'ewallet',
          status: 'cancelled',
          createdAt: '2024-01-13',
          notes: 'Pembeli membatalkan pesanan'
        }
      ]
      setOrders(dummyOrders)
      localStorage.setItem('adminOrders', JSON.stringify(dummyOrders))
    }
  }

  const updateOrderStatus = (orderId: string, newStatus: Order['status']) => {
    const updatedOrders = orders.map(order =>
      order.id === orderId ? { ...order, status: newStatus } : order
    )
    setOrders(updatedOrders)
    localStorage.setItem('adminOrders', JSON.stringify(updatedOrders))
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800'
      case 'processing':
        return 'bg-blue-100 text-blue-800'
      case 'shipped':
        return 'bg-purple-100 text-purple-800'
      case 'completed':
        return 'bg-green-100 text-green-800'
      case 'cancelled':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Menunggu Pembayaran'
      case 'processing':
        return 'Diproses'
      case 'shipped':
        return 'Dikirim'
      case 'completed':
        return 'Selesai'
      case 'cancelled':
        return 'Dibatalkan'
      default:
        return status
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4" />
      case 'processing':
        return <Package className="w-4 h-4" />
      case 'shipped':
        return <Truck className="w-4 h-4" />
      case 'completed':
        return <CheckCircle className="w-4 h-4" />
      case 'cancelled':
        return <XCircle className="w-4 h-4" />
      default:
        return null
    }
  }

  const getPaymentMethodText = (method: string) => {
    switch (method) {
      case 'transfer':
        return 'Transfer Bank'
      case 'ewallet':
        return 'E-Wallet'
      case 'cod':
        return 'COD'
      default:
        return method
    }
  }

  const getStatusActions = (status: string, orderId: string) => {
    const actions = []
    
    switch (status) {
      case 'pending':
        actions.push(
          <Button
            key="process"
            size="sm"
            onClick={() => updateOrderStatus(orderId, 'processing')}
          >
            Proses
          </Button>,
          <Button
            key="cancel"
            size="sm"
            variant="destructive"
            onClick={() => updateOrderStatus(orderId, 'cancelled')}
          >
            Batalkan
          </Button>
        )
        break
      case 'processing':
        actions.push(
          <Button
            key="ship"
            size="sm"
            onClick={() => updateOrderStatus(orderId, 'shipped')}
          >
            Kirim
          </Button>,
          <Button
            key="cancel"
            size="sm"
            variant="destructive"
            onClick={() => updateOrderStatus(orderId, 'cancelled')}
          >
            Batalkan
          </Button>
        )
        break
      case 'shipped':
        actions.push(
          <Button
            key="complete"
            size="sm"
            onClick={() => updateOrderStatus(orderId, 'completed')}
          >
            Selesai
          </Button>
        )
        break
    }
    
    return actions
  }

  const stats = {
    total: orders.length,
    pending: orders.filter(o => o.status === 'pending').length,
    processing: orders.filter(o => o.status === 'processing').length,
    completed: orders.filter(o => o.status === 'completed').length,
    totalRevenue: orders
      .filter(o => o.status === 'completed')
      .reduce((sum, o) => sum + o.total, 0)
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Manajemen Pesanan</h1>
            <p className="text-gray-500">Kelola semua pesanan pelanggan</p>
          </div>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Data
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Pesanan</p>
                  <p className="text-2xl font-bold">{stats.total}</p>
                </div>
                <Package className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Menunggu</p>
                  <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
                </div>
                <Clock className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Diproses</p>
                  <p className="text-2xl font-bold text-blue-600">{stats.processing}</p>
                </div>
                <Package className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Selesai</p>
                  <p className="text-2xl font-bold text-green-600">{stats.completed}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                  <p className="text-lg font-bold">{formatCurrency(stats.totalRevenue)}</p>
                </div>
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 font-bold text-sm">Rp</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filter */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Cari pesanan berdasarkan nomor, nama, atau email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Filter Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Status</SelectItem>
                  <SelectItem value="pending">Menunggu</SelectItem>
                  <SelectItem value="processing">Diproses</SelectItem>
                  <SelectItem value="shipped">Dikirim</SelectItem>
                  <SelectItem value="completed">Selesai</SelectItem>
                  <SelectItem value="cancelled">Dibatalkan</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Orders Table */}
        <Card>
          <CardHeader>
            <CardTitle>Daftar Pesanan ({filteredOrders.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3 font-medium">Pesanan</th>
                    <th className="text-left p-3 font-medium">Pelanggan</th>
                    <th className="text-left p-3 font-medium">Total</th>
                    <th className="text-left p-3 font-medium">Metode</th>
                    <th className="text-left p-3 font-medium">Status</th>
                    <th className="text-left p-3 font-medium">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOrders.map((order) => (
                    <tr key={order.id} className="border-b hover:bg-gray-50">
                      <td className="p-3">
                        <div>
                          <p className="font-medium">{order.orderNumber}</p>
                          <p className="text-sm text-gray-500">{order.createdAt}</p>
                        </div>
                      </td>
                      <td className="p-3">
                        <div>
                          <p className="font-medium">{order.customerName}</p>
                          <p className="text-sm text-gray-500">{order.customerEmail}</p>
                        </div>
                      </td>
                      <td className="p-3">
                        <p className="font-medium">{formatCurrency(order.total)}</p>
                        <p className="text-sm text-gray-500">{order.items.length} item</p>
                      </td>
                      <td className="p-3">
                        <Badge variant="outline" className="text-xs">
                          {getPaymentMethodText(order.paymentMethod)}
                        </Badge>
                      </td>
                      <td className="p-3">
                        <Badge className={`text-xs ${getStatusColor(order.status)}`}>
                          <div className="flex items-center gap-1">
                            {getStatusIcon(order.status)}
                            {getStatusText(order.status)}
                          </div>
                        </Badge>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setSelectedOrder(order)
                              setIsDetailDialogOpen(true)
                            }}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          {getStatusActions(order.status, order.id)}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {filteredOrders.length === 0 && (
                <div className="text-center py-12">
                  <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Tidak ada pesanan yang ditemukan</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Order Detail Dialog */}
      <OrderDetailDialog
        open={isDetailDialogOpen}
        onOpenChange={setIsDetailDialogOpen}
        order={selectedOrder}
        onUpdateStatus={updateOrderStatus}
      />
    </AdminLayout>
  )
}