import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ShieldX, ArrowLeft } from "lucide-react"

export default function UnauthorizedPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <ShieldX className="mx-auto h-16 w-16 text-red-500 mb-4" />
          <CardTitle className="text-2xl font-bold text-gray-900">
            Akses Ditolak
          </CardTitle>
          <CardDescription>
            Anda tidak memiliki izin untuk mengakses halaman ini.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-gray-600">
            Halaman ini memerlukan izin khusus. Silakan hubungi administrator jika Anda merasa ini adalah kesalahan.
          </p>
          <div className="space-y-2">
            <Button asChild className="w-full">
              <Link href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Kembali ke Beranda
              </Link>
            </Button>
            <Button variant="outline" asChild className="w-full">
              <Link href="/auth/signin">
                Masuk dengan Akun Lain
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}