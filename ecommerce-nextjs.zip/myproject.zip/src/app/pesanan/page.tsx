'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Package, 
  Search, 
  Calendar, 
  Truck, 
  CheckCircle, 
  Clock, 
  XCircle,
  ExternalLink,
  RefreshCw,
  Filter,
  Eye,
  Download,
  CreditCard
} from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

interface Order {
  id: string
  orderNumber: string
  status: 'PENDING' | 'CONFIRMED' | 'PROCESSING' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED' | 'REFUNDED'
  paymentStatus: 'PENDING' | 'PAID' | 'FAILED' | 'EXPIRED' | 'REFUNDED' | 'PARTIALLY_REFUNDED'
  paymentMethod: string
  paymentGateway: string
  total: number
  currency: string
  shippingName: string
  shippingEmail: string
  shippingPhone: string
  shippingAddress: string
  shippingCity: string
  shippingCountry: string
  notes?: string
  items: OrderItem[]
  transactions: Transaction[]
  createdAt: string
  updatedAt: string
  paidAt?: string
  expiredAt?: string
}

interface OrderItem {
  id: string
  productName: string
  productSku: string
  price: number
  quantity: number
}

interface Transaction {
  id: string
  transactionNumber: string
  status: 'PENDING' | 'PROCESSING' | 'SUCCESS' | 'FAILED' | 'CANCELLED' | 'EXPIRED'
  amount: number
  paymentMethod: string
  paymentGateway: string
  paymentUrl?: string
  externalId?: string
  processedAt?: string
  createdAt: string
}

export default function PesananPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [showDetailModal, setShowDetailModal] = useState(false)

  useEffect(() => {
    loadOrders()
  }, [])

  useEffect(() => {
    filterOrders()
  }, [orders, searchTerm, statusFilter])

  const loadOrders = async () => {
    setLoading(true)
    try {
      // Mock data for demonstration
      const mockOrders: Order[] = [
        {
          id: '1',
          orderNumber: 'ORD-20241014-1234',
          status: 'DELIVERED',
          paymentStatus: 'PAID',
          paymentMethod: 'E_WALLET',
          paymentGateway: 'midtrans',
          total: 1250000,
          currency: 'IDR',
          shippingName: 'John Doe',
          shippingEmail: 'john@example.com',
          shippingPhone: '+62812345678',
          shippingAddress: '{"street":"Jl. Sudirman No. 123","city":"Jakarta","province":"DKI Jakarta","postalCode":"12345"}',
          shippingCity: 'Jakarta',
          shippingCountry: 'Indonesia',
          items: [
            {
              id: '1',
              productName: 'Laptop Gaming Pro',
              productSku: 'LTP-001',
              price: 1200000,
              quantity: 1
            }
          ],
          transactions: [
            {
              id: '1',
              transactionNumber: 'TRX-123456-ABC',
              status: 'SUCCESS',
              amount: 1250000,
              paymentMethod: 'E_WALLET',
              paymentGateway: 'midtrans',
              externalId: 'midtrans-123',
              processedAt: '2024-10-14T10:30:00Z',
              createdAt: '2024-10-14T10:00:00Z'
            }
          ],
          createdAt: '2024-10-14T10:00:00Z',
          updatedAt: '2024-10-14T15:30:00Z',
          paidAt: '2024-10-14T10:30:00Z'
        },
        {
          id: '2',
          orderNumber: 'ORD-20241013-5678',
          status: 'PROCESSING',
          paymentStatus: 'PAID',
          paymentMethod: 'BANK_TRANSFER',
          paymentGateway: 'midtrans',
          total: 850000,
          currency: 'IDR',
          shippingName: 'Jane Smith',
          shippingEmail: 'jane@example.com',
          shippingPhone: '+62887654321',
          shippingAddress: '{"street":"Jl. Thamrin No. 456","city":"Bandung","province":"Jawa Barat","postalCode":"40111"}',
          shippingCity: 'Bandung',
          shippingCountry: 'Indonesia',
          items: [
            {
              id: '2',
              productName: 'Smartphone Premium',
              productSku: 'PHN-002',
              price: 850000,
              quantity: 1
            }
          ],
          transactions: [
            {
              id: '2',
              transactionNumber: 'TRX-234567-DEF',
              status: 'SUCCESS',
              amount: 850000,
              paymentMethod: 'BANK_TRANSFER',
              paymentGateway: 'midtrans',
              externalId: 'midtrans-456',
              processedAt: '2024-10-13T14:20:00Z',
              createdAt: '2024-10-13T14:00:00Z'
            }
          ],
          createdAt: '2024-10-13T14:00:00Z',
          updatedAt: '2024-10-14T09:15:00Z',
          paidAt: '2024-10-13T14:20:00Z'
        },
        {
          id: '3',
          orderNumber: 'ORD-20241012-9012',
          status: 'PENDING',
          paymentStatus: 'PENDING',
          paymentMethod: 'QR_CODE',
          paymentGateway: 'midtrans',
          total: 550000,
          currency: 'IDR',
          shippingName: 'Bob Johnson',
          shippingEmail: 'bob@example.com',
          shippingPhone: '+62899887766',
          shippingAddress: '{"street":"Jl. Gatot Subroto No. 789","city":"Surabaya","province":"Jawa Timur","postalCode":"60211"}',
          shippingCity: 'Surabaya',
          shippingCountry: 'Indonesia',
          items: [
            {
              id: '3',
              productName: 'Wireless Headphone',
              productSku: 'AUD-003',
              price: 550000,
              quantity: 1
            }
          ],
          transactions: [
            {
              id: '3',
              transactionNumber: 'TRX-345678-GHI',
              status: 'PENDING',
              amount: 550000,
              paymentMethod: 'QR_CODE',
              paymentGateway: 'midtrans',
              paymentUrl: 'https://app.sandbox.midtrans.com/payment/345',
              externalId: 'midtrans-789',
              createdAt: '2024-10-12T16:45:00Z'
            }
          ],
          createdAt: '2024-10-12T16:45:00Z',
          updatedAt: '2024-10-12T16:45:00Z',
          expiredAt: '2024-10-13T16:45:00Z'
        }
      ]

      setOrders(mockOrders)
    } catch (error) {
      console.error('Error loading orders:', error)
    } finally {
      setLoading(false)
    }
  }

  const filterOrders = () => {
    let filtered = orders

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(order =>
        order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.shippingName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.shippingEmail.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Filter by status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(order => order.status === statusFilter)
    }

    setFilteredOrders(filtered)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING': return 'bg-yellow-100 text-yellow-800'
      case 'CONFIRMED': return 'bg-blue-100 text-blue-800'
      case 'PROCESSING': return 'bg-purple-100 text-purple-800'
      case 'SHIPPED': return 'bg-indigo-100 text-indigo-800'
      case 'DELIVERED': return 'bg-green-100 text-green-800'
      case 'CANCELLED': return 'bg-red-100 text-red-800'
      case 'REFUNDED': return 'bg-gray-100 text-gray-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'PAID': return 'bg-green-100 text-green-800'
      case 'PENDING': return 'bg-yellow-100 text-yellow-800'
      case 'FAILED': return 'bg-red-100 text-red-800'
      case 'EXPIRED': return 'bg-orange-100 text-orange-800'
      case 'REFUNDED': return 'bg-gray-100 text-gray-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PENDING': return <Clock className="w-4 h-4" />
      case 'CONFIRMED': return <CheckCircle className="w-4 h-4" />
      case 'PROCESSING': return <RefreshCw className="w-4 h-4" />
      case 'SHIPPED': return <Truck className="w-4 h-4" />
      case 'DELIVERED': return <CheckCircle className="w-4 h-4" />
      case 'CANCELLED': return <XCircle className="w-4 h-4" />
      case 'REFUNDED': return <RefreshCw className="w-4 h-4" />
      default: return <Package className="w-4 h-4" />
    }
  }

  const handlePaymentAction = (order: Order) => {
    const transaction = order.transactions[0]
    if (transaction?.paymentUrl) {
      window.open(transaction.paymentUrl, '_blank')
    }
  }

  const handleViewDetail = (order: Order) => {
    setSelectedOrder(order)
    setShowDetailModal(true)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Pesanan Saya</h1>
          <p className="text-gray-600">Kelola dan lacak semua pesanan Anda</p>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Cari nomor pesanan atau nama..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="sm:w-48">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Status</SelectItem>
                    <SelectItem value="PENDING">Menunggu</SelectItem>
                    <SelectItem value="CONFIRMED">Dikonfirmasi</SelectItem>
                    <SelectItem value="PROCESSING">Diproses</SelectItem>
                    <SelectItem value="SHIPPED">Dikirim</SelectItem>
                    <SelectItem value="DELIVERED">Terkirim</SelectItem>
                    <SelectItem value="CANCELLED">Dibatalkan</SelectItem>
                    <SelectItem value="REFUNDED">Dikembalikan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Orders List */}
        {filteredOrders.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {searchTerm || statusFilter !== 'all' ? 'Tidak ada pesanan ditemukan' : 'Belum ada pesanan'}
              </h3>
              <p className="text-gray-600 mb-4">
                {searchTerm || statusFilter !== 'all' 
                  ? 'Coba ubah filter atau kata kunci pencarian' 
                  : 'Mulai berbelanja untuk membuat pesanan pertama Anda'
                }
              </p>
              {(!searchTerm && statusFilter === 'all') && (
                <Button onClick={() => window.location.href = '/'}>
                  Mulai Belanja
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredOrders.map((order) => (
              <Card key={order.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  {/* Order Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                    <div className="mb-2 sm:mb-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-lg">{order.orderNumber}</h3>
                        <Badge className={getStatusColor(order.status)}>
                          <div className="flex items-center gap-1">
                            {getStatusIcon(order.status)}
                            <span className="text-xs">
                              {order.status === 'PENDING' && 'Menunggu'}
                              {order.status === 'CONFIRMED' && 'Dikonfirmasi'}
                              {order.status === 'PROCESSING' && 'Diproses'}
                              {order.status === 'SHIPPED' && 'Dikirim'}
                              {order.status === 'DELIVERED' && 'Terkirim'}
                              {order.status === 'CANCELLED' && 'Dibatalkan'}
                              {order.status === 'REFUNDED' && 'Dikembalikan'}
                            </span>
                          </div>
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">
                        {new Date(order.createdAt).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'long',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getPaymentStatusColor(order.paymentStatus)}>
                        <CreditCard className="w-3 h-3 mr-1" />
                        {order.paymentStatus === 'PAID' && 'Dibayar'}
                        {order.paymentStatus === 'PENDING' && 'Menunggu Pembayaran'}
                        {order.paymentStatus === 'FAILED' && 'Gagal'}
                        {order.paymentStatus === 'EXPIRED' && 'Kadaluarsa'}
                        {order.paymentStatus === 'REFUNDED' && 'Dikembalikan'}
                      </Badge>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewDetail(order)}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Detail
                      </Button>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  {/* Order Items */}
                  <div className="mb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Package className="w-4 h-4 text-gray-500" />
                      <span className="text-sm font-medium">Produk ({order.items.length})</span>
                    </div>
                    <div className="space-y-2">
                      {order.items.map((item, index) => (
                        <div key={item.id} className="flex justify-between items-center text-sm">
                          <div className="flex-1">
                            <p className="font-medium">{item.productName}</p>
                            <p className="text-gray-500">SKU: {item.productSku}</p>
                          </div>
                          <div className="text-right">
                            <p>{item.quantity} x {formatCurrency(item.price)}</p>
                            <p className="font-medium">{formatCurrency(item.price * item.quantity)}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator className="my-4" />

                  {/* Order Footer */}
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div className="mb-2 sm:mb-0">
                      <p className="text-sm text-gray-600">
                        Metode: {order.paymentMethod.replace('_', ' ')} • {order.paymentGateway.toUpperCase()}
                      </p>
                      <p className="text-sm text-gray-600">
                        Pengiriman: {order.shippingCity}, {order.shippingCountry}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">Total Pembayaran</p>
                      <p className="text-xl font-bold text-purple-600">
                        {formatCurrency(order.total)}
                      </p>
                    </div>
                  </div>

                  {/* Payment Action for Pending Orders */}
                  {order.paymentStatus === 'PENDING' && order.transactions[0]?.paymentUrl && (
                    <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-yellow-600" />
                          <span className="text-sm text-yellow-800">
                            Menunggu pembayaran • Kadaluarsa: {order.expiredAt ? 
                              new Date(order.expiredAt).toLocaleString('id-ID') : 
                              '24 jam'
                            }
                          </span>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => handlePaymentAction(order)}
                          className="bg-yellow-600 hover:bg-yellow-700"
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Bayar Sekarang
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Order Detail Modal */}
        {showDetailModal && selectedOrder && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">Detail Pesanan</h2>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowDetailModal(false)}
                  >
                    <XCircle className="w-5 h-5" />
                  </Button>
                </div>

                <div className="space-y-4">
                  {/* Order Info */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Nomor Pesanan</p>
                      <p className="font-medium">{selectedOrder.orderNumber}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Tanggal</p>
                      <p className="font-medium">
                        {new Date(selectedOrder.createdAt).toLocaleDateString('id-ID')}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Status</p>
                      <Badge className={getStatusColor(selectedOrder.status)}>
                        {selectedOrder.status}
                      </Badge>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Status Pembayaran</p>
                      <Badge className={getPaymentStatusColor(selectedOrder.paymentStatus)}>
                        {selectedOrder.paymentStatus}
                      </Badge>
                    </div>
                  </div>

                  <Separator />

                  {/* Shipping Info */}
                  <div>
                    <h3 className="font-medium mb-2">Informasi Pengiriman</h3>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="font-medium">{selectedOrder.shippingName}</p>
                      <p className="text-sm text-gray-600">{selectedOrder.shippingEmail}</p>
                      <p className="text-sm text-gray-600">{selectedOrder.shippingPhone}</p>
                      <p className="text-sm text-gray-600 mt-1">
                        {JSON.parse(selectedOrder.shippingAddress).street}, {selectedOrder.shippingCity}
                      </p>
                    </div>
                  </div>

                  <Separator />

                  {/* Transaction Info */}
                  {selectedOrder.transactions.length > 0 && (
                    <div>
                      <h3 className="font-medium mb-2">Informasi Pembayaran</h3>
                      {selectedOrder.transactions.map((transaction) => (
                        <div key={transaction.id} className="bg-gray-50 p-3 rounded-lg">
                          <div className="flex justify-between items-center">
                            <div>
                              <p className="font-medium">{transaction.transactionNumber}</p>
                              <p className="text-sm text-gray-600">
                                {transaction.paymentGateway.toUpperCase()} • {transaction.paymentMethod.replace('_', ' ')}
                              </p>
                              <p className="text-sm text-gray-600">
                                {new Date(transaction.createdAt).toLocaleString('id-ID')}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">{formatCurrency(transaction.amount)}</p>
                              <Badge className={getPaymentStatusColor(transaction.status)}>
                                {transaction.status}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <Separator />

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1">
                      <Download className="w-4 h-4 mr-2" />
                      Download Invoice
                    </Button>
                    {selectedOrder.paymentStatus === 'PENDING' && selectedOrder.transactions[0]?.paymentUrl && (
                      <Button className="flex-1" onClick={() => handlePaymentAction(selectedOrder)}>
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Bayar Sekarang
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}