'use client'

import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useToast } from '@/hooks/use-toast'
import { Mail, Phone, MapPin, MessageSquare, Send, CheckCircle } from 'lucide-react'

export default function ContactPage() {
  const { t } = useTranslation()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    category: '',
    message: ''
  })

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // Here you would normally send the data to your backend
      console.log('Contact form submitted:', formData)
      
      setIsSubmitted(true)
      toast({
        title: "Message Sent Successfully",
        description: "We'll get back to you within 24 hours.",
      })
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        subject: '',
        category: '',
        message: ''
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const contactInfo = [
    {
      icon: Mail,
      title: 'Email Support',
      details: ['support@shophub.com', 'Response within 24 hours'],
      action: 'mailto:support@shophub.com'
    },
    {
      icon: Phone,
      title: 'Phone Support',
      details: ['+1 (555) 123-4567', 'Mon-Fri, 9AM-6PM EST'],
      action: 'tel:+15551234567'
    },
    {
      icon: MapPin,
      title: 'Office Address',
      details: ['123 Business Street', 'Commerce City, CC 12345', 'United States'],
      action: '#'
    }
  ]

  const helpCategories = [
    {
      title: 'Technical Support',
      description: 'Issues with platform functionality, bugs, or technical problems',
      icon: '🔧'
    },
    {
      title: 'Account Issues',
      description: 'Login problems, account settings, billing inquiries',
      icon: '👤'
    },
    {
      title: 'Seller Support',
      description: 'Product listings, inventory, payments, store management',
      icon: '🏪'
    },
    {
      title: 'Partnerships',
      description: 'Business partnerships, integrations, enterprise solutions',
      icon: '🤝'
    },
    {
      title: 'Legal & Compliance',
      description: 'Privacy policy, terms of service, legal inquiries',
      icon: '⚖️'
    },
    {
      title: 'Feedback & Suggestions',
      description: 'Feature requests, improvement ideas, user feedback',
      icon: '💡'
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Contact Us
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We're here to help! Whether you have a question, need support, or want to share feedback, 
            our team is ready to assist you.
          </p>
        </div>

        {/* Contact Information Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {contactInfo.map((info, index) => {
            const Icon = info.icon
            return (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
                    <Icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-lg">{info.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {info.details.map((detail, idx) => (
                      <p key={idx} className="text-gray-600">{detail}</p>
                    ))}
                  </div>
                  {info.action !== '#' && (
                    <Button 
                      variant="outline" 
                      className="mt-4 w-full"
                      onClick={() => window.location.href = info.action}
                    >
                      {info.icon === Mail ? 'Send Email' : info.icon === Phone ? 'Call Now' : 'Get Directions'}
                    </Button>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Help Categories */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-center mb-8">How can we help you?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {helpCategories.map((category, index) => (
              <Card 
                key={index} 
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => handleInputChange('category', category.title)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="text-2xl">{category.icon}</div>
                    <div>
                      <h3 className="font-semibold text-lg mb-2">{category.title}</h3>
                      <p className="text-gray-600 text-sm">{category.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageSquare className="w-5 h-5 mr-2" />
                Send us a Message
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isSubmitted ? (
                <div className="text-center py-8">
                  <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Message Sent!</h3>
                  <p className="text-gray-600">
                    Thank you for contacting us. We'll get back to you within 24 hours.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Name *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        required
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        required
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        {helpCategories.map((category) => (
                          <SelectItem key={category.title} value={category.title}>
                            {category.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="subject">Subject *</Label>
                    <Input
                      id="subject"
                      value={formData.subject}
                      onChange={(e) => handleInputChange('subject', e.target.value)}
                      required
                      placeholder="Brief description of your inquiry"
                    />
                  </div>

                  <div>
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => handleInputChange('message', e.target.value)}
                      required
                      rows={6}
                      placeholder="Please provide as much detail as possible..."
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Send Message
                      </>
                    )}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>

          {/* FAQ Section */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Frequently Asked Questions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">How quickly will I receive a response?</h4>
                  <p className="text-gray-600 text-sm">
                    We typically respond to all inquiries within 24 hours during business days. 
                    Urgent technical issues are prioritized and may receive faster responses.
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Do you offer phone support?</h4>
                  <p className="text-gray-600 text-sm">
                    Yes, phone support is available for Premium and Enterprise customers 
                    Monday through Friday, 9AM-6PM EST. Standard plan customers can request 
                    a callback through our contact form.
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Can I schedule a demo or consultation?</h4>
                  <p className="text-gray-600 text-sm">
                    Absolutely! We offer personalized demos for businesses interested in our 
                    Professional and Enterprise plans. Please select "Partnerships" as your 
                    category and mention demo request in your message.
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">What technical information should I include?</h4>
                  <p className="text-gray-600 text-sm">
                    For technical issues, please include your browser type, operating system, 
                    error messages you're seeing, and steps to reproduce the issue. Screenshots 
                    are very helpful!
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">How do I report a security issue?</h4>
                  <p className="text-gray-600 text-sm">
                    For security-related concerns, please email security@shophub.com directly. 
                    We take all security reports seriously and will respond promptly.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Business Hours */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Business Hours</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Monday - Friday</span>
                    <span className="font-semibold">9:00 AM - 6:00 PM EST</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Saturday</span>
                    <span className="font-semibold">10:00 AM - 4:00 PM EST</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sunday</span>
                    <span className="font-semibold">Closed</span>
                  </div>
                </div>
                <Alert className="mt-4">
                  <AlertDescription>
                    Emergency support is available 24/7 for Enterprise customers experiencing 
                    critical service disruptions.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Live Chat Banner */}
        <Card className="mt-12 bg-gradient-to-r from-blue-500 to-purple-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Need Immediate Help?</h3>
            <p className="text-lg mb-6">
              Start a live chat with our support team for instant assistance with pressing issues.
            </p>
            <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100">
              Start Live Chat
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}