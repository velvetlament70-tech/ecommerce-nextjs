'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel'
import { 
  Star, 
  ArrowRight,
  Truck,
  Shield,
  RefreshCw,
  Headphones,
  Sparkles,
  TrendingUp,
  Clock,
  Store,
  Users,
  ShoppingCart,
  Package,
  CheckCircle,
  Zap,
  Globe,
  Heart,
  Mail,
  Phone,
  MapPin
} from 'lucide-react'
import { productService } from '@/lib/products'
import { ProductGrid } from '@/components/product/product-card'
import { BrandTagline } from '@/components/BrandTagline'
import { TestimonialsSection } from '@/components/TestimonialsSection'
import { NewsletterForm } from '@/components/NewsletterForm'
import { AnimatedSection, AnimatedCard, StaggerContainer, StaggerItem } from '@/components/animations/AnimatedComponents'
import { motion } from 'framer-motion'
import { BRAND_CONFIG } from '@/lib/brand'

export default function Home() {
  const { data: session } = useSession()
  const [featuredProducts, setFeaturedProducts] = useState<any[]>([])
  const [newArrivals, setNewArrivals] = useState<any[]>([])
  const [bestSellers, setBestSellers] = useState<any[]>([])
  const [categories, setCategories] = useState<any[]>([])

  useEffect(() => {
    // Load data from product service
    setFeaturedProducts(productService.getFeaturedProducts(4))
    setNewArrivals(productService.getNewArrivals(4))
    setBestSellers(productService.getBestSellers(4))
    setCategories(productService.getAllCategories())
  }, [])

  const banners = [
    {
      title: 'Platform E-Commerce Terpercaya',
      subtitle: 'Untuk Bisnis Modern',
      description: 'Buka toko online Anda sendiri atau belanja produk berkualitas dari ribuan penjual terpercaya',
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1200&h=600&fit=crop',
      bgColor: 'bg-gradient-to-r from-blue-600 to-teal-600',
      cta: 'Mulai Sekarang',
      ctaLink: session ? '/produk' : '/auth/signup'
    },
    {
      title: 'Dashboard Multi-User',
      subtitle: 'Customer, Seller & Admin',
      description: 'Kelola bisnis Anda dengan tools lengkap dan analitik real-time',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&h=600&fit=crop',
      bgColor: 'bg-gradient-to-r from-purple-600 to-pink-600',
      cta: 'Coba Demo',
      ctaLink: '/auth/signin'
    }
  ]

  const features = [
    {
      icon: Store,
      title: 'Buka Toko Online',
      description: 'Mudah buka toko sendiri dengan dashboard lengkap',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: ShoppingCart,
      title: 'Belanja Aman',
      description: 'Pembayaran terjamin dengan sistem escrow',
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: Users,
      title: 'Multi-User',
      description: 'Support Customer, Seller, dan Admin',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: Package,
      title: 'Kelola Produk',
      description: 'Inventory management dan tracking real-time',
      color: 'from-orange-500 to-red-500'
    },
    {
      icon: TrendingUp,
      title: 'Analitik Bisnis',
      description: 'Laporan penjualan dan insight lengkap',
      color: 'from-indigo-500 to-purple-500'
    },
    {
      icon: Shield,
      title: 'Keamanan Terjamin',
      description: 'Data encryption dan fraud protection',
      color: 'from-teal-500 to-green-500'
    }
  ]

  const stats = [
    { label: 'Toko Aktif', value: '10,000+', icon: Store },
    { label: 'Produk Terjual', value: '500K+', icon: Package },
    { label: 'Pengguna Terdaftar', value: '50K+', icon: Users },
    { label: 'Transaksi Sukses', value: '1M+', icon: TrendingUp }
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Banner */}
      <AnimatedSection>
        <section className="relative">
          <Carousel className="w-full">
            <CarouselContent>
              {banners.map((banner, index) => (
                <CarouselItem key={index}>
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.8 }}
                    className={`relative h-96 md:h-[600px] ${banner.bgColor}`}
                  >
                    <img
                      src={banner.image}
                      alt={banner.title}
                      className="absolute inset-0 w-full h-full object-cover opacity-20"
                    />
                    <div className="relative container mx-auto px-4 h-full flex items-center">
                      <motion.div 
                        initial={{ opacity: 0, x: -50 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.8, delay: 0.2 }}
                        className="max-w-3xl text-white"
                      >
                        <Badge className="mb-6 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white border-white/30">
                          <Sparkles className="w-4 h-4 mr-2" />
                          {BRAND_CONFIG.tagline}
                        </Badge>
                        <h1 className="text-4xl md:text-7xl font-bold mb-6 leading-tight">
                          {banner.title}
                        </h1>
                        <h2 className="text-xl md:text-3xl mb-6 opacity-90 font-medium">
                          {banner.subtitle}
                        </h2>
                        <p className="text-lg md:text-xl mb-8 opacity-80 leading-relaxed">
                          {banner.description}
                        </p>
                        <motion.div
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="flex flex-wrap gap-4"
                        >
                          <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-100 shadow-xl text-lg px-8 py-6" asChild>
                            <Link href={banner.ctaLink}>
                              {banner.cta}
                              <ArrowRight className="w-6 h-6 ml-2" />
                            </Link>
                          </Button>
                          <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-gray-900 text-lg px-8 py-6">
                            <Play className="w-6 h-6 mr-2" />
                            Lihat Demo
                          </Button>
                        </motion.div>
                      </motion.div>
                    </div>
                  </motion.div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="left-4" />
            <CarouselNext className="right-4" />
          </Carousel>
        </section>
      </AnimatedSection>

      {/* Stats Section */}
      <AnimatedSection delay={0.2}>
        <section className="py-12 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
          <div className="container mx-auto px-4">
            <StaggerContainer className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <StaggerItem key={index}>
                  <AnimatedCard>
                    <Card className="text-center p-6 bg-white dark:bg-gray-800 shadow-lg hover:shadow-xl">
                      <stat.icon className="w-8 h-8 mx-auto mb-3 text-blue-600" />
                      <div className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-1">
                        {stat.value}
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {stat.label}
                      </div>
                    </Card>
                  </AnimatedCard>
                </StaggerItem>
              ))}
            </StaggerContainer>
          </div>
        </section>
      </AnimatedSection>

      {/* Features Grid */}
      <AnimatedSection delay={0.4}>
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-200">
                <Zap className="w-3 h-3 mr-1" />
                Fitur Unggulan
              </Badge>
              <h2 className="text-3xl md:text-5xl font-bold mb-6">
                Platform E-Commerce Lengkap
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Semua yang Anda butuhkan untuk memulai dan mengembangkan bisnis online Anda
              </p>
            </div>

            <StaggerContainer className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <StaggerItem key={index}>
                  <AnimatedCard>
                    <Card className="h-full p-8 hover:shadow-2xl transition-all duration-300 border-0 bg-gradient-to-br from-white to-gray-50 dark:from-gray-800 dark:to-gray-900">
                      <div className={`w-16 h-16 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center mb-6 shadow-lg`}>
                        <feature.icon className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-xl font-bold mb-4">{feature.title}</h3>
                      <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                        {feature.description}
                      </p>
                      <div className="mt-6">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      </div>
                    </Card>
                  </AnimatedCard>
                </StaggerItem>
              ))}
            </StaggerContainer>
          </div>
        </section>
      </AnimatedSection>

      {/* Multi-User System Showcase */}
      <AnimatedSection delay={0.6}>
        <section className="py-20 bg-gradient-to-br from-blue-50 via-white to-purple-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <Badge className="mb-4 bg-purple-100 text-purple-800 hover:bg-purple-200">
                <Users className="w-3 h-3 mr-1" />
                Sistem Multi-User
              </Badge>
              <h2 className="text-3xl md:text-5xl font-bold mb-6">
                Platform untuk Semua Role
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Didesain untuk mendukung Customer, Seller, dan Admin dengan fitur khusus untuk setiap role
              </p>
            </div>

            <StaggerContainer className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <StaggerItem>
                <AnimatedCard>
                  <Card className="h-full hover:shadow-2xl transition-all duration-300 border-0 bg-gradient-to-br from-green-50 to-emerald-50">
                    <CardContent className="p-8">
                      <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                        <ShoppingCart className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold mb-4">Customer</h3>
                      <p className="text-gray-600 mb-6 leading-relaxed">
                        Belanja produk berkualitas dari berbagai toko terpercaya dengan pengalaman terbaik
                      </p>
                      <ul className="space-y-3 mb-8">
                        {['Bebas biaya kirim', 'Pembayaran aman', 'Ulasan produk', 'Tracking real-time'].map((item) => (
                          <li key={item} className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                      {!session ? (
                        <Button className="w-full bg-green-600 hover:bg-green-700 text-lg py-6" asChild>
                          <Link href="/auth/signup">
                            <ShoppingCart className="w-5 h-5 mr-2" />
                            Mulai Belanja
                          </Link>
                        </Button>
                      ) : session.user.role === "CUSTOMER" ? (
                        <Button className="w-full bg-green-600 hover:bg-green-700 text-lg py-6" asChild>
                          <Link href="/produk">
                            <ShoppingCart className="w-5 h-5 mr-2" />
                            Lanjut Belanja
                          </Link>
                        </Button>
                      ) : null}
                    </CardContent>
                  </Card>
                </AnimatedCard>
              </StaggerItem>

              <StaggerItem>
                <AnimatedCard>
                  <Card className="h-full hover:shadow-2xl transition-all duration-300 border-0 bg-gradient-to-br from-blue-50 to-indigo-50">
                    <CardContent className="p-8">
                      <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                        <Store className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold mb-4">Seller</h3>
                      <p className="text-gray-600 mb-6 leading-relaxed">
                        Kelola toko online Anda dengan dashboard lengkap dan tools analitik canggih
                      </p>
                      <ul className="space-y-3 mb-8">
                        {['Dashboard lengkap', 'Kelola produk mudah', 'Analisis penjualan', 'Promosi otomatis'].map((item) => (
                          <li key={item} className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-blue-500 flex-shrink-0" />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                      {session?.user.role === "SELLER" ? (
                        <Button className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-6" asChild>
                          <Link href="/seller/dashboard">
                            <Store className="w-5 h-5 mr-2" />
                            Dashboard Seller
                          </Link>
                        </Button>
                      ) : (
                        <Button className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-6" asChild>
                          <Link href="/buat-toko">
                            <Store className="w-5 h-5 mr-2" />
                            Daftar Seller
                          </Link>
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                </AnimatedCard>
              </StaggerItem>

              <StaggerItem>
                <AnimatedCard>
                  <Card className="h-full hover:shadow-2xl transition-all duration-300 border-0 bg-gradient-to-br from-purple-50 to-pink-50">
                    <CardContent className="p-8">
                      <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                        <Users className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold mb-4">Administrator</h3>
                      <p className="text-gray-600 mb-6 leading-relaxed">
                        Kelola seluruh platform dengan tools admin yang powerful dan intuitif
                      </p>
                      <ul className="space-y-3 mb-8">
                        {['Kelola pengguna', 'Verifikasi toko', 'Laporan lengkap', 'System monitoring'].map((item) => (
                          <li key={item} className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-purple-500 flex-shrink-0" />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                      {session?.user.role === "ADMIN" ? (
                        <Button className="w-full bg-purple-600 hover:bg-purple-700 text-lg py-6" asChild>
                          <Link href="/admin/dashboard">
                            <Users className="w-5 h-5 mr-2" />
                            Admin Panel
                          </Link>
                        </Button>
                      ) : (
                        <Button className="w-full bg-gray-400 hover:bg-gray-500 text-lg py-6" disabled>
                          <Users className="w-5 h-5 mr-2" />
                          Admin Only
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                </AnimatedCard>
              </StaggerItem>
            </StaggerContainer>

            {/* Demo Accounts Info */}
            <div className="mt-16">
              <Card className="max-w-4xl mx-auto bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200 shadow-xl">
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <h4 className="text-xl font-bold text-blue-900 mb-2">Coba Platform Sekarang!</h4>
                    <p className="text-blue-700">
                      Gunakan akun demo untuk体验 semua fitur tanpa registrasi
                    </p>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white p-6 rounded-xl shadow-md border border-green-200">
                      <div className="flex items-center gap-3 mb-3">
                        <ShoppingCart className="w-6 h-6 text-green-600" />
                        <div className="font-bold text-green-700">Customer</div>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <div>Email: customer@example.com</div>
                        <div>Password: password123</div>
                      </div>
                    </div>
                    <div className="bg-white p-6 rounded-xl shadow-md border border-blue-200">
                      <div className="flex items-center gap-3 mb-3">
                        <Store className="w-6 h-6 text-blue-600" />
                        <div className="font-bold text-blue-700">Seller</div>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <div>Email: seller@example.com</div>
                        <div>Password: password123</div>
                      </div>
                    </div>
                    <div className="bg-white p-6 rounded-xl shadow-md border border-purple-200">
                      <div className="flex items-center gap-3 mb-3">
                        <Users className="w-6 h-6 text-purple-600" />
                        <div className="font-bold text-purple-700">Admin</div>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <div>Email: admin@example.com</div>
                        <div>Password: password123</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </AnimatedSection>

      {/* Newsletter Section */}
      <AnimatedSection delay={0.8}>
        <section className="py-20 bg-gradient-to-br from-blue-600 to-purple-600">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center text-white">
              <Badge className="mb-6 bg-white/20 hover:bg-white/30 text-white border-white/30">
                <Mail className="w-3 h-3 mr-1" />
                Newsletter
              </Badge>
              <h2 className="text-3xl md:text-5xl font-bold mb-6">
                Dapatkan Update Terbaru
              </h2>
              <p className="text-lg mb-8 opacity-90">
                Bergabung dengan newsletter kami untuk mendapatkan tips, promo, dan update fitur terbaru
              </p>
              <NewsletterForm />
            </div>
          </div>
        </section>
      </AnimatedSection>

      {/* Testimonials */}
      <AnimatedSection delay={1.0}>
        <section className="py-20">
          <div className="container mx-auto px-4">
            <TestimonialsSection />
          </div>
        </section>
      </AnimatedSection>

      {/* CTA Section */}
      <AnimatedSection delay={1.2}>
        <section className="py-20 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
          <div className="container mx-auto px-4">
            <Card className="max-w-4xl mx-auto bg-gradient-to-r from-blue-600 to-purple-600 border-0 shadow-2xl">
              <CardContent className="p-12 text-center text-white">
                <h2 className="text-3xl md:text-4xl font-bold mb-6">
                  Siap Memulai Bisnis Online Anda?
                </h2>
                <p className="text-lg mb-8 opacity-90">
                  Bergabung dengan ribuan pengguna yang sudah mempercayai {BRAND_CONFIG.name}
                </p>
                <div className="flex flex-wrap gap-4 justify-center">
                  <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-100 text-lg px-8 py-6" asChild>
                    <Link href="/auth/signup">
                      <Rocket className="w-6 h-6 mr-2" />
                      Daftar Gratis
                    </Link>
                  </Button>
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-gray-900 text-lg px-8 py-6" asChild>
                    <Link href="/auth/signin">
                      <Users className="w-6 h-6 mr-2" />
                      Masuk Demo
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </AnimatedSection>
    </div>
  )
}

function Play({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"
      />
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
      />
    </svg>
  )
}

function Rocket({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M13 10V3L4 14h7v7l9-11h-7z"
      />
    </svg>
  )
}