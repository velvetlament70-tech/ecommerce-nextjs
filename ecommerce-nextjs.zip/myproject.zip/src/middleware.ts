import { withAuth } from "next-auth/middleware"
import { NextResponse } from "next/server"

export default withAuth(
  function middleware(req) {
    const token = req.nextauth.token
    const isAdmin = token?.role === "ADMIN"
    const isSeller = token?.role === "SELLER"
    const isCustomer = token?.role === "CUSTOMER"

    // Admin routes
    if (req.nextUrl.pathname.startsWith("/admin")) {
      if (!isAdmin) {
        return NextResponse.redirect(new URL("/unauthorized", req.url))
      }
    }

    // Seller routes
    if (req.nextUrl.pathname.startsWith("/seller")) {
      if (!isSeller && !isAdmin) {
        return NextResponse.redirect(new URL("/unauthorized", req.url))
      }
    }

    // Store creation route - only for sellers without stores
    if (req.nextUrl.pathname.startsWith("/buat-toko")) {
      if (isSeller && token?.storeId) {
        return NextResponse.redirect(new URL("/seller/dashboard", req.url))
      }
      if (isCustomer) {
        return NextResponse.redirect(new URL("/auth/signin?callbackUrl=/buat-toko", req.url))
      }
    }

    return NextResponse.next()
  },
  {
    callbacks: {
      authorized: ({ token }) => !!token
    }
  }
)

export const config = {
  matcher: [
    "/admin/:path*",
    "/seller/:path*",
    "/buat-toko/:path*",
    "/api/stores/:path*",
    "/api/admin/:path*"
  ]
}