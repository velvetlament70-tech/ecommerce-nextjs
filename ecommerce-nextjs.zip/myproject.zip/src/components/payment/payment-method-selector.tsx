'use client'

import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { 
  CreditCard, 
  Smartphone, 
  Building, 
  Truck, 
  QrCode,
  Store,
  CheckCircle
} from 'lucide-react'

export interface PaymentMethod {
  id: string
  name: string
  type: 'E_WALLET' | 'BANK_TRANSFER' | 'CASH_ON_DELIVERY' | 'QR_CODE' | 'RETAIL_OUTLET'
  gateway: 'midtrans' | 'xendit' | 'stripe'
  icon: React.ReactNode
  description: string
  fee?: number
  popular?: boolean
  disabled?: boolean
}

const PAYMENT_METHODS: PaymentMethod[] = [
  // E-wallets
  {
    id: 'gopay',
    name: 'GoPay',
    type: 'E_WALLET',
    gateway: 'midtrans',
    icon: <Smartphone className="w-5 h-5" />,
    description: 'Bayar instan dengan GoPay',
    popular: true
  },
  {
    id: 'ovo',
    name: 'OVO',
    type: 'E_WALLET',
    gateway: 'midtrans',
    icon: <Smartphone className="w-5 h-5" />,
    description: 'Bayar instan dengan OVO',
    popular: true
  },
  {
    id: 'dana',
    name: 'DANA',
    type: 'E_WALLET',
    gateway: 'midtrans',
    icon: <Smartphone className="w-5 h-5" />,
    description: 'Bayar instan dengan DANA'
  },
  {
    id: 'shopeepay',
    name: 'ShopeePay',
    type: 'E_WALLET',
    gateway: 'midtrans',
    icon: <Smartphone className="w-5 h-5" />,
    description: 'Bayar instan dengan ShopeePay'
  },
  
  // Bank Transfers
  {
    id: 'bca_va',
    name: 'BCA Virtual Account',
    type: 'BANK_TRANSFER',
    gateway: 'midtrans',
    icon: <Building className="w-5 h-5" />,
    description: 'Transfer ke Virtual Account BCA',
    popular: true
  },
  {
    id: 'bni_va',
    name: 'BNI Virtual Account',
    type: 'BANK_TRANSFER',
    gateway: 'midtrans',
    icon: <Building className="w-5 h-5" />,
    description: 'Transfer ke Virtual Account BNI'
  },
  {
    id: 'bri_va',
    name: 'BRI Virtual Account',
    type: 'BANK_TRANSFER',
    gateway: 'midtrans',
    icon: <Building className="w-5 h-5" />,
    description: 'Transfer ke Virtual Account BRI'
  },
  {
    id: 'mandiri_va',
    name: 'Mandiri Virtual Account',
    type: 'BANK_TRANSFER',
    gateway: 'midtrans',
    icon: <Building className="w-5 h-5" />,
    description: 'Transfer ke Virtual Account Mandiri'
  },
  
  // QR Codes
  {
    id: 'qris',
    name: 'QRIS',
    type: 'QR_CODE',
    gateway: 'midtrans',
    icon: <QrCode className="w-5 h-5" />,
    description: 'Scan QR dengan aplikasi pembayaran',
    popular: true
  },
  
  // Retail Outlets
  {
    id: 'alfamart',
    name: 'Alfamart',
    type: 'RETAIL_OUTLET',
    gateway: 'midtrans',
    icon: <Store className="w-5 h-5" />,
    description: 'Bayar di gerai Alfamart terdekat'
  },
  {
    id: 'indomaret',
    name: 'Indomaret',
    type: 'RETAIL_OUTLET',
    gateway: 'midtrans',
    icon: <Store className="w-5 h-5" />,
    description: 'Bayar di gerai Indomaret terdekat'
  },
  
  // Cash on Delivery
  {
    id: 'cod',
    name: 'Cash on Delivery (COD)',
    type: 'CASH_ON_DELIVERY',
    gateway: 'midtrans',
    icon: <Truck className="w-5 h-5" />,
    description: 'Bayar saat pesanan tiba',
    fee: 5000
  }
]

interface PaymentMethodSelectorProps {
  selectedMethod: string
  onMethodChange: (method: string) => void
  amount: number
}

export function PaymentMethodSelector({ 
  selectedMethod, 
  onMethodChange, 
  amount 
}: PaymentMethodSelectorProps) {
  const [filter, setFilter] = useState<string>('all')

  const filteredMethods = filter === 'all' 
    ? PAYMENT_METHODS 
    : PAYMENT_METHODS.filter(method => method.type === filter)

  const selectedPaymentMethod = PAYMENT_METHODS.find(method => method.id === selectedMethod)
  const totalFee = selectedPaymentMethod?.fee || 0
  const totalAmount = amount + totalFee

  const filterButtons = [
    { value: 'all', label: 'Semua' },
    { value: 'E_WALLET', label: 'E-Wallet' },
    { value: 'BANK_TRANSFER', label: 'Transfer Bank' },
    { value: 'QR_CODE', label: 'QR Code' },
    { value: 'RETAIL_OUTLET', label: 'Toko Retail' },
    { value: 'CASH_ON_DELIVERY', label: 'COD' }
  ]

  return (
    <div className="space-y-6">
      {/* Filter Buttons */}
      <div className="flex flex-wrap gap-2">
        {filterButtons.map((button) => (
          <Button
            key={button.value}
            variant={filter === button.value ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter(button.value)}
            className="text-xs"
          >
            {button.label}
          </Button>
        ))}
      </div>

      {/* Payment Methods */}
      <RadioGroup value={selectedMethod} onValueChange={onMethodChange}>
        <div className="grid gap-3">
          {filteredMethods.map((method) => (
            <Card 
              key={method.id}
              className={`cursor-pointer transition-all hover:shadow-md ${
                selectedMethod === method.id 
                  ? 'ring-2 ring-purple-600 border-purple-600' 
                  : 'hover:border-gray-300'
              } ${method.disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <RadioGroupItem 
                    value={method.id} 
                    id={method.id}
                    disabled={method.disabled}
                  />
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-100">
                      {method.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <Label 
                          htmlFor={method.id} 
                          className="font-medium cursor-pointer"
                        >
                          {method.name}
                        </Label>
                        {method.popular && (
                          <Badge variant="secondary" className="text-xs">
                            Populer
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600">
                        {method.description}
                      </p>
                      {method.fee && method.fee > 0 && (
                        <p className="text-xs text-orange-600">
                          Biaya layanan: Rp{method.fee.toLocaleString('id-ID')}
                        </p>
                      )}
                    </div>
                  </div>
                  {selectedMethod === method.id && (
                    <CheckCircle className="w-5 h-5 text-purple-600" />
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </RadioGroup>

      {/* Fee Summary */}
      {selectedPaymentMethod && (
        <Card className="bg-purple-50 border-purple-200">
          <CardContent className="p-4">
            <h4 className="font-medium text-purple-900 mb-3">Detail Pembayaran</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal:</span>
                <span className="font-medium">
                  Rp{amount.toLocaleString('id-ID')}
                </span>
              </div>
              {totalFee > 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Biaya Layanan:</span>
                  <span className="font-medium text-orange-600">
                    +Rp{totalFee.toLocaleString('id-ID')}
                  </span>
                </div>
              )}
              <div className="flex justify-between pt-2 border-t border-purple-200">
                <span className="font-semibold text-purple-900">Total:</span>
                <span className="font-bold text-purple-900 text-lg">
                  Rp{totalAmount.toLocaleString('id-ID')}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}