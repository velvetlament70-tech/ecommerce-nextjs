import React from 'react';

interface BrandTaglineProps {
  className?: string;
}

export function BrandTagline({ className = '' }: BrandTaglineProps) {
  return (
    <div className={`text-center space-y-2 ${className}`}>
      <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">
        Your Premium Shopping Destination
      </h2>
      <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
        Discover curated collections, exclusive deals, and exceptional service. 
        Shop with confidence and style.
      </p>
    </div>
  );
}