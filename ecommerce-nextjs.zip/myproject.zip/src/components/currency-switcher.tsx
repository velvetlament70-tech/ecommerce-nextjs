'use client'

import { useCurrency } from '@/hooks/use-currency'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { DollarSign } from 'lucide-react'

export function CurrencySwitcher() {
  const { currency, setCurrency, currencies, loading } = useCurrency()

  const currentCurrency = currencies.find(c => c.code === currency) || currencies[0]

  if (loading) {
    return (
      <Button variant="outline" size="sm" disabled>
        <DollarSign className="h-4 w-4 mr-2" />
        Loading...
      </Button>
    )
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm">
          <DollarSign className="h-4 w-4 mr-2" />
          <span className="hidden sm:inline">{currency}</span>
          <span className="sm:hidden">{currentCurrency.symbol}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {currencies.map((curr) => (
          <DropdownMenuItem
            key={curr.code}
            onClick={() => setCurrency(curr.code)}
            className={currency === curr.code ? 'bg-accent' : ''}
          >
            <span className="mr-2">{curr.symbol}</span>
            <span className="mr-2">{curr.code}</span>
            <span className="text-muted-foreground">{curr.name}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}