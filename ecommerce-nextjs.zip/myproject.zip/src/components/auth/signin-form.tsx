"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { FormValidator, useFormValidation } from "@/lib/form-validation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Eye, EyeOff, Store, User, Shield } from "lucide-react"

interface SignInFormProps {
  redirectTo?: string
}

export function SignInForm({ redirectTo }: SignInFormProps) {
  const { login, isLoading } = useAuth()
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")

  const {
    formData,
    errors,
    touched,
    isSubmitting,
    isValid,
    handleChange,
    handleBlur,
    handleSubmit
  } = useFormValidation({
    initialValues: {
      email: "",
      password: ""
    },
    validationRules: {
      email: FormValidator.COMMON_RULES.email,
      password: {
        required: true,
        minLength: 6,
        maxLength: 100
      }
    },
    onSubmit: async (data) => {
      setError("")
      const success = await login(data.email, data.password)
      if (!success) {
        setError("Login failed. Please check your credentials.")
      }
    }
  })

  const getFieldError = (fieldName: string) => {
    if (touched[fieldName] && errors[fieldName]) {
      return errors[fieldName][0]
    }
    return ""
  }

  const hasFieldError = (fieldName: string) => {
    return touched[fieldName] && errors[fieldName] && errors[fieldName].length > 0
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <div className="flex justify-center mb-4">
          <Store className="h-12 w-12 text-primary" />
        </div>
        <CardTitle className="text-2xl">Sign In</CardTitle>
        <CardDescription>
          Enter your credentials to access your account
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleChange("email", e.target.value)}
              onBlur={() => handleBlur("email")}
              placeholder="Enter your email"
              className={hasFieldError("email") ? "border-red-500" : ""}
              disabled={isLoading || isSubmitting}
              required
            />
            {hasFieldError("email") && (
              <p className="text-sm text-red-500">{getFieldError("email")}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Input
                id="password"
                name="password"
                type={showPassword ? "text" : "password"}
                value={formData.password}
                onChange={(e) => handleChange("password", e.target.value)}
                onBlur={() => handleBlur("password")}
                placeholder="Enter your password"
                className={hasFieldError("password") ? "border-red-500 pr-10" : "pr-10"}
                disabled={isLoading || isSubmitting}
                required
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowPassword(!showPassword)}
                disabled={isLoading || isSubmitting}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </Button>
            </div>
            {hasFieldError("password") && (
              <p className="text-sm text-red-500">{getFieldError("password")}</p>
            )}
          </div>

          <div className="bg-blue-50 p-3 rounded-lg">
            <p className="text-sm text-blue-800">
              <strong>Demo Accounts:</strong><br />
              Customer: customer@example.com<br />
              Seller: seller@example.com<br />
              Admin: admin@example.com<br />
              Password: password123
            </p>
          </div>
        </CardContent>
        <CardFooter>
          <Button 
            type="submit" 
            className="w-full" 
            disabled={!isValid || isLoading || isSubmitting}
          >
            {(isLoading || isSubmitting) ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Signing In...
              </>
            ) : (
              "Sign In"
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}