'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useAuth } from '@/contexts/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { 
  Search, 
  ShoppingCart, 
  User, 
  Menu, 
  ChevronDown,
  Heart,
  Package,
  Phone,
  Mail,
  Store,
  Shield,
  LogOut
} from 'lucide-react'
import { useCart } from '@/hooks/use-cart'
import { Logo } from '@/components/Logo'
import { motion } from 'framer-motion'
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const { user, isAuthenticated, logout, isLoading } = useAuth()
  const { items, getTotalItems } = useCart()
  const totalItems = getTotalItems()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const categories = [
    { name: 'Electronics', href: '/kategori/electronics' },
    { name: "Men's Fashion", href: '/kategori/mens-fashion' },
    { name: "Women's Fashion", href: '/kategori/womens-fashion' },
    { name: 'Health & Beauty', href: '/kategori/health-beauty' },
    { name: 'Sports', href: '/kategori/sports' },
    { name: 'Home & Living', href: '/kategori/home-living' },
  ]

  return (
    <>
      {/* Top Bar */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 text-sm"
      >
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Phone className="w-4 h-4" />
              <span>+1 (555) 123-4567</span>
            </div>
            <div className="flex items-center gap-1">
              <Mail className="w-4 h-4" />
              <span>support@shophub.com</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span>Free Shipping $50+</span>
            <span>|</span>
            <span>100% Guarantee</span>
          </div>
        </div>
      </motion.div>

      {/* Main Header */}
      <motion.header 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
        className={`sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b transition-all duration-200 ${
          isScrolled ? 'shadow-md' : ''
        }`}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80">
                <div className="flex flex-col gap-6 mt-8">
                  <Logo />
                  <nav className="flex flex-col gap-4">
                    {categories.map((category) => (
                      <Link
                        key={category.name}
                        href={category.href}
                        className="text-lg hover:text-purple-600 transition-colors"
                      >
                        {category.name}
                      </Link>
                    ))}
                    <Link href="/promo" className="text-lg hover:text-purple-600 transition-colors">
                      Deals
                    </Link>
                    <Link href="/about" className="text-lg hover:text-purple-600 transition-colors">
                      About Us
                    </Link>
                  </nav>
                </div>
              </SheetContent>
            </Sheet>

            {/* Logo */}
            <Link href="/" className="flex items-center">
              <Logo />
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              <div className="relative group">
                <Button variant="ghost" className="flex items-center gap-1 hover:text-purple-600">
                  Categories
                  <ChevronDown className="w-4 h-4" />
                </Button>
                <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-lg shadow-lg border opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                  <div className="p-4">
                    {categories.map((category) => (
                      <Link
                        key={category.name}
                        href={category.href}
                        className="block py-2 px-3 hover:bg-purple-50 rounded-md transition-colors"
                      >
                        {category.name}
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
              <Link href="/promo" className="hover:text-purple-600 transition-colors">
                Deals
              </Link>
              <Link href="/about" className="hover:text-purple-600 transition-colors">
                About Us
              </Link>
            </nav>

            {/* Search Bar */}
            <div className="hidden lg:flex flex-1 max-w-md mx-6">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search products..."
                  className="pl-10 pr-4 border-purple-200 focus:border-purple-500 focus:ring-purple-500"
                  onFocus={() => setIsSearchOpen(true)}
                  onBlur={() => setTimeout(() => setIsSearchOpen(false), 200)}
                />
                {isSearchOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-lg border p-4">
                    <div className="text-sm text-gray-500">Start typing to search...</div>
                  </div>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              {/* Mobile Search */}
              <Button 
                variant="ghost" 
                size="icon" 
                className="lg:hidden"
                onClick={() => setIsSearchOpen(!isSearchOpen)}
              >
                <Search className="w-5 h-5" />
              </Button>

              {/* Wishlist */}
              <Button variant="ghost" size="icon" className="hidden sm:flex hover:text-purple-600">
                <Heart className="w-5 h-5" />
              </Button>

              {/* Cart */}
              <Link href="/keranjang">
                <Button variant="ghost" size="icon" className="relative hover:text-purple-600">
                  <ShoppingCart className="w-5 h-5" />
                  {totalItems > 0 && (
                    <Badge className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center p-0 text-xs bg-purple-600">
                      {totalItems}
                    </Badge>
                  )}
                </Button>
              </Link>

              {/* Quick Checkout - only show when cart has items */}
              {totalItems > 0 && (
                <Link href="/checkout">
                  <Button className="hidden sm:flex bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                    Checkout
                  </Button>
                </Link>
              )}

              {/* User Account */}
              {isAuthenticated && user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="hover:text-purple-600">
                      <User className="w-5 h-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <div className="px-2 py-1.5 text-sm font-medium">
                      {user.name || user.email}
                    </div>
                    <div className="px-2 py-1.5 text-xs text-muted-foreground">
                      {user.role === "ADMIN" && (
                        <div className="flex items-center gap-1">
                          <Shield className="w-3 h-3" />
                          Administrator
                        </div>
                      )}
                      {user.role === "SELLER" && (
                        <div className="flex items-center gap-1">
                          <Store className="w-3 h-3" />
                          Seller {user.storeName && `- ${user.storeName}`}
                        </div>
                      )}
                      {user.role === "CUSTOMER" && (
                        <div className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          Customer
                        </div>
                      )}
                    </div>
                    <DropdownMenuSeparator />
                    
                    {user.role === "ADMIN" && (
                      <DropdownMenuItem asChild>
                        <Link href="/admin/dashboard" className="flex items-center gap-2">
                          <Shield className="w-4 h-4" />
                          Admin Dashboard
                        </Link>
                      </DropdownMenuItem>
                    )}
                    
                    {user.role === "SELLER" && (
                      <>
                        <DropdownMenuItem asChild>
                          <Link href="/seller/dashboard" className="flex items-center gap-2">
                            <Store className="w-4 h-4" />
                            Seller Dashboard
                          </Link>
                        </DropdownMenuItem>
                        {!user.storeId && (
                          <DropdownMenuItem asChild>
                            <Link href="/buat-toko" className="flex items-center gap-2">
                              <Store className="w-4 h-4" />
                              Buat Toko
                            </Link>
                          </DropdownMenuItem>
                        )}
                      </>
                    )}
                    
                    <DropdownMenuItem asChild>
                      <Link href="/orders" className="flex items-center gap-2">
                        <Package className="w-4 h-4" />
                        My Orders
                      </Link>
                    </DropdownMenuItem>
                    
                    <DropdownMenuSeparator />
                    
                    <DropdownMenuItem 
                      className="flex items-center gap-2 text-red-600"
                      onClick={() => logout()}
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link href="/auth/signin">
                  <Button variant="ghost" size="icon" className="hover:text-purple-600">
                    <User className="w-5 h-5" />
                  </Button>
                </Link>
              )}
            </div>
          </div>

          {/* Mobile Search */}
          {isSearchOpen && (
            <div className="lg:hidden py-4 border-t">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search products..."
                  className="pl-10 pr-4"
                  autoFocus
                />
              </div>
            </div>
          )}
        </div>
      </motion.header>
    </>
  )
}