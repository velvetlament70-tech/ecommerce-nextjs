'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Star, 
  ShoppingCart, 
  Heart, 
  Eye,
  Truck,
  Shield
} from 'lucide-react'
import { useCart } from '@/hooks/use-cart'
import { productService } from '@/lib/products'
import { Product } from '@/lib/products'

interface ProductCardProps {
  product: Product
  className?: string
  showQuickView?: boolean
  compact?: boolean
}

export function ProductCard({ 
  product, 
  className = '', 
  showQuickView = true,
  compact = false 
}: ProductCardProps) {
  const { addItem, isInCart, getItemQuantity } = useCart()
  const [isAdding, setIsAdding] = useState(false)
  const [isWishlist, setIsWishlist] = useState(false)
  const [imageError, setImageError] = useState(false)

  const discountPercentage = productService.getDiscountPercentage(product)
  const isInStock = productService.isInStock(product.id)
  const inCart = isInCart(product.id)
  const cartQuantity = getItemQuantity(product.id)

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    
    if (isAdding || !isInStock) return
    
    setIsAdding(true)
    
    const result = addItem({
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      quantity: 1,
      slug: product.slug
    })
    
    // Show toast notification here if needed
    console.log(result.message)
    
    setTimeout(() => setIsAdding(false), 500)
  }

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsWishlist(!isWishlist)
  }

  const handleImageError = () => {
    setImageError(true)
  }

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`w-3 h-3 ${
              i < Math.floor(rating)
                ? 'fill-yellow-400 text-yellow-400'
                : 'text-gray-300'
            }`}
          />
        ))}
        <span className="text-xs text-gray-500 ml-1">({product.reviews})</span>
      </div>
    )
  }

  return (
    <Card className={`group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 overflow-hidden ${className}`}>
      {/* Product Image */}
      <div className="relative overflow-hidden">
        <div className={`aspect-square ${compact ? 'aspect-[4/3]' : ''} bg-gray-100`}>
          {!imageError ? (
            <img
              src={product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              onError={handleImageError}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-200">
              <div className="text-gray-400 text-center p-4">
                <div className="text-4xl mb-2">📦</div>
                <div className="text-sm">Gambar tidak tersedia</div>
              </div>
            </div>
          )}
        </div>
        
        {/* Overlay Actions */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300">
          <div className="absolute top-2 left-2 right-2 flex justify-between items-start">
            {/* Badges */}
            <div className="flex flex-col gap-1">
              {product.badge && (
                <Badge className="bg-red-500 hover:bg-red-600 text-white text-xs px-2 py-1">
                  {product.badge}
                </Badge>
              )}
              {discountPercentage > 0 && (
                <Badge className="bg-green-500 hover:bg-green-600 text-white text-xs px-2 py-1">
                  -{discountPercentage}%
                </Badge>
              )}
              {!isInStock && (
                <Badge className="bg-gray-500 hover:bg-gray-600 text-white text-xs px-2 py-1">
                  Habis
                </Badge>
              )}
            </div>
            
            {/* Action Buttons */}
            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              {showQuickView && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="bg-white/90 hover:bg-white text-gray-700 w-8 h-8"
                  onClick={(e) => {
                    e.preventDefault()
                    e.stopPropagation()
                    // Quick view functionality
                  }}
                >
                  <Eye className="w-4 h-4" />
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                className={`bg-white/90 hover:bg-white w-8 h-8 ${
                  isWishlist ? 'text-red-500' : 'text-gray-700'
                }`}
                onClick={handleToggleWishlist}
              >
                <Heart className={`w-4 h-4 ${isWishlist ? 'fill-current' : ''}`} />
              </Button>
            </div>
          </div>
          
          {/* Stock Indicator */}
          {!isInStock && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <div className="text-white text-center">
                <div className="text-lg font-semibold mb-1">Stok Habis</div>
                <div className="text-sm">Produk sedang kosong</div>
              </div>
            </div>
          )}
          
          {/* Low Stock Warning */}
          {isInStock && product.stock <= 5 && product.stock > 0 && (
            <div className="absolute bottom-2 left-2">
              <Badge className="bg-orange-500 hover:bg-orange-600 text-white text-xs">
                Stok tersisa {product.stock}
              </Badge>
            </div>
          )}
        </div>
      </div>

      {/* Product Info */}
      <CardContent className="p-4">
        {/* Category & Brand */}
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-gray-500">{product.category}</span>
          <span className="text-xs text-gray-400">{product.brand}</span>
        </div>

        {/* Product Name */}
        <Link href={`/produk/${product.slug}`}>
          <h3 className={`font-semibold text-gray-900 mb-2 line-clamp-2 hover:text-primary transition-colors ${
            compact ? 'text-sm' : 'text-base'
          }`}>
            {product.name}
          </h3>
        </Link>

        {/* Short Description */}
        {!compact && (
          <p className="text-xs text-gray-600 mb-3 line-clamp-2">
            {product.shortDescription}
          </p>
        )}

        {/* Rating */}
        <div className="mb-3">
          {renderStars(product.rating)}
        </div>

        {/* Price */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className={`font-bold text-primary ${compact ? 'text-sm' : 'text-lg'}`}>
              Rp{product.price.toLocaleString('id-ID')}
            </div>
            {product.comparePrice && product.comparePrice > product.price && (
              <div className={`text-gray-500 line-through ${compact ? 'text-xs' : 'text-sm'}`}>
                Rp{product.comparePrice.toLocaleString('id-ID')}
              </div>
            )}
          </div>
        </div>

        {/* Features */}
        {!compact && product.features.length > 0 && (
          <div className="mb-3">
            <div className="flex flex-wrap gap-1">
              {product.features.slice(0, 2).map((feature, index) => (
                <span
                  key={index}
                  className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded"
                >
                  {feature}
                </span>
              ))}
              {product.features.length > 2 && (
                <span className="text-xs text-gray-500">
                  +{product.features.length - 2} lagi
                </span>
              )}
            </div>
          </div>
        )}

        {/* Action Button */}
        <div className="flex gap-2">
          {inCart ? (
            <div className="flex-1 flex items-center justify-between bg-green-50 border border-green-200 rounded-lg px-3 py-2">
              <span className="text-sm text-green-700">
                {cartQuantity} di keranjang
              </span>
              <Link href="/keranjang">
                <Button size="sm" variant="outline" className="text-green-700 border-green-300 hover:bg-green-100">
                  Lihat
                </Button>
              </Link>
            </div>
          ) : (
            <Button
              onClick={handleAddToCart}
              disabled={!isInStock || isAdding}
              className={`flex-1 ${compact ? 'text-sm py-2' : ''}`}
              size={compact ? 'sm' : 'default'}
            >
              {isAdding ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Menambahkan...
                </>
              ) : !isInStock ? (
                'Stok Habis'
              ) : (
                <>
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Tambah ke Keranjang
                </>
              )}
            </Button>
          )}
        </div>

        {/* Trust Badges */}
        {!compact && (
          <div className="flex items-center gap-3 mt-3 text-xs text-gray-500">
            <div className="flex items-center gap-1">
              <Truck className="w-3 h-3" />
              <span>Gratis Ongkir</span>
            </div>
            <div className="flex items-center gap-1">
              <Shield className="w-3 h-3" />
              <span>Garansi</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

// Product Grid Component
interface ProductGridProps {
  products: Product[]
  className?: string
  columns?: 1 | 2 | 3 | 4 | 5 | 6
  compact?: boolean
}

export function ProductGrid({ 
  products, 
  className = '', 
  columns = 4,
  compact = false 
}: ProductGridProps) {
  const gridCols = {
    1: 'grid-cols-1',
    2: 'grid-cols-1 sm:grid-cols-2',
    3: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4',
    5: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5',
    6: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 3xl:grid-cols-6'
  }

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <ShoppingCart className="w-8 h-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-semibold mb-2">Tidak ada produk ditemukan</h3>
        <p className="text-gray-600">Coba ubah filter atau kata kunci pencarian Anda</p>
      </div>
    )
  }

  return (
    <div className={`grid ${gridCols[columns]} gap-6 ${className}`}>
      {products.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          compact={compact}
        />
      ))}
    </div>
  )
}

// Product List Component
interface ProductListProps {
  products: Product[]
  className?: string
}

export function ProductList({ products, className = '' }: ProductListProps) {
  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <ShoppingCart className="w-8 h-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-semibold mb-2">Tidak ada produk ditemukan</h3>
        <p className="text-gray-600">Coba ubah filter atau kata kunci pencarian Anda</p>
      </div>
    )
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {products.map((product) => (
        <Card key={product.id} className="hover:shadow-lg transition-all duration-300">
          <CardContent className="p-4">
            <div className="flex gap-4">
              {/* Product Image */}
              <div className="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Product Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <Link href={`/produk/${product.slug}`}>
                      <h3 className="font-semibold text-lg mb-1 hover:text-primary transition-colors">
                        {product.name}
                      </h3>
                    </Link>
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                      <span>{product.category}</span>
                      <span>•</span>
                      <span>{product.brand}</span>
                    </div>
                    <p className="text-sm text-gray-600 line-clamp-2 mb-2">
                      {product.shortDescription}
                    </p>
                  </div>
                </div>

                {/* Rating */}
                <div className="mb-2">
                  {Array.from({ length: 5 }, (_, i) => (
                    <Star
                      key={i}
                      className={`w-3 h-3 inline ${
                        i < Math.floor(product.rating)
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                  <span className="text-xs text-gray-500 ml-1">({product.reviews})</span>
                </div>

                {/* Price and Actions */}
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-lg font-bold text-primary">
                      Rp{product.price.toLocaleString('id-ID')}
                    </div>
                    {product.comparePrice && product.comparePrice > product.price && (
                      <div className="text-sm text-gray-500 line-through">
                        Rp{product.comparePrice.toLocaleString('id-ID')}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Heart className="w-4 h-4" />
                    </Button>
                    <Button size="sm">
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Tambah
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}