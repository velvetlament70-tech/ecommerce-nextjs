'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  MessageCircle, 
  Send, 
  Bot, 
  Smartphone, 
  CheckCircle,
  AlertCircle,
  Clock,
  Users,
  Settings,
  Loader2,
  Copy,
  ExternalLink
} from 'lucide-react'
import { useWhatsApp, useTelegram } from '@/hooks/use-integrations'
import { WhatsAppConfig, TelegramConfig, MessageTemplate } from '@/lib/integrations'

interface NotificationSettingsProps {
  config?: {
    whatsapp?: WhatsAppConfig
    telegram?: TelegramConfig
  }
  onConfigChange?: (type: 'whatsapp' | 'telegram', config: any) => void
  className?: string
}

export function NotificationSettings({ config, onConfigChange, className = "" }: NotificationSettingsProps) {
  const [activeTab, setActiveTab] = useState<'whatsapp' | 'telegram'>('whatsapp')
  const [testMessage, setTestMessage] = useState('')
  const [testPhone, setTestPhone] = useState('')
  const [isSending, setIsSending] = useState(false)
  const [sendResult, setSendResult] = useState<{ success: boolean; message: string } | null>(null)

  const { sendMessage: sendWhatsApp, generateWhatsAppLink } = useWhatsApp()
  const { sendMessage: sendTelegram } = useTelegram()

  const whatsappConfig = config?.whatsapp
  const telegramConfig = config?.telegram

  const handleSendTestWhatsApp = async () => {
    if (!testPhone || !testMessage || !whatsappConfig) return

    setIsSending(true)
    setSendResult(null)

    try {
      const success = await sendWhatsApp(testPhone, testMessage, whatsappConfig)
      setSendResult({
        success,
        message: success ? 'Pesan WhatsApp berhasil dikirim!' : 'Gagal mengirim pesan WhatsApp'
      })
    } catch (err) {
      setSendResult({
        success: false,
        message: 'Terjadi kesalahan saat mengirim pesan'
      })
    } finally {
      setIsSending(false)
    }
  }

  const handleSendTestTelegram = async () => {
    if (!testMessage || !telegramConfig) return

    setIsSending(true)
    setSendResult(null)

    try {
      const success = await sendTelegram(telegramConfig.chatId, testMessage, telegramConfig)
      setSendResult({
        success,
        message: success ? 'Pesan Telegram berhasil dikirim!' : 'Gagal mengirim pesan Telegram'
      })
    } catch (err) {
      setSendResult({
        success: false,
        message: 'Terjadi kesalahan saat mengirim pesan'
      })
    } finally {
      setIsSending(false)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageCircle className="w-5 h-5" />
          Pengaturan Notifikasi
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Tab Navigation */}
        <div className="flex gap-2 mb-6">
          <Button
            variant={activeTab === 'whatsapp' ? 'default' : 'outline'}
            onClick={() => setActiveTab('whatsapp')}
            className="flex items-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            WhatsApp
          </Button>
          <Button
            variant={activeTab === 'telegram' ? 'default' : 'outline'}
            onClick={() => setActiveTab('telegram')}
            className="flex items-center gap-2"
          >
            <Bot className="w-4 h-4" />
            Telegram
          </Button>
        </div>

        {/* WhatsApp Settings */}
        {activeTab === 'whatsapp' && (
          <div className="space-y-6">
            <div className="flex items-center gap-2 mb-4">
              <Smartphone className="w-5 h-5 text-green-600" />
              <h3 className="text-lg font-semibold">WhatsApp Business</h3>
              {whatsappConfig?.phoneNumber && (
                <Badge variant="outline" className="text-green-600">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Terhubung
                </Badge>
              )}
            </div>

            {whatsappConfig && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="whatsapp-phone">Nomor WhatsApp</Label>
                    <Input
                      id="whatsapp-phone"
                      value={whatsappConfig.phoneNumber}
                      onChange={(e) => onConfigChange?.('whatsapp', {
                        ...whatsappConfig,
                        phoneNumber: e.target.value
                      })}
                      placeholder="+62812345678"
                    />
                  </div>
                  <div>
                    <Label htmlFor="whatsapp-api">API Key</Label>
                    <Input
                      id="whatsapp-api"
                      type="password"
                      value={whatsappConfig.apiKey}
                      onChange={(e) => onConfigChange?.('whatsapp', {
                        ...whatsappConfig,
                        apiKey: e.target.value
                      })}
                      placeholder="WhatsApp API Key"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="whatsapp-greeting">Pesan Sapaan</Label>
                  <Textarea
                    id="whatsapp-greeting"
                    value={whatsappConfig.greetingMessage}
                    onChange={(e) => onConfigChange?.('whatsapp', {
                      ...whatsappConfig,
                      greetingMessage: e.target.value
                    })}
                    placeholder="Halo! Terima kasih telah menghubungi toko kami. Ada yang bisa kami bantu?"
                    rows={3}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="whatsapp-auto-reply"
                    checked={whatsappConfig.autoReply}
                    onCheckedChange={(checked) => onConfigChange?.('whatsapp', {
                      ...whatsappConfig,
                      autoReply: checked
                    })}
                  />
                  <Label htmlFor="whatsapp-auto-reply">Balas Otomatis</Label>
                </div>

                {/* Quick Actions */}
                <div className="border-t pt-4">
                  <h4 className="font-medium mb-3">Aksi Cepat</h4>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const link = generateWhatsAppLink(whatsappConfig.phoneNumber, whatsappConfig.greetingMessage)
                        window.open(link, '_blank')
                      }}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Buka WhatsApp
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(whatsappConfig.phoneNumber)}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Salin Nomor
                    </Button>
                  </div>
                </div>
              </>
            )}

            {/* Test WhatsApp */}
            <div className="border-t pt-4">
              <h4 className="font-medium mb-3">Test Pengiriman</h4>
              <div className="space-y-3">
                <div>
                  <Label htmlFor="test-phone">Nomor Tujuan</Label>
                  <Input
                    id="test-phone"
                    value={testPhone}
                    onChange={(e) => setTestPhone(e.target.value)}
                    placeholder="+62812345678"
                  />
                </div>
                <div>
                  <Label htmlFor="test-message">Pesan Test</Label>
                  <Textarea
                    id="test-message"
                    value={testMessage}
                    onChange={(e) => setTestMessage(e.target.value)}
                    placeholder="Ini adalah pesan test dari ShopHub"
                    rows={2}
                  />
                </div>
                <Button
                  onClick={handleSendTestWhatsApp}
                  disabled={isSending || !testPhone || !testMessage}
                  className="w-full"
                >
                  {isSending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4 mr-2" />
                  )}
                  Kirim Test WhatsApp
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Telegram Settings */}
        {activeTab === 'telegram' && (
          <div className="space-y-6">
            <div className="flex items-center gap-2 mb-4">
              <Bot className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg font-semibold">Telegram Bot</h3>
              {telegramConfig?.botToken && (
                <Badge variant="outline" className="text-blue-600">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Terhubung
                </Badge>
              )}
            </div>

            {telegramConfig && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="telegram-token">Bot Token</Label>
                    <Input
                      id="telegram-token"
                      type="password"
                      value={telegramConfig.botToken}
                      onChange={(e) => onConfigChange?.('telegram', {
                        ...telegramConfig,
                        botToken: e.target.value
                      })}
                      placeholder="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
                    />
                  </div>
                  <div>
                    <Label htmlFor="telegram-chat">Chat ID</Label>
                    <Input
                      id="telegram-chat"
                      value={telegramConfig.chatId}
                      onChange={(e) => onConfigChange?.('telegram', {
                        ...telegramConfig,
                        chatId: e.target.value
                      })}
                      placeholder="@username atau chat_id"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="telegram-parse-mode">Parse Mode</Label>
                  <Select
                    value={telegramConfig.parseMode}
                    onValueChange={(value: 'HTML' | 'Markdown') => onConfigChange?.('telegram', {
                      ...telegramConfig,
                      parseMode: value
                    })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="HTML">HTML</SelectItem>
                      <SelectItem value="Markdown">Markdown</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="telegram-welcome">Pesan Selamat Datang</Label>
                  <Textarea
                    id="telegram-welcome"
                    value={telegramConfig.welcomeMessage}
                    onChange={(e) => onConfigChange?.('telegram', {
                      ...telegramConfig,
                      welcomeMessage: e.target.value
                    })}
                    placeholder="Selamat datang di toko kami! 🛍️"
                    rows={3}
                  />
                </div>

                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="telegram-notifications"
                      checked={telegramConfig.enableNotifications}
                      onCheckedChange={(checked) => onConfigChange?.('telegram', {
                        ...telegramConfig,
                        enableNotifications: checked
                      })}
                    />
                    <Label htmlFor="telegram-notifications">Aktifkan Notifikasi</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="telegram-commands"
                      checked={telegramConfig.enableCommands}
                      onCheckedChange={(checked) => onConfigChange?.('telegram', {
                        ...telegramConfig,
                        enableCommands: checked
                      })}
                    />
                    <Label htmlFor="telegram-commands">Aktifkan Commands</Label>
                  </div>
                </div>
              </>
            )}

            {/* Test Telegram */}
            <div className="border-t pt-4">
              <h4 className="font-medium mb-3">Test Pengiriman</h4>
              <div className="space-y-3">
                <div>
                  <Label htmlFor="test-telegram-message">Pesan Test</Label>
                  <Textarea
                    id="test-telegram-message"
                    value={testMessage}
                    onChange={(e) => setTestMessage(e.target.value)}
                    placeholder="Ini adalah pesan test dari ShopHub 🛍️"
                    rows={2}
                  />
                </div>
                <Button
                  onClick={handleSendTestTelegram}
                  disabled={isSending || !testMessage}
                  className="w-full"
                >
                  {isSending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4 mr-2" />
                  )}
                  Kirim Test Telegram
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Send Result */}
        {sendResult && (
          <div className={`flex items-center gap-2 p-3 rounded-lg ${
            sendResult.success ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
          }`}>
            {sendResult.success ? (
              <CheckCircle className="w-4 h-4" />
            ) : (
              <AlertCircle className="w-4 h-4" />
            )}
            <span className="text-sm">{sendResult.message}</span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

interface MessageTemplateManagerProps {
  templates: MessageTemplate[]
  onTemplatesChange: (templates: MessageTemplate[]) => void
  className?: string
}

export function MessageTemplateManager({ templates, onTemplatesChange, className = "" }: MessageTemplateManagerProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<MessageTemplate | null>(null)
  const [isEditing, setIsEditing] = useState(false)

  const categories = [
    { value: 'order', label: 'Pesanan' },
    { value: 'payment', label: 'Pembayaran' },
    { value: 'shipping', label: 'Pengiriman' },
    { value: 'promotion', label: 'Promosi' }
  ]

  const handleSaveTemplate = (template: MessageTemplate) => {
    if (selectedTemplate) {
      // Update existing template
      const updated = templates.map(t => t.id === template.id ? template : t)
      onTemplatesChange(updated)
    } else {
      // Add new template
      onTemplatesChange([...templates, { ...template, id: Date.now().toString() }])
    }
    setIsEditing(false)
    setSelectedTemplate(null)
  }

  const handleDeleteTemplate = (id: string) => {
    onTemplatesChange(templates.filter(t => t.id !== id))
  }

  const extractVariables = (content: string): string[] => {
    const matches = content.match(/\{\{(\w+)\}\}/g)
    return matches ? matches.map(match => match.replace(/[{}]/g, '')) : []
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="w-5 h-5" />
          Template Pesan
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Template List */}
          <div>
            <h4 className="font-medium mb-3">Template Tersedia</h4>
            <div className="space-y-2">
              {templates.map((template) => (
                <div
                  key={template.id}
                  className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                  onClick={() => setSelectedTemplate(template)}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium">{template.name}</span>
                    <Badge variant="outline" className="text-xs">
                      {categories.find(c => c.value === template.category)?.label}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 truncate">{template.content}</p>
                  <div className="flex gap-1 mt-2">
                    {template.variables.map((variable, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {variable}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Template Editor */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium">
                {isEditing ? 'Edit Template' : 'Template Detail'}
              </h4>
              {selectedTemplate && (
                <div className="flex gap-2">
                  {isEditing ? (
                    <>
                      <Button size="sm" onClick={() => handleSaveTemplate(selectedTemplate)}>
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Simpan
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setIsEditing(false)}>
                        Batal
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button size="sm" variant="outline" onClick={() => setIsEditing(true)}>
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteTemplate(selectedTemplate.id)}
                      >
                        Hapus
                      </Button>
                    </>
                  )}
                </div>
              )}
            </div>

            {selectedTemplate ? (
              <div className="space-y-4">
                <div>
                  <Label>Nama Template</Label>
                  <Input
                    value={selectedTemplate.name}
                    onChange={(e) => setSelectedTemplate({
                      ...selectedTemplate,
                      name: e.target.value
                    })}
                    disabled={!isEditing}
                  />
                </div>

                <div>
                  <Label>Kategori</Label>
                  <Select
                    value={selectedTemplate.category}
                    onValueChange={(value: any) => setSelectedTemplate({
                      ...selectedTemplate,
                      category: value
                    })}
                    disabled={!isEditing}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.value} value={category.value}>
                          {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Konten Pesan</Label>
                  <Textarea
                    value={selectedTemplate.content}
                    onChange={(e) => setSelectedTemplate({
                      ...selectedTemplate,
                      content: e.target.value,
                      variables: extractVariables(e.target.value)
                    })}
                    disabled={!isEditing}
                    rows={4}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Gunakan {'{{variable}}'} untuk dynamic content
                  </p>
                </div>

                <div>
                  <Label>Variables Terdeteksi</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {selectedTemplate.variables.map((variable, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {variable}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <MessageCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>Pilih template untuk melihat detail</p>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}