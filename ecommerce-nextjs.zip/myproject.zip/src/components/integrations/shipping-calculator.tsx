'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { 
  Truck, 
  Package, 
  Clock, 
  Shield, 
  Calculator,
  Loader2,
  AlertCircle,
  CheckCircle,
  Info
} from 'lucide-react'
import { useRajaOngkir } from '@/hooks/use-integrations'
import { ShippingRate } from '@/lib/integrations'

interface ShippingCalculatorProps {
  origin: string
  destination: string
  weight: number
  onRateSelect?: (rate: ShippingRate) => void
  selectedRate?: ShippingRate
  className?: string
}

export function ShippingCalculator({ 
  origin, 
  destination, 
  weight, 
  onRateSelect, 
  selectedRate,
  className = ""
}: ShippingCalculatorProps) {
  const [rates, setRates] = useState<ShippingRate[]>([])
  const [selectedCourier, setSelectedCourier] = useState<string>('all')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  const { getShippingRates } = useRajaOngkir()

  const courierOptions = [
    { value: 'all', label: 'Semua Kurir' },
    { value: 'jne', label: 'JNE' },
    { value: 'tiki', label: 'TIKI' },
    { value: 'pos', label: 'POS Indonesia' },
    { value: 'wahana', label: 'Wahana' },
    { value: 'jnt', label: 'J&T' },
    { value: 'sicepat', label: 'SiCepat' }
  ]

  useEffect(() => {
    if (origin && destination && weight > 0) {
      fetchShippingRates()
    }
  }, [origin, destination, weight])

  const fetchShippingRates = async () => {
    setIsLoading(true)
    setError(null)
    
    try {
      const couriers = selectedCourier === 'all' 
        ? ['jne', 'tiki', 'pos', 'jnt', 'sicepat']
        : [selectedCourier]
      
      const shippingRates = await getShippingRates(origin, destination, weight, couriers)
      setRates(shippingRates)
    } catch (err) {
      setError('Gagal mengambil data ongkos kirim')
      console.error('Shipping rates error:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCourierChange = (value: string) => {
    setSelectedCourier(value)
  }

  const handleRateSelect = (rate: ShippingRate) => {
    if (onRateSelect) {
      onRateSelect(rate)
    }
  }

  const filteredRates = selectedCourier === 'all' 
    ? rates 
    : rates.filter(rate => rate.courier.toLowerCase().includes(selectedCourier.toLowerCase()))

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR'
    }).format(amount)
  }

  const getCourierColor = (courier: string) => {
    const colors: Record<string, string> = {
      'JNE': 'bg-red-100 text-red-800',
      'TIKI': 'bg-blue-100 text-blue-800',
      'POS Indonesia': 'bg-orange-100 text-orange-800',
      'J&T': 'bg-purple-100 text-purple-800',
      'SiCepat': 'bg-green-100 text-green-800',
      'Wahana': 'bg-yellow-100 text-yellow-800'
    }
    return colors[courier] || 'bg-gray-100 text-gray-800'
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="w-5 h-5" />
          Kalkulator Ongkos Kirim
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Shipping Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label className="text-sm text-gray-600">Dari</Label>
            <p className="font-medium">{origin || '-'}</p>
          </div>
          <div>
            <Label className="text-sm text-gray-600">Ke</Label>
            <p className="font-medium">{destination || '-'}</p>
          </div>
          <div>
            <Label className="text-sm text-gray-600">Berat</Label>
            <p className="font-medium">{weight} gram</p>
          </div>
        </div>

        {/* Courier Filter */}
        <div>
          <Label htmlFor="courier-filter">Filter Kurir</Label>
          <Select value={selectedCourier} onValueChange={handleCourierChange}>
            <SelectTrigger>
              <SelectValue placeholder="Pilih kurir" />
            </SelectTrigger>
            <SelectContent>
              {courierOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Refresh Button */}
        <Button 
          onClick={fetchShippingRates} 
          disabled={isLoading}
          variant="outline"
          className="w-full"
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Truck className="w-4 h-4 mr-2" />
          )}
          Refresh Ongkir
        </Button>

        {/* Error Message */}
        {error && (
          <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 p-3 rounded-lg">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        )}

        {/* Shipping Rates */}
        {isLoading ? (
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-gray-100 rounded-lg p-4 animate-pulse">
                <div className="h-4 bg-gray-300 rounded w-1/4 mb-2"></div>
                <div className="h-3 bg-gray-300 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        ) : filteredRates.length > 0 ? (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Info className="w-4 h-4" />
              <span>{filteredRates.length} opsi pengiriman tersedia</span>
            </div>
            
            <RadioGroup value={selectedRate?.service} className="space-y-3">
              {filteredRates.map((rate, index) => (
                <div key={index} className="relative">
                  <RadioGroupItem
                    value={rate.service}
                    id={`rate-${index}`}
                    className="peer sr-only"
                    onClick={() => handleRateSelect(rate)}
                  />
                  <Label
                    htmlFor={`rate-${index}`}
                    className={`block p-4 border rounded-lg cursor-pointer transition-all peer-checked:border-blue-500 peer-checked:bg-blue-50 hover:border-gray-300 ${
                      selectedRate?.service === rate.service ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Truck className="w-5 h-5 text-gray-600" />
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <Badge className={getCourierColor(rate.courier)}>
                              {rate.courier}
                            </Badge>
                            <span className="font-medium">{rate.service}</span>
                          </div>
                          <p className="text-sm text-gray-600">{rate.description}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Clock className="w-3 h-3 text-gray-400" />
                            <span className="text-xs text-gray-500">{rate.etd}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="text-lg font-bold text-green-600">
                          {formatCurrency(rate.cost)}
                        </div>
                        {rate.insurance && (
                          <div className="flex items-center gap-1 text-xs text-gray-500">
                            <Shield className="w-3 h-3" />
                            <span>Asuransi</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {selectedRate?.service === rate.service && (
                      <div className="absolute top-2 right-2">
                        <CheckCircle className="w-5 h-5 text-blue-600" />
                      </div>
                    )}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <Package className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p>Tidak ada opsi pengiriman tersedia</p>
            <p className="text-sm">Pastikan alamat dan berat sudah benar</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

interface ShippingRateDisplayProps {
  rate: ShippingRate
  className?: string
}

export function ShippingRateDisplay({ rate, className = "" }: ShippingRateDisplayProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR'
    }).format(amount)
  }

  const getCourierColor = (courier: string) => {
    const colors: Record<string, string> = {
      'JNE': 'bg-red-100 text-red-800',
      'TIKI': 'bg-blue-100 text-blue-800',
      'POS Indonesia': 'bg-orange-100 text-orange-800',
      'J&T': 'bg-purple-100 text-purple-800',
      'SiCepat': 'bg-green-100 text-green-800',
      'Wahana': 'bg-yellow-100 text-yellow-800'
    }
    return colors[courier] || 'bg-gray-100 text-gray-800'
  }

  return (
    <div className={`flex items-center justify-between p-3 bg-gray-50 rounded-lg ${className}`}>
      <div className="flex items-center gap-3">
        <Truck className="w-4 h-4 text-gray-600" />
        <div>
          <div className="flex items-center gap-2">
            <Badge className={getCourierColor(rate.courier)} variant="secondary">
              {rate.courier}
            </Badge>
            <span className="text-sm font-medium">{rate.service}</span>
          </div>
          <p className="text-xs text-gray-500">{rate.etd}</p>
        </div>
      </div>
      <div className="text-right">
        <div className="font-bold text-green-600">
          {formatCurrency(rate.cost)}
        </div>
      </div>
    </div>
  )
}

interface ProvinceCitySelectorProps {
  onProvinceChange: (provinceId: string) => void
  onCityChange: (cityId: string) => void
  selectedProvince?: string
  selectedCity?: string
  className?: string
}

export function ProvinceCitySelector({
  onProvinceChange,
  onCityChange,
  selectedProvince,
  selectedCity,
  className = ""
}: ProvinceCitySelectorProps) {
  const [provinces, setProvinces] = useState<Array<{ id: string; province: string }>>([])
  const [cities, setCities] = useState<Array<{ id: string; city: string; type: string }>>([])
  const [isLoadingProvinces, setIsLoadingProvinces] = useState(false)
  const [isLoadingCities, setIsLoadingCities] = useState(false)
  
  const { getProvinces, getCities } = useRajaOngkir()

  useEffect(() => {
    fetchProvinces()
  }, [])

  useEffect(() => {
    if (selectedProvince) {
      fetchCities(selectedProvince)
    }
  }, [selectedProvince])

  const fetchProvinces = async () => {
    setIsLoadingProvinces(true)
    try {
      const provinceList = await getProvinces()
      setProvinces(provinceList)
    } catch (err) {
      console.error('Failed to fetch provinces:', err)
    } finally {
      setIsLoadingProvinces(false)
    }
  }

  const fetchCities = async (provinceId: string) => {
    setIsLoadingCities(true)
    try {
      const cityList = await getCities(provinceId)
      setCities(cityList)
    } catch (err) {
      console.error('Failed to fetch cities:', err)
    } finally {
      setIsLoadingCities(false)
    }
  }

  const handleProvinceChange = (provinceId: string) => {
    onProvinceChange(provinceId)
    onCityChange('') // Reset city when province changes
  }

  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 gap-4 ${className}`}>
      <div>
        <Label htmlFor="province">Provinsi</Label>
        <Select 
          value={selectedProvince} 
          onValueChange={handleProvinceChange}
          disabled={isLoadingProvinces}
        >
          <SelectTrigger>
            <SelectValue placeholder="Pilih provinsi" />
          </SelectTrigger>
          <SelectContent>
            {provinces.map((province) => (
              <SelectItem key={province.id} value={province.id}>
                {province.province}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label htmlFor="city">Kota/Kabupaten</Label>
        <Select 
          value={selectedCity} 
          onValueChange={onCityChange}
          disabled={isLoadingCities || !selectedProvince}
        >
          <SelectTrigger>
            <SelectValue placeholder="Pilih kota" />
          </SelectTrigger>
          <SelectContent>
            {cities.map((city) => (
              <SelectItem key={city.id} value={city.id}>
                {city.type} {city.city}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  )
}