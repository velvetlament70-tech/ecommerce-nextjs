'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Store, 
  Package, 
  ShoppingCart, 
  Sync, 
  AlertCircle, 
  CheckCircle, 
  Clock,
  TrendingUp,
  Users,
  Eye,
  ExternalLink,
  Loader2,
  RefreshCw,
  ArrowUpDown,
  Settings
} from 'lucide-react'
import { useMarketplace } from '@/hooks/use-integrations'
import { MarketplaceConfig, MarketplaceProduct, MarketplaceOrder } from '@/lib/integrations'

interface MarketplaceIntegrationProps {
  config?: MarketplaceConfig[]
  onConfigChange?: (configs: MarketplaceConfig[]) => void
  className?: string
}

export function MarketplaceIntegration({ config = [], onConfigChange, className = "" }: MarketplaceIntegrationProps) {
  const [activeTab, setActiveTab] = useState<string>('tokopedia')
  const [isSyncing, setIsSyncing] = useState(false)
  const [syncResults, setSyncResults] = useState<Record<string, any>>({})
  
  const { syncProducts, syncOrders, isLoading } = useMarketplace()

  const marketplaceConfigs = config.reduce((acc, cfg) => {
    acc[cfg.platform] = cfg
    return acc
  }, {} as Record<string, MarketplaceConfig>)

  const handleConfigChange = (platform: string, updates: Partial<MarketplaceConfig>) => {
    const newConfigs = config.map(cfg => 
      cfg.platform === platform 
        ? { ...cfg, ...updates }
        : cfg
    )
    onConfigChange?.(newConfigs)
  }

  const handleSyncProducts = async (platform: string) => {
    setIsSyncing(true)
    setSyncResults(prev => ({ ...prev, [platform]: { loading: true } }))

    try {
      const products = await syncProducts(platform, marketplaceConfigs[platform])
      setSyncResults(prev => ({
        ...prev,
        [platform]: {
          loading: false,
          products,
          success: true,
          message: `Berhasil sync ${products.length} produk`
        }
      }))
    } catch (err) {
      setSyncResults(prev => ({
        ...prev,
        [platform]: {
          loading: false,
          success: false,
          message: 'Gagal sync produk'
        }
      }))
    } finally {
      setIsSyncing(false)
    }
  }

  const handleSyncOrders = async (platform: string) => {
    setIsSyncing(true)
    setSyncResults(prev => ({ ...prev, [platform]: { loading: true } }))

    try {
      const orders = await syncOrders(platform, marketplaceConfigs[platform])
      setSyncResults(prev => ({
        ...prev,
        [platform]: {
          ...prev[platform],
          loading: false,
          orders,
          success: true,
          message: `Berhasil sync ${orders.length} pesanan`
        }
      }))
    } catch (err) {
      setSyncResults(prev => ({
        ...prev,
        [platform]: {
          ...prev[platform],
          loading: false,
          success: false,
          message: 'Gagal sync pesanan'
        }
      }))
    } finally {
      setIsSyncing(false)
    }
  }

  const platforms = [
    {
      id: 'tokopedia',
      name: 'Tokopedia',
      color: 'bg-green-100 text-green-800',
      icon: '🛒'
    },
    {
      id: 'shopee',
      name: 'Shopee',
      color: 'bg-orange-100 text-orange-800',
      icon: '🛍️'
    },
    {
      id: 'bukalapak',
      name: 'Bukalapak',
      color: 'bg-red-100 text-red-800',
      icon: '🏪'
    },
    {
      id: 'lazada',
      name: 'Lazada',
      color: 'bg-blue-100 text-blue-800',
      icon: '🛍️'
    }
  ]

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Store className="w-5 h-5" />
          Integrasi Marketplace
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            {platforms.map((platform) => (
              <TabsTrigger key={platform.id} value={platform.id} className="flex items-center gap-2">
                <span>{platform.icon}</span>
                <span className="hidden sm:inline">{platform.name}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {platforms.map((platform) => {
            const config = marketplaceConfigs[platform.id]
            const result = syncResults[platform.id]

            return (
              <TabsContent key={platform.id} value={platform.id} className="space-y-6">
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-2xl">{platform.icon}</span>
                  <h3 className="text-lg font-semibold">{platform.name}</h3>
                  {config?.apiKey && (
                    <Badge variant="outline" className={platform.color}>
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Terhubung
                    </Badge>
                  )}
                </div>

                {/* Configuration */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor={`${platform.id}-shop-id`}>Shop ID</Label>
                    <Input
                      id={`${platform.id}-shop-id`}
                      value={config?.shopId || ''}
                      onChange={(e) => handleConfigChange(platform.id, { shopId: e.target.value })}
                      placeholder="Masukkan Shop ID"
                    />
                  </div>
                  <div>
                    <Label htmlFor={`${platform.id}-api-key`}>API Key</Label>
                    <Input
                      id={`${platform.id}-api-key`}
                      type="password"
                      value={config?.apiKey || ''}
                      onChange={(e) => handleConfigChange(platform.id, { apiKey: e.target.value })}
                      placeholder="Masukkan API Key"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor={`${platform.id}-secret-key`}>Secret Key</Label>
                  <Input
                    id={`${platform.id}-secret-key`}
                    type="password"
                    value={config?.secretKey || ''}
                    onChange={(e) => handleConfigChange(platform.id, { secretKey: e.target.value })}
                    placeholder="Masukkan Secret Key"
                  />
                </div>

                {/* Sync Settings */}
                <div className="space-y-3">
                  <h4 className="font-medium">Pengaturan Sinkronisasi</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`${platform.id}-sync-products`}
                        checked={config?.syncProducts || false}
                        onCheckedChange={(checked) => handleConfigChange(platform.id, { syncProducts: checked })}
                      />
                      <Label htmlFor={`${platform.id}-sync-products`}>Sync Produk</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`${platform.id}-sync-orders`}
                        checked={config?.syncOrders || false}
                        onCheckedChange={(checked) => handleConfigChange(platform.id, { syncOrders: checked })}
                      />
                      <Label htmlFor={`${platform.id}-sync-orders`}>Sync Pesanan</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`${platform.id}-sync-inventory`}
                        checked={config?.syncInventory || false}
                        onCheckedChange={(checked) => handleConfigChange(platform.id, { syncInventory: checked })}
                      />
                      <Label htmlFor={`${platform.id}-sync-inventory`}>Sync Inventory</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`${platform.id}-auto-accept`}
                        checked={config?.autoAcceptOrders || false}
                        onCheckedChange={(checked) => handleConfigChange(platform.id, { autoAcceptOrders: checked })}
                      />
                      <Label htmlFor={`${platform.id}-auto-accept`}>Auto Accept Orders</Label>
                    </div>
                  </div>
                </div>

                {/* Price Markup */}
                <div>
                  <Label htmlFor={`${platform.id}-markup`}>Markup Harga (%)</Label>
                  <Input
                    id={`${platform.id}-markup`}
                    type="number"
                    value={config?.priceMarkup || 0}
                    onChange={(e) => handleConfigChange(platform.id, { priceMarkup: Number(e.target.value) })}
                    placeholder="0"
                    min="0"
                    max="100"
                  />
                </div>

                {/* Sync Actions */}
                <div className="border-t pt-4">
                  <h4 className="font-medium mb-3">Aksi Sinkronisasi</h4>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      onClick={() => handleSyncProducts(platform.id)}
                      disabled={isSyncing || !config?.apiKey}
                      variant="outline"
                    >
                      {result?.loading ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Package className="w-4 h-4 mr-2" />
                      )}
                      Sync Produk
                    </Button>
                    <Button
                      onClick={() => handleSyncOrders(platform.id)}
                      disabled={isSyncing || !config?.apiKey}
                      variant="outline"
                    >
                      {result?.loading ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <ShoppingCart className="w-4 h-4 mr-2" />
                      )}
                      Sync Pesanan
                    </Button>
                    <Button
                      onClick={() => {
                        handleSyncProducts(platform.id)
                        setTimeout(() => handleSyncOrders(platform.id), 2000)
                      }}
                      disabled={isSyncing || !config?.apiKey}
                    >
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Sync All
                    </Button>
                  </div>
                </div>

                {/* Sync Results */}
                {result && (
                  <div className={`p-3 rounded-lg ${
                    result.success ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                  }`}>
                    <div className="flex items-center gap-2">
                      {result.success ? (
                        <CheckCircle className="w-4 h-4" />
                      ) : (
                        <AlertCircle className="w-4 h-4" />
                      )}
                      <span className="text-sm">{result.message}</span>
                    </div>
                  </div>
                )}

                {/* Sync Results Display */}
                {result?.products && (
                  <div className="space-y-4">
                    <h4 className="font-medium">Hasil Sync Produk</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {result.products.slice(0, 4).map((product: MarketplaceProduct) => (
                        <div key={product.id} className="border rounded-lg p-3">
                          <div className="flex items-start justify-between mb-2">
                            <h5 className="font-medium text-sm truncate">{product.name}</h5>
                            <Badge variant={product.status === 'active' ? 'default' : 'secondary'}>
                              {product.status}
                            </Badge>
                          </div>
                          <p className="text-lg font-bold text-green-600">
                            Rp {product.price.toLocaleString('id-ID')}
                          </p>
                          <p className="text-sm text-gray-500">Stok: {product.stock}</p>
                          <Button
                            size="sm"
                            variant="outline"
                            className="w-full mt-2"
                            onClick={() => window.open(product.url, '_blank')}
                          >
                            <ExternalLink className="w-3 h-3 mr-1" />
                            Lihat di {platform.name}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {result?.orders && (
                  <div className="space-y-4">
                    <h4 className="font-medium">Hasil Sync Pesanan</h4>
                    <div className="space-y-2">
                      {result.orders.slice(0, 3).map((order: MarketplaceOrder) => (
                        <div key={order.id} className="border rounded-lg p-3">
                          <div className="flex items-center justify-between mb-2">
                            <div>
                              <p className="font-medium">{order.orderNumber}</p>
                              <p className="text-sm text-gray-500">{order.customerName}</p>
                            </div>
                            <Badge variant={order.status === 'completed' ? 'default' : 'secondary'}>
                              {order.status}
                            </Badge>
                          </div>
                          <p className="text-lg font-bold">
                            Rp {order.totalAmount.toLocaleString('id-ID')}
                          </p>
                          <div className="flex items-center gap-2 text-xs text-gray-500">
                            <Clock className="w-3 h-3" />
                            <span>{new Date(order.createdAt).toLocaleDateString('id-ID')}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </TabsContent>
            )
          })}
        </Tabs>
      </CardContent>
    </Card>
  )
}

interface MarketplaceStatsProps {
  configs: MarketplaceConfig[]
  className?: string
}

export function MarketplaceStats({ configs, className = "" }: MarketplaceStatsProps) {
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalOrders: 0,
    totalRevenue: 0,
    activePlatforms: 0
  })

  // Mock stats - replace with actual API calls
  useEffect(() => {
    const mockStats = {
      totalProducts: Math.floor(Math.random() * 500) + 100,
      totalOrders: Math.floor(Math.random() * 100) + 50,
      totalRevenue: Math.floor(Math.random() * 10000000) + 5000000,
      activePlatforms: configs.filter(c => c.apiKey).length
    }
    setStats(mockStats)
  }, [configs])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR'
    }).format(amount)
  }

  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 ${className}`}>
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Package className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Produk</p>
              <p className="text-2xl font-bold">{stats.totalProducts}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <ShoppingCart className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Pesanan</p>
              <p className="text-2xl font-bold">{stats.totalOrders}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold">{formatCurrency(stats.totalRevenue)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Store className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Platform Aktif</p>
              <p className="text-2xl font-bold">{stats.activePlatforms}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}