'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';
import { AnimatedCard, StaggerContainer, StaggerItem } from '@/components/animations/AnimatedComponents';

interface Testimonial {
  id: number;
  name: string;
  avatar: string;
  rating: number;
  comment: string;
  product: string;
  date: string;
  verified: boolean;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Sarah Johnson",
    avatar: "SJ",
    rating: 5,
    comment: "Absolutely love the quality and service! The product exceeded my expectations and arrived faster than expected. Will definitely shop here again.",
    product: "Premium Wireless Headphones",
    date: "2 days ago",
    verified: true
  },
  {
    id: 2,
    name: "Michael Chen",
    avatar: "MC",
    rating: 5,
    comment: "Best shopping experience I've had online. The website is easy to navigate, prices are competitive, and customer service is outstanding.",
    product: "Smart Watch Pro",
    date: "1 week ago",
    verified: true
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    avatar: "ER",
    rating: 4,
    comment: "Great selection of products and fast shipping. The only minor issue was that the packaging could be more eco-friendly, but the product quality is amazing.",
    product: "Organic Skincare Set",
    date: "2 weeks ago",
    verified: true
  },
  {
    id: 4,
    name: "David Kim",
    avatar: "DK",
    rating: 5,
    comment: "I've been a loyal customer for over a year now. The quality is consistently excellent, and the rewards program is a nice bonus!",
    product: "Gaming Keyboard RGB",
    date: "3 weeks ago",
    verified: true
  },
  {
    id: 5,
    name: "Lisa Thompson",
    avatar: "LT",
    rating: 5,
    comment: "The customer service team went above and beyond to help me with my return. They made the process completely hassle-free. Highly recommend!",
    product: "Yoga Mat Premium",
    date: "1 month ago",
    verified: true
  },
  {
    id: 6,
    name: "James Wilson",
    avatar: "JW",
    rating: 4,
    comment: "Very satisfied with my purchase. The product quality is top-notch and the price was very competitive. Would definitely recommend to friends.",
    product: "Coffee Maker Deluxe",
    date: "1 month ago",
    verified: true
  }
];

export function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const visibleTestimonials = 3;
  const maxIndex = Math.max(0, testimonials.length - visibleTestimonials);

  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        prevIndex >= maxIndex ? 0 : prevIndex + 1
      );
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, maxIndex]);

  const handlePrevious = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex <= 0 ? maxIndex : prevIndex - 1
    );
    setIsAutoPlaying(false);
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex >= maxIndex ? 0 : prevIndex + 1
    );
    setIsAutoPlaying(false);
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < rating
            ? 'fill-yellow-400 text-yellow-400'
            : 'text-gray-300 dark:text-gray-600'
        }`}
      />
    ));
  };

  const getAvatarColor = (name: string) => {
    const colors = [
      'bg-purple-500', 'bg-pink-500', 'bg-blue-500', 
      'bg-green-500', 'bg-orange-500', 'bg-teal-500'
    ];
    const index = name.charCodeAt(0) % colors.length;
    return colors[index];
  };

  return (
    <section className="py-16 bg-gradient-to-br from-purple-50 via-white to-pink-50 dark:from-gray-900 dark:via-gray-900 dark:to-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
              <Quote className="w-8 h-8 text-white" />
            </div>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            What Our Customers Say
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Real reviews from real customers who love shopping with us
          </p>
        </div>

        <div className="relative">
          <StaggerContainer className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.slice(currentIndex, currentIndex + visibleTestimonials).map((testimonial, index) => (
              <StaggerItem key={testimonial.id}>
                <AnimatedCard className="h-full">
                  <Card className="h-full bg-white dark:bg-gray-800 border-purple-200 dark:border-purple-700 shadow-lg hover:shadow-xl transition-shadow duration-300">
                    <CardContent className="p-6 h-full flex flex-col">
                      <div className="flex items-center mb-4">
                        <div className={`w-12 h-12 rounded-full ${getAvatarColor(testimonial.name)} flex items-center justify-center text-white font-bold mr-3`}>
                          {testimonial.avatar}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <h4 className="font-semibold text-gray-900 dark:text-white">
                              {testimonial.name}
                            </h4>
                            {testimonial.verified && (
                              <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                                <span className="text-white text-xs">✓</span>
                              </div>
                            )}
                          </div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {testimonial.date}
                          </p>
                        </div>
                      </div>

                      <div className="flex mb-3">
                        {renderStars(testimonial.rating)}
                      </div>

                      <blockquote className="text-gray-700 dark:text-gray-300 mb-4 flex-1">
                        "{testimonial.comment}"
                      </blockquote>

                      <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                        <p className="text-sm text-purple-600 dark:text-purple-400 font-medium">
                          Purchased: {testimonial.product}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </AnimatedCard>
              </StaggerItem>
            ))}
          </StaggerContainer>

          {/* Navigation Controls */}
          <div className="flex justify-center items-center space-x-4 mt-8">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrevious}
              className="border-purple-200 dark:border-purple-700 hover:bg-purple-50 dark:hover:bg-purple-900/20"
              disabled={testimonials.length <= visibleTestimonials}
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              Previous
            </Button>

            <div className="flex space-x-2">
              {Array.from({ length: maxIndex + 1 }, (_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setCurrentIndex(i);
                    setIsAutoPlaying(false);
                  }}
                  className={`w-2 h-2 rounded-full transition-colors duration-200 ${
                    i === currentIndex
                      ? 'bg-purple-600'
                      : 'bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500'
                  }`}
                />
              ))}
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={handleNext}
              className="border-purple-200 dark:border-purple-700 hover:bg-purple-50 dark:hover:bg-purple-900/20"
              disabled={testimonials.length <= visibleTestimonials}
            >
              Next
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>

          {/* Auto-play toggle */}
          <div className="flex justify-center mt-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsAutoPlaying(!isAutoPlaying)}
              className="text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300"
            >
              {isAutoPlaying ? 'Pause' : 'Play'} Auto-scroll
            </Button>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="mt-16 text-center">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                50K+
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Happy Customers
              </p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                4.8/5
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Average Rating
              </p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                10K+
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Products Sold
              </p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                24/7
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Customer Support
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}