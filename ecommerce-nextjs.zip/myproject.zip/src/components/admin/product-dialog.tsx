'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { X, Upload, Image as ImageIcon, Sparkles, Loader2 } from 'lucide-react'

interface Product {
  id: string
  name: string
  price: number
  category: string
  stock: number
  description: string
  image: string
  status: 'active' | 'inactive'
  createdAt: string
}

interface ProductDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  product: Product | null
  onSave: (product: Omit<Product, 'id' | 'createdAt'>) => void
}

const categories = [
  'Elektronik',
  'Fashion',
  'Kesehatan',
  'Olahraga',
  'Rumah Tangga',
  'Makanan & Minuman',
  'Buku & Alat Tulis',
  'Mainan & Hobi',
  'Otomotif',
  'Lainnya'
]

export function ProductDialog({ open, onOpenChange, product, onSave }: ProductDialogProps) {
  const [formData, setFormData] = useState({
    name: '',
    price: 0,
    category: '',
    stock: 0,
    description: '',
    image: '',
    status: 'active' as 'active' | 'inactive'
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isGeneratingDescription, setIsGeneratingDescription] = useState(false)

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name,
        price: product.price,
        category: product.category,
        stock: product.stock,
        description: product.description,
        image: product.image,
        status: product.status
      })
    } else {
      setFormData({
        name: '',
        price: 0,
        category: '',
        stock: 0,
        description: '',
        image: '',
        status: 'active'
      })
    }
    setErrors({})
  }, [product, open])

  const handleInputChange = (field: string, value: string | number | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }))
    }
  }

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (!formData.name.trim()) {
      newErrors.name = 'Nama produk wajib diisi'
    }

    if (!formData.price || formData.price <= 0) {
      newErrors.price = 'Harga harus lebih dari 0'
    }

    if (!formData.category) {
      newErrors.category = 'Kategori wajib dipilih'
    }

    if (formData.stock < 0) {
      newErrors.stock = 'Stok tidak boleh negatif'
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Deskripsi produk wajib diisi'
    }

    if (!formData.image.trim()) {
      newErrors.image = 'URL gambar wajib diisi'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      onSave(formData)
      onOpenChange(false)
    } catch (error) {
      console.error('Error saving product:', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const generateRandomImage = () => {
    const randomSeed = Math.random().toString(36).substring(7)
    const imageUrl = `https://picsum.photos/seed/${randomSeed}/400/400.jpg`
    handleInputChange('image', imageUrl)
  }

  const generateAIDescription = async () => {
    if (!formData.name.trim()) {
      setErrors(prev => ({ ...prev, name: 'Nama produk harus diisi terlebih dahulu' }))
      return
    }

    setIsGeneratingDescription(true)
    try {
      const response = await fetch('/api/generate-description', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          productName: formData.name,
          category: formData.category
        }),
      })

      const data = await response.json()

      if (data.success) {
        handleInputChange('description', data.description)
        setErrors(prev => ({ ...prev, description: '' }))
      } else {
        console.error('Failed to generate description:', data.error)
        // Fallback to a generic description
        const fallbackDescription = `${formData.name} adalah produk berkualitas tinggi dalam kategori ${formData.category || 'umum'}. Dibuat dengan bahan terbaik dan desain yang menarik, produk ini menawarkan nilai tambah yang luar biasa untuk kebutuhan Anda.`
        handleInputChange('description', fallbackDescription)
      }
    } catch (error) {
      console.error('Error generating description:', error)
      // Fallback to a generic description
      const fallbackDescription = `${formData.name} adalah produk berkualitas tinggi dalam kategori ${formData.category || 'umum'}. Dibuat dengan bahan terbaik dan desain yang menarik, produk ini menawarkan nilai tambah yang luar biasa untuk kebutuhan Anda.`
      handleInputChange('description', fallbackDescription)
    } finally {
      setIsGeneratingDescription(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>{product ? 'Edit Produk' : 'Tambah Produk Baru'}</span>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onOpenChange(false)}
              className="h-6 w-6"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
          <DialogDescription>
            {product ? 'Edit informasi produk yang ada' : 'Tambahkan produk baru ke inventori toko Anda'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Product Name */}
          <div className="space-y-2">
            <Label htmlFor="name">Nama Produk *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              placeholder="Masukkan nama produk"
              className={errors.name ? 'border-red-500' : ''}
            />
            {errors.name && (
              <p className="text-sm text-red-500">{errors.name}</p>
            )}
          </div>

          {/* Price and Stock */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="price">Harga (Rp) *</Label>
              <Input
                id="price"
                type="number"
                value={formData.price}
                onChange={(e) => handleInputChange('price', parseInt(e.target.value) || 0)}
                placeholder="0"
                className={errors.price ? 'border-red-500' : ''}
              />
              {errors.price && (
                <p className="text-sm text-red-500">{errors.price}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="stock">Stok *</Label>
              <Input
                id="stock"
                type="number"
                value={formData.stock}
                onChange={(e) => handleInputChange('stock', parseInt(e.target.value) || 0)}
                placeholder="0"
                className={errors.stock ? 'border-red-500' : ''}
              />
              {errors.stock && (
                <p className="text-sm text-red-500">{errors.stock}</p>
              )}
            </div>
          </div>

          {/* Category */}
          <div className="space-y-2">
            <Label htmlFor="category">Kategori *</Label>
            <Select
              value={formData.category}
              onValueChange={(value) => handleInputChange('category', value)}
            >
              <SelectTrigger className={errors.category ? 'border-red-500' : ''}>
                <SelectValue placeholder="Pilih kategori" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.category && (
              <p className="text-sm text-red-500">{errors.category}</p>
            )}
          </div>

          {/* Description */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="description">Deskripsi Produk *</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={generateAIDescription}
                disabled={isGeneratingDescription || !formData.name.trim()}
                className="text-xs"
              >
                {isGeneratingDescription ? (
                  <>
                    <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3 h-3 mr-1" />
                    Generate AI
                  </>
                )}
              </Button>
            </div>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Jelaskan detail produk Anda..."
              rows={3}
              className={errors.description ? 'border-red-500' : ''}
            />
            {errors.description && (
              <p className="text-sm text-red-500">{errors.description}</p>
            )}
          </div>

          {/* Image URL */}
          <div className="space-y-2">
            <Label htmlFor="image">URL Gambar Produk *</Label>
            <div className="flex gap-2">
              <div className="flex-1">
                <Input
                  id="image"
                  value={formData.image}
                  onChange={(e) => handleInputChange('image', e.target.value)}
                  placeholder="https://example.com/image.jpg"
                  className={errors.image ? 'border-red-500' : ''}
                />
              </div>
              <Button
                type="button"
                variant="outline"
                onClick={generateRandomImage}
                className="whitespace-nowrap"
              >
                <ImageIcon className="w-4 h-4 mr-2" />
                Random
              </Button>
            </div>
            {errors.image && (
              <p className="text-sm text-red-500">{errors.image}</p>
            )}
            
            {/* Image Preview */}
            {formData.image && (
              <div className="mt-2">
                <div className="w-32 h-32 border rounded-lg overflow-hidden bg-gray-50">
                  <img
                    src={formData.image}
                    alt="Preview"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = 'https://via.placeholder.com/400x400?text=Error'
                    }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Status */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="status">Status Produk</Label>
              <p className="text-sm text-gray-500">
                Produk aktif akan ditampilkan di toko
              </p>
            </div>
            <Switch
              id="status"
              checked={formData.status === 'active'}
              onCheckedChange={(checked) => 
                handleInputChange('status', checked ? 'active' : 'inactive')
              }
            />
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Batal
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Menyimpan...
                </>
              ) : (
                product ? 'Update Produk' : 'Tambah Produk'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}