'use client'

import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'
import { 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar, 
  CreditCard, 
  Package,
  Truck,
  CheckCircle,
  Clock,
  XCircle,
  ArrowRight
} from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

interface OrderItem {
  id: string
  name: string
  price: number
  quantity: number
  image: string
}

interface Order {
  id: string
  orderNumber: string
  customerName: string
  customerEmail: string
  customerPhone: string
  customerAddress: string
  items: OrderItem[]
  subtotal: number
  shipping: number
  tax: number
  total: number
  paymentMethod: string
  status: 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled'
  createdAt: string
  notes?: string
}

interface OrderDetailDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  order: Order | null
  onUpdateStatus: (orderId: string, status: Order['status']) => void
}

export function OrderDetailDialog({ open, onOpenChange, order, onUpdateStatus }: OrderDetailDialogProps) {
  if (!order) return null

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800'
      case 'processing':
        return 'bg-blue-100 text-blue-800'
      case 'shipped':
        return 'bg-purple-100 text-purple-800'
      case 'completed':
        return 'bg-green-100 text-green-800'
      case 'cancelled':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Menunggu Pembayaran'
      case 'processing':
        return 'Diproses'
      case 'shipped':
        return 'Dikirim'
      case 'completed':
        return 'Selesai'
      case 'cancelled':
        return 'Dibatalkan'
      default:
        return status
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-5 h-5" />
      case 'processing':
        return <Package className="w-5 h-5" />
      case 'shipped':
        return <Truck className="w-5 h-5" />
      case 'completed':
        return <CheckCircle className="w-5 h-5" />
      case 'cancelled':
        return <XCircle className="w-5 h-5" />
      default:
        return null
    }
  }

  const getPaymentMethodText = (method: string) => {
    switch (method) {
      case 'transfer':
        return 'Transfer Bank'
      case 'ewallet':
        return 'E-Wallet'
      case 'cod':
        return 'COD (Bayar di Tempat)'
      default:
        return method
    }
  }

  const getNextStatus = (currentStatus: string) => {
    switch (currentStatus) {
      case 'pending':
        return [
          { status: 'processing', label: 'Proses Pesanan', color: 'bg-blue-600' },
          { status: 'cancelled', label: 'Batalkan Pesanan', color: 'bg-red-600' }
        ]
      case 'processing':
        return [
          { status: 'shipped', label: 'Kirim Pesanan', color: 'bg-purple-600' },
          { status: 'cancelled', label: 'Batalkan Pesanan', color: 'bg-red-600' }
        ]
      case 'shipped':
        return [
          { status: 'completed', label: 'Selesaikan Pesanan', color: 'bg-green-600' }
        ]
      default:
        return []
    }
  }

  const handleStatusUpdate = (newStatus: Order['status']) => {
    onUpdateStatus(order.id, newStatus)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              {getStatusIcon(order.status)}
              <span>Detail Pesanan</span>
            </div>
            <Badge className={`text-sm ${getStatusColor(order.status)}`}>
              {getStatusText(order.status)}
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Nomor Pesanan: {order.orderNumber}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Customer Information */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <User className="w-4 h-4" />
              Informasi Pelanggan
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-gray-500" />
                <span className="font-medium">{order.customerName}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-gray-500" />
                <span>{order.customerEmail}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-gray-500" />
                <span>{order.customerPhone}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-gray-500" />
                <span>{order.createdAt}</span>
              </div>
            </div>
            <div className="mt-3 flex items-start gap-2">
              <MapPin className="w-4 h-4 text-gray-500 mt-0.5" />
              <span className="text-sm">{order.customerAddress}</span>
            </div>
          </div>

          {/* Order Items */}
          <div>
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <Package className="w-4 h-4" />
              Produk yang Dipesan
            </h3>
            <div className="space-y-3">
              {order.items.map((item) => (
                <div key={item.id} className="flex gap-3 p-3 border rounded-lg">
                  <div className="w-16 h-16 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium">{item.name}</h4>
                    <p className="text-sm text-gray-500">
                      {formatCurrency(item.price)} x {item.quantity}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">
                      {formatCurrency(item.price * item.quantity)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Order Summary */}
          <div>
            <h3 className="font-semibold mb-3">Ringkasan Pembayaran</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Subtotal ({order.items.length} item)</span>
                <span>{formatCurrency(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Biaya Pengiriman</span>
                <span>
                  {order.shipping === 0 ? (
                    <Badge variant="secondary" className="text-xs">Gratis</Badge>
                  ) : (
                    formatCurrency(order.shipping)
                  )}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Pajak (11%)</span>
                <span>{formatCurrency(order.tax)}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span className="text-primary">{formatCurrency(order.total)}</span>
              </div>
            </div>
          </div>

          {/* Payment Method */}
          <div className="bg-blue-50 rounded-lg p-4">
            <h3 className="font-semibold mb-2 flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Metode Pembayaran
            </h3>
            <Badge variant="outline" className="text-sm">
              {getPaymentMethodText(order.paymentMethod)}
            </Badge>
          </div>

          {/* Notes */}
          {order.notes && (
            <div className="bg-yellow-50 rounded-lg p-4">
              <h3 className="font-semibold mb-2">Catatan Pesanan</h3>
              <p className="text-sm text-gray-700">{order.notes}</p>
            </div>
          )}

          {/* Status Actions */}
          <div className="space-y-3">
            <h3 className="font-semibold">Update Status Pesanan</h3>
            <div className="flex flex-wrap gap-2">
              {getNextStatus(order.status).map((action) => (
                <Button
                  key={action.status}
                  onClick={() => handleStatusUpdate(action.status as Order['status'])}
                  className={`${action.color} hover:opacity-90`}
                >
                  {action.label}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}