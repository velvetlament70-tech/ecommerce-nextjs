'use client'

import { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { X, Settings, Cookie, Shield, Eye, Target } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'

interface CookiePreferences {
  essential: boolean
  performance: boolean
  functional: boolean
  marketing: boolean
}

interface CookieConsentProps {
  onAccept?: (preferences: CookiePreferences) => void
  onDecline?: () => void
  onCustomize?: () => void
}

export function CookieConsent({ onAccept, onDecline, onCustomize }: CookieConsentProps) {
  const { t } = useTranslation()
  const { toast } = useToast()
  const [isVisible, setIsVisible] = useState(false)
  const [showCustomize, setShowCustomize] = useState(false)
  const [preferences, setPreferences] = useState<CookiePreferences>({
    essential: true,
    performance: false,
    functional: false,
    marketing: false
  })

  useEffect(() => {
    // Check if user has already made a choice
    const consent = localStorage.getItem('cookie-consent')
    if (!consent) {
      // Show consent banner after a short delay
      const timer = setTimeout(() => {
        setIsVisible(true)
      }, 1000)
      return () => clearTimeout(timer)
    }
  }, [])

  const handleAcceptAll = () => {
    const allPreferences: CookiePreferences = {
      essential: true,
      performance: true,
      functional: true,
      marketing: true
    }
    savePreferences(allPreferences)
    setIsVisible(false)
    onAccept?.(allPreferences)
    
    toast({
      title: "Cookie Preferences Saved",
      description: "You've accepted all cookies. You can change this anytime in settings.",
    })
  }

  const handleAcceptSelected = () => {
    savePreferences(preferences)
    setIsVisible(false)
    setShowCustomize(false)
    onAccept?.(preferences)
    
    toast({
      title: "Cookie Preferences Saved",
      description: "Your cookie preferences have been saved.",
    })
  }

  const handleDecline = () => {
    const minimalPreferences: CookiePreferences = {
      essential: true,
      performance: false,
      functional: false,
      marketing: false
    }
    savePreferences(minimalPreferences)
    setIsVisible(false)
    onDecline?.()
    
    toast({
      title: "Only Essential Cookies",
      description: "Only essential cookies will be used.",
    })
  }

  const savePreferences = (prefs: CookiePreferences) => {
    localStorage.setItem('cookie-consent', JSON.stringify(prefs))
    localStorage.setItem('cookie-consent-date', new Date().toISOString())
    
    // Apply cookie preferences
    applyCookiePreferences(prefs)
  }

  const applyCookiePreferences = (prefs: CookiePreferences) => {
    // In a real implementation, this would:
    // 1. Enable/disable analytics scripts
    // 2. Enable/disable marketing pixels
    // 3. Enable/disable functional cookies
    // 4. Update cookie settings for third-party services
    
    // For demonstration, we'll just log the preferences
    console.log('Cookie preferences applied:', prefs)
    
    // Trigger custom event for other components to listen to
    window.dispatchEvent(new CustomEvent('cookiePreferencesChanged', { 
      detail: prefs 
    }))
  }

  const updatePreference = (key: keyof CookiePreferences, value: boolean) => {
    setPreferences(prev => ({ ...prev, [key]: value }))
  }

  if (!isVisible) return null

  return (
    <>
      {/* Cookie Consent Banner */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg z-50 p-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3 flex-1">
            <Cookie className="w-6 h-6 text-blue-600 mt-1 flex-shrink-0" />
            <div className="text-sm text-gray-700">
              <p className="font-medium mb-1">
                We use cookies to enhance your experience and analyze site traffic.
              </p>
              <p className="text-xs text-gray-600">
                By clicking "Accept All", you consent to our use of cookies. 
                <button 
                  onClick={() => setShowCustomize(true)}
                  className="text-blue-600 hover:underline ml-1"
                >
                  Customize your preferences
                </button>
              </p>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleDecline}
            >
              Decline
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setShowCustomize(true)}
            >
              Customize
            </Button>
            <Button 
              size="sm" 
              onClick={handleAcceptAll}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Accept All
            </Button>
          </div>
        </div>
      </div>

      {/* Customization Modal */}
      {showCustomize && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-2xl max-h-[80vh] overflow-y-auto">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Cookie Preferences
              </CardTitle>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setShowCustomize(false)}
              >
                <X className="w-4 h-4" />
              </Button>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="text-sm text-gray-600">
                <p>
                  We use cookies to enhance your browsing experience, serve personalized content, 
                  and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.
                </p>
              </div>

              {/* Essential Cookies */}
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Shield className="w-5 h-5 text-red-600" />
                    <div>
                      <h4 className="font-medium">Essential Cookies</h4>
                      <p className="text-sm text-gray-600">Required for the website to function</p>
                    </div>
                  </div>
                  <Switch 
                    checked={preferences.essential}
                    disabled={true}
                  />
                </div>
                <p className="text-sm text-gray-600">
                  These cookies are necessary for the website to function and cannot be switched off. 
                  They are usually only set in response to actions made by you.
                </p>
                <div className="mt-2">
                  <Badge variant="secondary" className="text-xs">Always Active</Badge>
                </div>
              </div>

              {/* Performance Cookies */}
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Eye className="w-5 h-5 text-blue-600" />
                    <div>
                      <h4 className="font-medium">Performance Cookies</h4>
                      <p className="text-sm text-gray-600">Help us improve our website</p>
                    </div>
                  </div>
                  <Switch 
                    checked={preferences.performance}
                    onCheckedChange={(checked) => updatePreference('performance', checked)}
                  />
                </div>
                <p className="text-sm text-gray-600">
                  These cookies allow us to count visits and traffic sources so we can measure and 
                  improve the performance of our site.
                </p>
                <div className="mt-2 space-y-1">
                  <p className="text-xs text-gray-500">Used for:</p>
                  <ul className="text-xs text-gray-500 list-disc pl-4">
                    <li>Google Analytics</li>
                    <li>Hotjar</li>
                    <li>Vercel Analytics</li>
                  </ul>
                </div>
              </div>

              {/* Functional Cookies */}
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Cookie className="w-5 h-5 text-green-600" />
                    <div>
                      <h4 className="font-medium">Functional Cookies</h4>
                      <p className="text-sm text-gray-600">Enhanced functionality and personalization</p>
                    </div>
                  </div>
                  <Switch 
                    checked={preferences.functional}
                    onCheckedChange={(checked) => updatePreference('functional', checked)}
                  />
                </div>
                <p className="text-sm text-gray-600">
                  These cookies enable the website to provide enhanced functionality and personalization.
                </p>
                <div className="mt-2 space-y-1">
                  <p className="text-xs text-gray-500">Used for:</p>
                  <ul className="text-xs text-gray-500 list-disc pl-4">
                    <li>Remembering preferences</li>
                    <li>Language and currency settings</li>
                    <li>Saved items in wishlist</li>
                  </ul>
                </div>
              </div>

              {/* Marketing Cookies */}
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-purple-600" />
                    <div>
                      <h4 className="font-medium">Marketing Cookies</h4>
                      <p className="text-sm text-gray-600">Personalized advertising and content</p>
                    </div>
                  </div>
                  <Switch 
                    checked={preferences.marketing}
                    onCheckedChange={(checked) => updatePreference('marketing', checked)}
                  />
                </div>
                <p className="text-sm text-gray-600">
                  These cookies may be set through our site by our advertising partners to build a profile 
                  of your interests and show you relevant adverts.
                </p>
                <div className="mt-2 space-y-1">
                  <p className="text-xs text-gray-500">Used for:</p>
                  <ul className="text-xs text-gray-500 list-disc pl-4">
                    <li>Google Ads</li>
                    <li>Facebook Pixel</li>
                    <li>LinkedIn Insight Tag</li>
                  </ul>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-2 pt-4 border-t">
                <Button 
                  variant="outline" 
                  onClick={() => setShowCustomize(false)}
                >
                  Cancel
                </Button>
                <Button 
                  variant="outline" 
                  onClick={handleAcceptSelected}
                >
                  Accept Selected
                </Button>
                <Button 
                  onClick={handleAcceptAll}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Accept All
                </Button>
              </div>

              {/* Additional Links */}
              <div className="text-xs text-gray-500 text-center space-x-4">
                <a href="/privacy" className="hover:underline">Privacy Policy</a>
                <a href="/cookies" className="hover:underline">Cookie Policy</a>
                <a href="/terms" className="hover:underline">Terms of Service</a>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  )
}

// Hook to check cookie preferences
export function useCookiePreferences() {
  const [preferences, setPreferences] = useState<CookiePreferences | null>(null)

  useEffect(() => {
    const consent = localStorage.getItem('cookie-consent')
    if (consent) {
      setPreferences(JSON.parse(consent))
    }

    const handlePreferencesChange = (event: CustomEvent) => {
      setPreferences(event.detail)
    }

    window.addEventListener('cookiePreferencesChanged', handlePreferencesChange as EventListener)
    return () => {
      window.removeEventListener('cookiePreferencesChanged', handlePreferencesChange as EventListener)
    }
  }, [])

  const hasConsent = (category: keyof CookiePreferences) => {
    return preferences?.[category] || false
  }

  return { preferences, hasConsent }
}