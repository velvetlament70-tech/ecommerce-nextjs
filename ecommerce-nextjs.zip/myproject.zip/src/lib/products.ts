import productsData from '@/data/products.json'

export interface Product {
  id: string
  name: string
  slug: string
  price: number
  comparePrice?: number
  description: string
  shortDescription: string
  category: string
  subcategory: string
  brand: string
  sku: string
  stock: number
  rating: number
  reviews: number
  images: string[]
  badge?: string
  tags: string[]
  specifications: Record<string, string>
  features: string[]
  weight: number
  dimensions: {
    length: number
    width: number
    height: number
  }
  isActive: boolean
  featured: boolean
  createdAt: string
  updatedAt: string
}

export interface Category {
  id: string
  name: string
  slug: string
  description: string
  image: string
  productCount: number
  isActive: boolean
}

export interface ProductsResponse {
  products: Product[]
  categories: Category[]
}

class ProductService {
  private products: Product[]
  private categories: Category[]

  constructor() {
    this.products = productsData.products as Product[]
    this.categories = productsData.categories as Category[]
  }

  // Get all products
  getAllProducts(): Product[] {
    return this.products.filter(product => product.isActive)
  }

  // Get product by ID
  getProductById(id: string): Product | null {
    return this.products.find(product => product.id === id && product.isActive) || null
  }

  // Get product by slug
  getProductBySlug(slug: string): Product | null {
    return this.products.find(product => product.slug === slug && product.isActive) || null
  }

  // Get featured products
  getFeaturedProducts(limit?: number): Product[] {
    const featured = this.products.filter(product => product.isActive && product.featured)
    return limit ? featured.slice(0, limit) : featured
  }

  // Get products by category
  getProductsByCategory(category: string): Product[] {
    return this.products.filter(product => 
      product.isActive && product.category.toLowerCase() === category.toLowerCase()
    )
  }

  // Get products by brand
  getProductsByBrand(brand: string): Product[] {
    return this.products.filter(product => 
      product.isActive && product.brand.toLowerCase() === brand.toLowerCase()
    )
  }

  // Search products
  searchProducts(query: string): Product[] {
    const lowercaseQuery = query.toLowerCase()
    return this.products.filter(product => 
      product.isActive && (
        product.name.toLowerCase().includes(lowercaseQuery) ||
        product.description.toLowerCase().includes(lowercaseQuery) ||
        product.shortDescription.toLowerCase().includes(lowercaseQuery) ||
        product.tags.some(tag => tag.toLowerCase().includes(lowercaseQuery)) ||
        product.brand.toLowerCase().includes(lowercaseQuery) ||
        product.category.toLowerCase().includes(lowercaseQuery)
      )
    )
  }

  // Filter products
  filterProducts(filters: {
    category?: string
    brand?: string
    minPrice?: number
    maxPrice?: number
    minRating?: number
    tags?: string[]
    featured?: boolean
  }): Product[] {
    return this.products.filter(product => {
      if (!product.isActive) return false
      
      if (filters.category && product.category.toLowerCase() !== filters.category.toLowerCase()) {
        return false
      }
      
      if (filters.brand && product.brand.toLowerCase() !== filters.brand.toLowerCase()) {
        return false
      }
      
      if (filters.minPrice && product.price < filters.minPrice) {
        return false
      }
      
      if (filters.maxPrice && product.price > filters.maxPrice) {
        return false
      }
      
      if (filters.minRating && product.rating < filters.minRating) {
        return false
      }
      
      if (filters.tags && filters.tags.length > 0) {
        const hasMatchingTag = filters.tags.some(tag => 
          product.tags.some(productTag => 
            productTag.toLowerCase() === tag.toLowerCase()
          )
        )
        if (!hasMatchingTag) return false
      }
      
      if (filters.featured !== undefined && product.featured !== filters.featured) {
        return false
      }
      
      return true
    })
  }

  // Sort products
  sortProducts(products: Product[], sortBy: 'featured' | 'price-low' | 'price-high' | 'rating' | 'newest' | 'discount'): Product[] {
    const sorted = [...products]
    
    switch (sortBy) {
      case 'price-low':
        return sorted.sort((a, b) => a.price - b.price)
      case 'price-high':
        return sorted.sort((a, b) => b.price - a.price)
      case 'rating':
        return sorted.sort((a, b) => b.rating - a.rating)
      case 'newest':
        return sorted.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      case 'discount':
        return sorted.sort((a, b) => {
          const discountA = a.comparePrice ? ((a.comparePrice - a.price) / a.comparePrice) * 100 : 0
          const discountB = b.comparePrice ? ((b.comparePrice - b.price) / b.comparePrice) * 100 : 0
          return discountB - discountA
        })
      case 'featured':
      default:
        return sorted.sort((a, b) => {
          if (a.featured && !b.featured) return -1
          if (!a.featured && b.featured) return 1
          return 0
        })
    }
  }

  // Get product suggestions
  getProductSuggestions(query: string, limit: number = 5): Product[] {
    const results = this.searchProducts(query)
    return this.sortProducts(results, 'rating').slice(0, limit)
  }

  // Get related products
  getRelatedProducts(productId: string, limit: number = 4): Product[] {
    const product = this.getProductById(productId)
    if (!product) return []
    
    // Find products in same category
    const sameCategory = this.products.filter(p => 
      p.id !== productId && 
      p.isActive && 
      p.category === product.category
    )
    
    // If not enough products in same category, include products with same tags
    if (sameCategory.length < limit) {
      const sameTags = this.products.filter(p => 
        p.id !== productId && 
        p.isActive && 
        p.tags.some(tag => product.tags.includes(tag))
      )
      
      const combined = [...sameCategory, ...sameTags]
      const unique = combined.filter((product, index, self) => 
        index === self.findIndex(p => p.id === product.id)
      )
      
      return this.sortProducts(unique, 'rating').slice(0, limit)
    }
    
    return this.sortProducts(sameCategory, 'rating').slice(0, limit)
  }

  // Check if product is in stock
  isInStock(productId: string, quantity: number = 1): boolean {
    const product = this.getProductById(productId)
    return product ? product.stock >= quantity : false
  }

  // Get discount percentage
  getDiscountPercentage(product: Product): number {
    if (!product.comparePrice) return 0
    return Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100)
  }

  // Get all categories
  getAllCategories(): Category[] {
    return this.categories.filter(category => category.isActive)
  }

  // Get category by slug
  getCategoryBySlug(slug: string): Category | null {
    return this.categories.find(category => category.slug === slug && category.isActive) || null
  }

  // Get unique brands
  getUniqueBrands(): string[] {
    const brands = this.products
      .filter(product => product.isActive)
      .map(product => product.brand)
    return [...new Set(brands)].sort()
  }

  // Get unique tags
  getUniqueTags(): string[] {
    const tags = this.products
      .filter(product => product.isActive)
      .flatMap(product => product.tags)
    return [...new Set(tags)].sort()
  }

  // Get price range
  getPriceRange(): { min: number; max: number } {
    const prices = this.products
      .filter(product => product.isActive)
      .map(product => product.price)
    
    return {
      min: Math.min(...prices),
      max: Math.max(...prices)
    }
  }

  // Get products by price range
  getProductsByPriceRange(min: number, max: number): Product[] {
    return this.products.filter(product => 
      product.isActive && product.price >= min && product.price <= max
    )
  }

  // Get new arrivals (products created in last 30 days)
  getNewArrivals(days: number = 30): Product[] {
    const cutoffDate = new Date()
    cutoffDate.setDate(cutoffDate.getDate() - days)
    
    return this.products
      .filter(product => 
        product.isActive && new Date(product.createdAt) >= cutoffDate
      )
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
  }

  // Get best sellers (products with most reviews and high rating)
  getBestSellers(limit: number = 10): Product[] {
    return this.products
      .filter(product => product.isActive && product.rating >= 4.0 && product.reviews >= 10)
      .sort((a, b) => (b.reviews * b.rating) - (a.reviews * a.rating))
      .slice(0, limit)
  }

  // Get products on sale
  getProductsOnSale(): Product[] {
    return this.products.filter(product => 
      product.isActive && product.comparePrice && product.comparePrice > product.price
    )
  }
}

export const productService = new ProductService()
export default productService