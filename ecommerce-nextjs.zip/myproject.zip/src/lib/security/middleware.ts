// Security middleware for API routes
import { NextRequest, NextResponse } from 'next/server'
import { RateLimiter, CSRFProtection, InputSanitizer } from './sanitization'

// Rate limiting configuration
const RATE_LIMITS = {
  'api/auth': { maxRequests: 5, windowMs: 15 * 60 * 1000 }, // 5 requests per 15 minutes
  'api/contact': { maxRequests: 3, windowMs: 60 * 60 * 1000 }, // 3 requests per hour
  'api/subscribe': { maxRequests: 2, windowMs: 60 * 60 * 1000 }, // 2 requests per hour
  'default': { maxRequests: 100, windowMs: 15 * 60 * 1000 } // 100 requests per 15 minutes
}

// Security headers middleware
export function addSecurityHeaders(response: NextResponse): NextResponse {
  const headers = {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    ...response.headers
  }

  Object.entries(headers).forEach(([key, value]) => {
    response.headers.set(key, value)
  })

  return response
}

// Rate limiting middleware
export function rateLimit(request: NextRequest): { allowed: boolean; resetTime?: number } {
  const ip = getClientIP(request)
  const path = request.nextUrl.pathname
  
  // Find matching rate limit config
  let limitConfig = RATE_LIMITS.default
  for (const [pattern, config] of Object.entries(RATE_LIMITS)) {
    if (pattern !== 'default' && path.startsWith(pattern)) {
      limitConfig = config
      break
    }
  }

  return RateLimiter.checkLimit(ip, limitConfig.maxRequests, limitConfig.windowMs)
}

// Input validation middleware
export function validateInput(request: NextRequest): { valid: boolean; error?: string } {
  const url = request.nextUrl
  const method = request.method

  // Validate request method
  const allowedMethods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE']
  if (!allowedMethods.includes(method)) {
    return { valid: false, error: 'Method not allowed' }
  }

  // Validate URL length
  if (url.pathname.length > 2048) {
    return { valid: false, error: 'URL too long' }
  }

  // Validate query parameters
  for (const [key, value] of url.searchParams.entries()) {
    if (key.length > 100 || value.length > 1000) {
      return { valid: false, error: 'Invalid parameter length' }
    }

    // Sanitize parameter values
    const sanitized = InputSanitizer.sanitizeText(value)
    if (sanitized !== value) {
      return { valid: false, error: 'Invalid parameter value' }
    }
  }

  return { valid: true }
}

// CSRF protection middleware
export function validateCSRF(request: NextRequest): { valid: boolean; error?: string } {
  if (request.method === 'GET' || request.method === 'HEAD' || request.method === 'OPTIONS') {
    return { valid: true } // CSRF not needed for safe methods
  }

  const token = request.headers.get('x-csrf-token')
  const sessionId = request.headers.get('x-session-id')

  if (!token || !sessionId) {
    return { valid: false, error: 'CSRF token missing' }
  }

  if (!CSRFProtection.validateToken(sessionId, token)) {
    return { valid: false, error: 'Invalid CSRF token' }
  }

  return { valid: true }
}

// Get client IP address
function getClientIP(request: NextRequest): string {
  const forwarded = request.headers.get('x-forwarded-for')
  const realIP = request.headers.get('x-real-ip')
  const clientIP = request.ip

  if (forwarded) {
    return forwarded.split(',')[0].trim()
  }

  if (realIP) {
    return realIP.trim()
  }

  if (clientIP) {
    return clientIP
  }

  return 'unknown'
}

// Main security middleware
export function securityMiddleware(request: NextRequest) {
  // Add security headers to response
  const response = NextResponse.next()
  addSecurityHeaders(response)

  // Validate input
  const inputValidation = validateInput(request)
  if (!inputValidation.valid) {
    return NextResponse.json(
      { error: inputValidation.error },
      { status: 400 }
    )
  }

  // Rate limiting
  const rateLimitResult = rateLimit(request)
  if (!rateLimitResult.allowed) {
    return NextResponse.json(
      { error: 'Rate limit exceeded', resetTime: rateLimitResult.resetTime },
      { 
        status: 429,
        headers: {
          'Retry-After': Math.ceil((rateLimitResult.resetTime! - Date.now()) / 1000).toString()
        }
      }
    )
  }

  // CSRF protection
  const csrfValidation = validateCSRF(request)
  if (!csrfValidation.valid) {
    return NextResponse.json(
      { error: csrfValidation.error },
      { status: 403 }
    )
  }

  return response
}

// API route wrapper with security
export function withSecurity(handler: (req: NextRequest) => Promise<NextResponse>) {
  return async (request: NextRequest) => {
    try {
      // Apply security middleware
      const securityResult = securityMiddleware(request)
      if (securityResult.status !== 200) {
        return securityResult
      }

      // Execute the actual handler
      const response = await handler(request)
      
      // Add security headers to the response
      return addSecurityHeaders(response)
    } catch (error) {
      console.error('Security middleware error:', error)
      return NextResponse.json(
        { error: 'Internal server error' },
        { status: 500 }
      )
    }
  }
}

// Export utilities for use in API routes
export { getClientIP, RateLimiter, CSRFProtection, InputSanitizer }