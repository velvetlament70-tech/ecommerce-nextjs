import { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import { db } from "@/lib/db"
import { UserRole } from "@prisma/client"

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        // For demo purposes, we'll use a simple authentication
        // In production, you'd hash passwords and verify them
        const user = await db.user.findUnique({
          where: {
            email: credentials.email
          },
          include: {
            store: true
          }
        })

        if (!user) {
          return null
        }

        // Simple password check (in production, use bcrypt)
        if (credentials.password === "password123") {
          return {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            storeId: user.store?.id,
            storeName: user.store?.name
          }
        }

        return null
      }
    })
  ],
  session: {
    strategy: "jwt"
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = user.role
        token.storeId = user.storeId
        token.storeName = user.storeName
      }
      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.sub!
        session.user.role = token.role as UserRole
        session.user.storeId = token.storeId as string | undefined
        session.user.storeName = token.storeName as string | undefined
      }
      return session
    }
  },
  pages: {
    signIn: "/auth/signin",
    signUp: "/auth/signup"
  }
}