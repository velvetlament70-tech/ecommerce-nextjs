export interface IntegrationConfig {
  id: string
  name: string
  description: string
  category: 'shipping' | 'maps' | 'notification' | 'marketplace' | 'payment'
  status: 'active' | 'inactive' | 'error' | 'testing'
  credentials: Record<string, any>
  settings: Record<string, any>
  webhooks: WebhookConfig[]
  lastSync?: string
  error?: string
}

export interface WebhookConfig {
  id: string
  event: string
  url: string
  secret?: string
  active: boolean
  retryCount: number
}

export interface GoogleMapsConfig {
  apiKey: string
  defaultLocation: {
    lat: number
    lng: number
    address: string
  }
  mapStyle: 'roadmap' | 'satellite' | 'hybrid' | 'terrain'
  enableGeocoding: boolean
  enablePlaces: boolean
  enableDirections: boolean
}

export interface RajaOngkirConfig {
  apiKey: string
  origin: string
  courier: string[]
  weightUnit: 'gram' | 'kg'
  insuranceEnabled: boolean
  codEnabled: boolean
  markupPercentage: number
}

export interface WhatsAppConfig {
  phoneNumber: string
  apiKey: string
  businessProfile: {
    name: string
    email: string
    address: string
    description: string
  }
  templates: MessageTemplate[]
  autoReply: boolean
  greetingMessage: string
}

export interface TelegramConfig {
  botToken: string
  chatId: string
  parseMode: 'HTML' | 'Markdown'
  enableNotifications: boolean
  enableCommands: boolean
  welcomeMessage: string
}

export interface MarketplaceConfig {
  platform: 'tokopedia' | 'shopee' | 'bukalapak' | 'lazada'
  shopId: string
  apiKey: string
  secretKey: string
  syncProducts: boolean
  syncOrders: boolean
  syncInventory: boolean
  priceMarkup: number
  autoAcceptOrders: boolean
}

export interface MessageTemplate {
  id: string
  name: string
  content: string
  variables: string[]
  category: 'order' | 'payment' | 'shipping' | 'promotion'
}

export interface ShippingRate {
  service: string
  description: string
  cost: number
  etd: string
  courier: string
  insurance?: number
}

export interface AddressComponent {
  long_name: string
  short_name: string
  types: string[]
}

export interface GeocodeResult {
  address_components: AddressComponent[]
  formatted_address: string
  geometry: {
    location: {
      lat: number
      lng: number
    }
  }
  place_id: string
  types: string[]
}

export interface MarketplaceProduct {
  id: string
  name: string
  price: number
  stock: number
  description: string
  images: string[]
  category: string
  status: 'active' | 'inactive' | 'out_of_stock'
  url: string
  platform: string
}

export interface MarketplaceOrder {
  id: string
  orderNumber: string
  customerName: string
  customerPhone: string
  customerAddress: string
  items: {
    productId: string
    quantity: number
    price: number
  }[]
  totalAmount: number
  status: 'pending' | 'paid' | 'shipped' | 'completed' | 'cancelled'
  platform: string
  createdAt: string
}

// Default configurations
export const DEFAULT_INTEGRATIONS: IntegrationConfig[] = [
  {
    id: 'google-maps',
    name: 'Google Maps',
    description: 'Integrasi Google Maps untuk layanan peta dan geolokasi',
    category: 'maps',
    status: 'inactive',
    credentials: {
      apiKey: ''
    },
    settings: {
      defaultLocation: {
        lat: -6.2088,
        lng: 106.8456,
        address: 'Jakarta, Indonesia'
      },
      mapStyle: 'roadmap',
      enableGeocoding: true,
      enablePlaces: true,
      enableDirections: true
    },
    webhooks: []
  },
  {
    id: 'rajaongkir',
    name: 'RajaOngkir',
    description: 'API untuk cek ongkos kirim berbagai kurir',
    category: 'shipping',
    status: 'inactive',
    credentials: {
      apiKey: ''
    },
    settings: {
      origin: '1', // Jakarta
      courier: ['jne', 'tiki', 'pos'],
      weightUnit: 'gram',
      insuranceEnabled: false,
      codEnabled: false,
      markupPercentage: 0
    },
    webhooks: []
  },
  {
    id: 'whatsapp',
    name: 'WhatsApp Business',
    description: 'Notifikasi otomatis via WhatsApp',
    category: 'notification',
    status: 'inactive',
    credentials: {
      phoneNumber: '',
      apiKey: ''
    },
    settings: {
      businessProfile: {
        name: '',
        email: '',
        address: '',
        description: ''
      },
      templates: [],
      autoReply: true,
      greetingMessage: 'Halo! Terima kasih telah menghubungi toko kami. Ada yang bisa kami bantu?'
    },
    webhooks: []
  },
  {
    id: 'telegram',
    name: 'Telegram Bot',
    description: 'Notifikasi dan customer service via Telegram',
    category: 'notification',
    status: 'inactive',
    credentials: {
      botToken: '',
      chatId: ''
    },
    settings: {
      parseMode: 'HTML',
      enableNotifications: true,
      enableCommands: true,
      welcomeMessage: 'Selamat datang di toko kami! 🛍️'
    },
    webhooks: []
  },
  {
    id: 'tokopedia',
    name: 'Tokopedia',
    description: 'Sinkronisasi produk dan pesanan dengan Tokopedia',
    category: 'marketplace',
    status: 'inactive',
    credentials: {
      shopId: '',
      apiKey: '',
      secretKey: ''
    },
    settings: {
      syncProducts: true,
      syncOrders: true,
      syncInventory: true,
      priceMarkup: 10,
      autoAcceptOrders: false
    },
    webhooks: []
  },
  {
    id: 'shopee',
    name: 'Shopee',
    description: 'Sinkronisasi produk dan pesanan dengan Shopee',
    category: 'marketplace',
    status: 'inactive',
    credentials: {
      shopId: '',
      apiKey: '',
      secretKey: ''
    },
    settings: {
      syncProducts: true,
      syncOrders: true,
      syncInventory: true,
      priceMarkup: 10,
      autoAcceptOrders: false
    },
    webhooks: []
  }
]

export const DEFAULT_MESSAGE_TEMPLATES: MessageTemplate[] = [
  {
    id: 'order-confirmation',
    name: 'Konfirmasi Pesanan',
    content: 'Halo {{customerName}}! Pesanan Anda dengan nomor {{orderNumber}} telah kami terima. Total: {{totalAmount}}. Terima kasih! 🛍️',
    variables: ['customerName', 'orderNumber', 'totalAmount'],
    category: 'order'
  },
  {
    id: 'payment-confirmation',
    name: 'Konfirmasi Pembayaran',
    content: 'Pembayaran untuk pesanan {{orderNumber}} telah kami terima. Pesanan Anda akan segera diproses. 📦',
    variables: ['orderNumber'],
    category: 'payment'
  },
  {
    id: 'shipping-notification',
    name: 'Notifikasi Pengiriman',
    content: 'Pesanan {{orderNumber}} telah dikirim! Nomor resi: {{trackingNumber}}. Estimasi sampai: {{estimatedDelivery}} 🚚',
    variables: ['orderNumber', 'trackingNumber', 'estimatedDelivery'],
    category: 'shipping'
  },
  {
    id: 'promotion',
    name: 'Promosi',
    content: '🎉 PROMO SPESIAL! Dapatkan diskon {{discount}}% untuk produk {{productName}}. Buruan checkout sebelum kehabisan!',
    variables: ['discount', 'productName'],
    category: 'promotion'
  }
]