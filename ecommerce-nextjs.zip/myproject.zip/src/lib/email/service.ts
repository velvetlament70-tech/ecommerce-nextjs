import nodemailer from 'nodemailer'
import { db } from '@/lib/db'

interface EmailOptions {
  to: string
  subject: string
  template: string
  variables?: Record<string, any>
  attachments?: Array<{
    filename: string
    path?: string
    content?: Buffer | string
  }>
}

class EmailService {
  private transporter: nodemailer.Transporter

  constructor() {
    this.transporter = nodemailer.createTransporter({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    })
  }

  private async getTemplate(templateName: string, language: string = 'en'): Promise<any> {
    try {
      const template = await db.emailTemplate.findFirst({
        where: {
          name: templateName,
          language: language,
          isActive: true
        }
      })

      if (!template) {
        // Fallback to default templates
        return this.getDefaultTemplate(templateName, language)
      }

      return template
    } catch (error) {
      console.error('Failed to fetch email template:', error)
      return this.getDefaultTemplate(templateName, language)
    }
  }

  private getDefaultTemplate(templateName: string, language: string) {
    const templates = {
      'order_confirmation': {
        subject: language === 'id' ? 'Konfirmasi Pesanan' : 'Order Confirmation',
        content: this.getOrderConfirmationTemplate(language)
      },
      'password_reset': {
        subject: language === 'id' ? 'Reset Kata Sandi' : 'Password Reset',
        content: this.getPasswordResetTemplate(language)
      },
      'welcome_email': {
        subject: language === 'id' ? 'Selamat Datang di ShopHub' : 'Welcome to ShopHub',
        content: this.getWelcomeTemplate(language)
      },
      'shipping_update': {
        subject: language === 'id' ? 'Update Pengiriman' : 'Shipping Update',
        content: this.getShippingUpdateTemplate(language)
      },
      'review_request': {
        subject: language === 'id' ? 'Request Ulasan' : 'Review Request',
        content: this.getReviewRequestTemplate(language)
      }
    }

    return templates[templateName as keyof typeof templates] || {
      subject: 'Notification',
      content: '<p>This is a notification from ShopHub.</p>'
    }
  }

  private replaceVariables(content: string, variables: Record<string, any>): string {
    let result = content
    for (const [key, value] of Object.entries(variables)) {
      const regex = new RegExp(`{{\\s*${key}\\s*}}`, 'g')
      result = result.replace(regex, String(value))
    }
    return result
  }

  async sendEmail(options: EmailOptions): Promise<boolean> {
    try {
      // Log email attempt
      await this.logEmail(options.to, options.subject, options.template, options.variables, 'PENDING')

      // Get template
      const template = await this.getTemplate(options.template, options.variables?.language || 'en')
      
      // Replace variables in subject and content
      const subject = this.replaceVariables(template.subject, options.variables || {})
      const html = this.replaceVariables(template.content, options.variables || {})

      // Send email
      const mailOptions = {
        from: process.env.SMTP_FROM || '"ShopHub" <noreply@shophub.com>',
        to: options.to,
        subject,
        html,
        attachments: options.attachments
      }

      const result = await this.transporter.sendMail(mailOptions)

      // Update email log
      await this.updateEmailLog(options.to, options.subject, 'SENT', null, new Date())

      console.log('Email sent successfully:', result.messageId)
      return true
    } catch (error) {
      console.error('Failed to send email:', error)
      
      // Update email log with error
      await this.updateEmailLog(options.to, options.subject, 'FAILED', String(error))
      
      return false
    }
  }

  private async logEmail(to: string, subject: string, template: string, variables: Record<string, any> | undefined, status: string) {
    try {
      await db.emailLog.create({
        data: {
          to,
          subject,
          template,
          variables: variables ? JSON.stringify(variables) : null,
          status: status as any
        }
      })
    } catch (error) {
      console.error('Failed to log email:', error)
    }
  }

  private async updateEmailLog(to: string, subject: string, status: string, error: string | null, sentAt?: Date) {
    try {
      await db.emailLog.updateMany({
        where: {
          to,
          subject,
          status: 'PENDING'
        },
        data: {
          status: status as any,
          error,
          sentAt
        }
      })
    } catch (error) {
      console.error('Failed to update email log:', error)
    }
  }

  // Template methods
  private getOrderConfirmationTemplate(language: string): string {
    if (language === 'id') {
      return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Konfirmasi Pesanan #{{orderNumber}}</h2>
          <p>Terima kasih telah berbelanja di ShopHub!</p>
          <p>Pesanan Anda telah dikonfirmasi dan akan segera diproses.</p>
          
          <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
            <h3>Detail Pesanan:</h3>
            <p><strong>Nama:</strong> {{customerName}}</p>
            <p><strong>Email:</strong> {{customerEmail}}</p>
            <p><strong>Total:</strong> Rp{{total}}</p>
          </div>
          
          <p>Anda dapat melacak status pesanan Anda di dashboard akun ShopHub.</p>
          <p>Jika ada pertanyaan, jangan ragu menghubungi kami.</p>
          
          <p>Terima kasih,<br>Tim ShopHub</p>
        </div>
      `
    }

    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">Order Confirmation #{{orderNumber}}</h2>
        <p>Thank you for shopping with ShopHub!</p>
        <p>Your order has been confirmed and will be processed shortly.</p>
        
        <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
          <h3>Order Details:</h3>
          <p><strong>Name:</strong> {{customerName}}</p>
          <p><strong>Email:</strong> {{customerEmail}}</p>
          <p><strong>Total:</strong> ${{total}}</p>
        </div>
        
        <p>You can track your order status in your ShopHub dashboard.</p>
        <p>If you have any questions, please don't hesitate to contact us.</p>
        
        <p>Best regards,<br>The ShopHub Team</p>
      </div>
    `
  }

  private getPasswordResetTemplate(language: string): string {
    if (language === 'id') {
      return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Reset Kata Sandi</h2>
          <p>Anda menerima email ini karena kami menerima permintaan reset kata sandi untuk akun Anda.</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="{{resetLink}}" style="background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px;">
              Reset Kata Sandi
            </a>
          </div>
          
          <p>Link ini akan kadaluarsa dalam 1 jam.</p>
          <p>Jika Anda tidak meminta reset kata sandi, abaikan email ini.</p>
          
          <p>Terima kasih,<br>Tim ShopHub</p>
        </div>
      `
    }

    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">Password Reset</h2>
        <p>You're receiving this email because we received a password reset request for your account.</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="{{resetLink}}" style="background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px;">
            Reset Password
          </a>
        </div>
        
        <p>This link will expire in 1 hour.</p>
        <p>If you didn't request a password reset, please ignore this email.</p>
        
        <p>Best regards,<br>The ShopHub Team</p>
      </div>
    `
  }

  private getWelcomeTemplate(language: string): string {
    if (language === 'id') {
      return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Selamat Datang di ShopHub!</h2>
          <p>Selamat datang {{userName}}!</p>
          <p>Terima kasih telah bergabung dengan ShopHub. Kami sangat senang memiliki Anda sebagai bagian dari komunitas kami.</p>
          
          <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
            <h3>Apa selanjutnya?</h3>
            <ul>
              <li>Lengkapi profil Anda</li>
              <li>Jelajahi produk menarik</li>
              <li>Buat toko Anda jika Anda adalah penjual</li>
              <li>Bergabung dengan forum komunitas</li>
            </ul>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="{{dashboardLink}}" style="background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px;">
              Mulai Berbelanja
            </a>
          </div>
          
          <p>Jika ada pertanyaan, tim dukungan kami siap membantu.</p>
          
          <p>Terima kasih,<br>Tim ShopHub</p>
        </div>
      `
    }

    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">Welcome to ShopHub!</h2>
        <p>Welcome {{userName}}!</p>
        <p>Thank you for joining ShopHub. We're excited to have you as part of our community.</p>
        
        <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
          <h3>What's next?</h3>
          <ul>
            <li>Complete your profile</li>
            <li>Explore our products</li>
            <li>Create your store if you're a seller</li>
            <li>Join our community forum</li>
          </ul>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="{{dashboardLink}}" style="background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px;">
            Start Shopping
          </a>
        </div>
        
        <p>If you have any questions, our support team is here to help.</p>
        
        <p>Best regards,<br>The ShopHub Team</p>
      </div>
    `
  }

  private getShippingUpdateTemplate(language: string): string {
    if (language === 'id') {
      return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Update Pengiriman Pesanan #{{orderNumber}}</h2>
          <p>Pesanan Anda telah {{status}}!</p>
          
          <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
            <h3>Detail Pengiriman:</h3>
            <p><strong>Status:</strong> {{status}}</p>
            <p><strong>Nomor Tracking:</strong> {{trackingNumber}}</p>
            <p><strong>Kurir:</strong> {{courier}}</p>
            <p><strong>Perkiraan Tiba:</strong> {{estimatedDelivery}}</p>
          </div>
          
          {{#if trackingLink}}
          <div style="text-align: center; margin: 30px 0;">
            <a href="{{trackingLink}}" style="background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px;">
              Lacak Pengiriman
            </a>
          </div>
          {{/if}}
          
          <p>Terima kasih telah berbelanja di ShopHub!</p>
          
          <p>Terima kasih,<br>Tim ShopHub</p>
        </div>
      `
    }

    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">Shipping Update for Order #{{orderNumber}}</h2>
        <p>Your order has been {{status}}!</p>
        
        <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
          <h3>Shipping Details:</h3>
          <p><strong>Status:</strong> {{status}}</p>
          <p><strong>Tracking Number:</strong> {{trackingNumber}}</p>
          <p><strong>Carrier:</strong> {{courier}}</p>
          <p><strong>Estimated Delivery:</strong> {{estimatedDelivery}}</p>
        </div>
        
        {{#if trackingLink}}
        <div style="text-align: center; margin: 30px 0;">
          <a href="{{trackingLink}}" style="background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px;">
            Track Package
          </a>
        </div>
        {{/if}}
        
        <p>Thank you for shopping with ShopHub!</p>
        
        <p>Best regards,<br>The ShopHub Team</p>
      </div>
    `
  }

  private getReviewRequestTemplate(language: string): string {
    if (language === 'id') {
      return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Bagaimana Pengalaman Anda?</h2>
          <p>Kami ingin mendengar tentang pengalaman Anda dengan pesanan #{{orderNumber}}.</p>
          
          <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
            <h3>Produk yang Dibeli:</h3>
            {{#each products}}
            <p><strong>{{name}}</strong> - {{quantity}}x</p>
            {{/each}}
          </div>
          
          <p>Ulasan Anda membantu penjual lain dan komunitas ShopHub.</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="{{reviewLink}}" style="background: #ffc107; color: black; padding: 12px 24px; text-decoration: none; border-radius: 4px;">
              Tulis Ulasan
            </a>
          </div>
          
          <p>Terima kasih telah memilih ShopHub!</p>
          
          <p>Terima kasih,<br>Tim ShopHub</p>
        </div>
      `
    }

    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">How Was Your Experience?</h2>
        <p>We'd love to hear about your experience with order #{{orderNumber}}.</p>
        
        <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
          <h3>Products Purchased:</h3>
          {{#each products}}
          <p><strong>{{name}}</strong> - {{quantity}}x</p>
          {{/each}}
        </div>
        
        <p>Your review helps other sellers and the ShopHub community.</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="{{reviewLink}}" style="background: #ffc107; color: black; padding: 12px 24px; text-decoration: none; border-radius: 4px;">
            Write a Review
          </a>
        </div>
        
        <p>Thank you for choosing ShopHub!</p>
        
        <p>Best regards,<br>The ShopHub Team</p>
      </div>
    `
  }

  // Convenience methods
  async sendOrderConfirmation(orderData: any) {
    return this.sendEmail({
      to: orderData.customerEmail,
      subject: '',
      template: 'order_confirmation',
      variables: {
        ...orderData,
        language: orderData.language || 'en'
      }
    })
  }

  async sendPasswordReset(email: string, resetLink: string, language: string = 'en') {
    return this.sendEmail({
      to: email,
      subject: '',
      template: 'password_reset',
      variables: {
        resetLink,
        language
      }
    })
  }

  async sendWelcomeEmail(userData: any) {
    return this.sendEmail({
      to: userData.email,
      subject: '',
      template: 'welcome_email',
      variables: {
        ...userData,
        dashboardLink: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,
        language: userData.language || 'en'
      }
    })
  }

  async sendShippingUpdate(orderData: any) {
    return this.sendEmail({
      to: orderData.customerEmail,
      subject: '',
      template: 'shipping_update',
      variables: {
        ...orderData,
        language: orderData.language || 'en'
      }
    })
  }

  async sendReviewRequest(orderData: any) {
    return this.sendEmail({
      to: orderData.customerEmail,
      subject: '',
      template: 'review_request',
      variables: {
        ...orderData,
        reviewLink: `${process.env.NEXT_PUBLIC_APP_URL}/review/${orderData.orderId}`,
        language: orderData.language || 'en'
      }
    })
  }
}

export const emailService = new EmailService()