export const BRAND_CONFIG = {
  name: "ShopHub",
  tagline: "Platform E-Commerce Terpercaya untuk Bisnis Modern",
  description: "Platform e-commerce lengkap dengan fitur toko online, manajemen produk, dan sistem pembayaran yang aman",
  
  // Warna brand
  colors: {
    primary: {
      50: '#eff6ff',
      100: '#dbeafe',
      500: '#3b82f6',
      600: '#2563eb',
      700: '#1d4ed8',
      900: '#1e3a8a'
    },
    secondary: {
      50: '#f0fdfa',
      100: '#ccfbf1',
      500: '#14b8a6',
      600: '#0d9488',
      700: '#0f766e',
      900: '#134e4a'
    },
    accent: {
      500: '#f59e0b',
      600: '#d97706'
    }
  },
  
  // Contact info
  contact: {
    email: 'info@shophub.com',
    phone: '+62 812-3456-7890',
    address: 'Jakarta, Indonesia',
    social: {
      facebook: 'https://facebook.com/shophub',
      twitter: 'https://twitter.com/shophub',
      instagram: 'https://instagram.com/shophub',
      linkedin: 'https://linkedin.com/company/shophub'
    }
  },
  
  // Business info
  business: {
    founded: '2024',
    version: '1.0.0',
    license: 'MIT',
    author: 'ShopHub Team'
  }
}

export const SEO_CONFIG = {
  title: `${BRAND_CONFIG.name} - ${BRAND_CONFIG.tagline}`,
  description: BRAND_CONFIG.description,
  keywords: [
    'e-commerce',
    'online store',
    'toko online',
    'marketplace',
    'jual beli online',
    'shopping cart',
    'payment gateway',
    'product management',
    'Indonesia'
  ],
  author: BRAND_CONFIG.business.author,
  viewport: 'width=device-width, initial-scale=1',
  robots: 'index, follow',
  ogImage: '/logo.png',
  twitterCard: 'summary_large_image'
}