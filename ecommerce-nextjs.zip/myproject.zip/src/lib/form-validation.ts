// Comprehensive Form Validation System
export interface ValidationRule {
  required?: boolean
  minLength?: number
  maxLength?: number
  pattern?: RegExp
  email?: boolean
  phone?: boolean
  numeric?: boolean
  alphanumeric?: boolean
  match?: string // Field name to match (for password confirmation)
  custom?: (value: string) => string | null
}

export interface ValidationField {
  [fieldName: string]: ValidationRule
}

export interface ValidationErrors {
  [fieldName: string]: string[]
}

export class FormValidator {
  private static readonly EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  private static readonly PHONE_REGEX = /^[\+]?[1-9][\d]{0,15}$/
  private static readonly PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
  private static readonly USERNAME_REGEX = /^[a-zA-Z0-9_]{3,20}$/

  // Common validation rules
  static readonly COMMON_RULES = {
    email: {
      required: true,
      email: true,
      maxLength: 255
    } as ValidationRule,

    password: {
      required: true,
      minLength: 8,
      pattern: this.PASSWORD_REGEX,
      custom: (value: string) => {
        if (!/(?=.*[a-z])/.test(value)) {
          return "Password must contain at least one lowercase letter"
        }
        if (!/(?=.*[A-Z])/.test(value)) {
          return "Password must contain at least one uppercase letter"
        }
        if (!/(?=.*\d)/.test(value)) {
          return "Password must contain at least one number"
        }
        if (!/(?=.*[@$!%*?&])/.test(value)) {
          return "Password must contain at least one special character (@$!%*?&)"
        }
        return null
      }
    } as ValidationRule,

    name: {
      required: true,
      minLength: 2,
      maxLength: 100,
      pattern: /^[a-zA-Z\s'-]+$/
    } as ValidationRule,

    phone: {
      required: false,
      phone: true,
      maxLength: 20
    } as ValidationRule,

    storeName: {
      required: true,
      minLength: 3,
      maxLength: 100,
      alphanumeric: true
    } as ValidationRule,

    confirmPassword: {
      required: true,
      match: "password"
    } as ValidationRule
  }

  // Validate a single field
  static validateField(value: string, rules: ValidationRule, formData?: Record<string, string>): string[] {
    const errors: string[] = []

    // Required validation
    if (rules.required && (!value || value.trim() === "")) {
      errors.push("This field is required")
      return errors
    }

    // Skip other validations if field is empty and not required
    if (!value || value.trim() === "") {
      return errors
    }

    const trimmedValue = value.trim()

    // Length validations
    if (rules.minLength && trimmedValue.length < rules.minLength) {
      errors.push(`Must be at least ${rules.minLength} characters long`)
    }

    if (rules.maxLength && trimmedValue.length > rules.maxLength) {
      errors.push(`Must be no more than ${rules.maxLength} characters long`)
    }

    // Pattern validation
    if (rules.pattern && !rules.pattern.test(trimmedValue)) {
      errors.push("Invalid format")
    }

    // Email validation
    if (rules.email && !this.EMAIL_REGEX.test(trimmedValue)) {
      errors.push("Please enter a valid email address")
    }

    // Phone validation
    if (rules.phone && !this.PHONE_REGEX.test(trimmedValue.replace(/[\s\-\(\)]/g, ""))) {
      errors.push("Please enter a valid phone number")
    }

    // Numeric validation
    if (rules.numeric && !/^\d+$/.test(trimmedValue)) {
      errors.push("Must contain only numbers")
    }

    // Alphanumeric validation
    if (rules.alphanumeric && !/^[a-zA-Z0-9\s]+$/.test(trimmedValue)) {
      errors.push("Must contain only letters and numbers")
    }

    // Field matching (for password confirmation)
    if (rules.match && formData && formData[rules.match] !== trimmedValue) {
      errors.push(`Must match ${rules.match.replace(/([A-Z])/g, ' $1').toLowerCase()}`)
    }

    // Custom validation
    if (rules.custom) {
      const customError = rules.custom(trimmedValue)
      if (customError) {
        errors.push(customError)
      }
    }

    return errors
  }

  // Validate entire form
  static validateForm(formData: Record<string, string>, validationRules: ValidationField): {
    isValid: boolean
    errors: ValidationErrors
  } {
    const errors: ValidationErrors = {}
    let isValid = true

    Object.keys(validationRules).forEach(fieldName => {
      const fieldErrors = this.validateField(
        formData[fieldName] || "",
        validationRules[fieldName],
        formData
      )

      if (fieldErrors.length > 0) {
        errors[fieldName] = fieldErrors
        isValid = false
      }
    })

    return { isValid, errors }
  }

  // Real-time validation for form fields
  static createFieldValidator(
    rules: ValidationRule,
    formData: Record<string, string>,
    onValidationChange?: (fieldName: string, errors: string[]) => void
  ) {
    return (fieldName: string, value: string) => {
      const errors = this.validateField(value, rules, formData)
      onValidationChange?.(fieldName, errors)
      return errors
    }
  }

  // Sanitize input data
  static sanitizeInput(value: string): string {
    return value
      .trim()
      .replace(/[<>]/g, "") // Remove potential HTML tags
      .replace(/javascript:/gi, "") // Remove javascript protocol
      .replace(/on\w+=/gi, "") // Remove event handlers
  }

  // Sanitize entire form data
  static sanitizeFormData(formData: Record<string, string>): Record<string, string> {
    const sanitized: Record<string, string> = {}
    
    Object.keys(formData).forEach(key => {
      sanitized[key] = this.sanitizeInput(formData[key])
    })

    return sanitized
  }
}

// React Hook for form validation
export interface UseFormValidationOptions {
  initialValues: Record<string, string>
  validationRules: ValidationField
  onSubmit: (data: Record<string, string>) => Promise<void>
}

export interface UseFormValidationReturn {
  formData: Record<string, string>
  errors: ValidationErrors
  touched: Record<string, boolean>
  isSubmitting: boolean
  isValid: boolean
  handleChange: (fieldName: string, value: string) => void
  handleBlur: (fieldName: string) => void
  handleSubmit: (e: React.FormEvent) => Promise<void>
  setFieldValue: (fieldName: string, value: string) => void
  setFieldError: (fieldName: string, error: string[]) => void
  resetForm: () => void
}

export function useFormValidation({
  initialValues,
  validationRules,
  onSubmit
}: UseFormValidationOptions): UseFormValidationReturn {
  const [formData, setFormData] = useState(initialValues)
  const [errors, setErrors] = useState<ValidationErrors>({})
  const [touched, setTouched] = useState<Record<string, boolean>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Validate form whenever form data changes
  const isValid = useMemo(() => {
    const validation = FormValidator.validateForm(formData, validationRules)
    return validation.isValid
  }, [formData, validationRules])

  const handleChange = (fieldName: string, value: string) => {
    const sanitizedValue = FormValidator.sanitizeInput(value)
    setFormData(prev => ({ ...prev, [fieldName]: sanitizedValue }))
    
    // Validate field on change
    const fieldErrors = FormValidator.validateField(
      sanitizedValue,
      validationRules[fieldName],
      formData
    )
    
    setErrors(prev => ({
      ...prev,
      [fieldName]: fieldErrors
    }))
  }

  const handleBlur = (fieldName: string) => {
    setTouched(prev => ({ ...prev, [fieldName]: true }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validate all fields
    const validation = FormValidator.validateForm(formData, validationRules)
    setErrors(validation.errors)
    
    // Mark all fields as touched
    const allTouched = Object.keys(validationRules).reduce((acc, key) => {
      acc[key] = true
      return acc
    }, {} as Record<string, boolean>)
    setTouched(allTouched)

    if (!validation.isValid) {
      return
    }

    setIsSubmitting(true)
    try {
      await onSubmit(FormValidator.sanitizeFormData(formData))
    } catch (error) {
      console.error("Form submission error:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const setFieldValue = (fieldName: string, value: string) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }))
  }

  const setFieldError = (fieldName: string, error: string[]) => {
    setErrors(prev => ({ ...prev, [fieldName]: error }))
  }

  const resetForm = () => {
    setFormData(initialValues)
    setErrors({})
    setTouched({})
    setIsSubmitting(false)
  }

  return {
    formData,
    errors,
    touched,
    isSubmitting,
    isValid,
    handleChange,
    handleBlur,
    handleSubmit,
    setFieldValue,
    setFieldError,
    resetForm
  }
}