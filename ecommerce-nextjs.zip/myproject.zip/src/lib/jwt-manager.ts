// JWT Dummy Implementation for Client-side Authentication
export interface JWTPayload {
  id: string
  email: string
  name: string
  role: "CUSTOMER" | "SELLER" | "ADMIN"
  storeId?: string
  storeName?: string
  iat: number
  exp: number
}

export class JWTManager {
  private static readonly TOKEN_KEY = "auth_token"
  private static readonly USER_KEY = "user_data"
  private static readonly TOKEN_EXPIRY = 24 * 60 * 60 * 1000 // 24 hours

  // Generate dummy JWT token
  static generateToken(payload: Omit<JWTPayload, "iat" | "exp">): string {
    const header = { alg: "HS256", typ: "JWT" }
    const now = Math.floor(Date.now() / 1000)
    const jwtPayload: JWTPayload = {
      ...payload,
      iat: now,
      exp: now + (this.TOKEN_EXPIRY / 1000)
    }

    // This is a dummy implementation - in production, use real JWT
    const encodedHeader = btoa(JSON.stringify(header))
    const encodedPayload = btoa(JSON.stringify(jwtPayload))
    const signature = btoa("dummy-signature") // In production, use real HMAC

    return `${encodedHeader}.${encodedPayload}.${signature}`
  }

  // Parse and validate token
  static parseToken(token: string): JWTPayload | null {
    try {
      const [, payloadPart] = token.split(".")
      const payload = JSON.parse(atob(payloadPart)) as JWTPayload

      // Check if token is expired
      if (payload.exp < Math.floor(Date.now() / 1000)) {
        return null
      }

      return payload
    } catch (error) {
      console.error("Failed to parse token:", error)
      return null
    }
  }

  // Save token and user data to localStorage
  static saveAuth(token: string, user: JWTPayload): void {
    localStorage.setItem(this.TOKEN_KEY, token)
    localStorage.setItem(this.USER_KEY, JSON.stringify(user))
  }

  // Get token from localStorage
  static getToken(): string | null {
    if (typeof window === "undefined") return null
    return localStorage.getItem(this.TOKEN_KEY)
  }

  // Get user data from localStorage
  static getUser(): JWTPayload | null {
    if (typeof window === "undefined") return null
    
    const userData = localStorage.getItem(this.USER_KEY)
    if (!userData) return null

    try {
      return JSON.parse(userData)
    } catch (error) {
      console.error("Failed to parse user data:", error)
      return null
    }
  }

  // Validate current session
  static validateSession(): { valid: boolean; user: JWTPayload | null } {
    const token = this.getToken()
    if (!token) {
      return { valid: false, user: null }
    }

    const user = this.parseToken(token)
    if (!user) {
      this.clearAuth()
      return { valid: false, user: null }
    }

    return { valid: true, user }
  }

  // Clear authentication data
  static clearAuth(): void {
    if (typeof window === "undefined") return
    localStorage.removeItem(this.TOKEN_KEY)
    localStorage.removeItem(this.USER_KEY)
  }

  // Refresh token
  static refreshToken(): string | null {
    const user = this.getUser()
    if (!user) return null

    const newToken = this.generateToken(user)
    localStorage.setItem(this.TOKEN_KEY, newToken)
    return newToken
  }

  // Check if user has specific role
  static hasRole(role: "CUSTOMER" | "SELLER" | "ADMIN"): boolean {
    const user = this.getUser()
    return user?.role === role
  }

  // Check if user can access resource (role-based)
  static canAccess(requiredRole: "CUSTOMER" | "SELLER" | "ADMIN"): boolean {
    const user = this.getUser()
    if (!user) return false

    const roleHierarchy = {
      CUSTOMER: 0,
      SELLER: 1,
      ADMIN: 2
    }

    return roleHierarchy[user.role] >= roleHierarchy[requiredRole]
  }

  // Check if user owns the resource
  static canAccessResource(resourceOwnerId: string): boolean {
    const user = this.getUser()
    if (!user) return false

    // Admin can access all resources
    if (user.role === "ADMIN") return true

    // Users can access their own resources
    return user.id === resourceOwnerId
  }

  // Check if seller can access store
  static canAccessStore(storeId: string): boolean {
    const user = this.getUser()
    if (!user) return false

    // Admin can access all stores
    if (user.role === "ADMIN") return true

    // Seller can access their own store
    return user.role === "SELLER" && user.storeId === storeId
  }
}