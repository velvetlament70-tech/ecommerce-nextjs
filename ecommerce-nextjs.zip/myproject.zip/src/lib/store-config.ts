export interface StoreTheme {
  id: string
  name: string
  description: string
  colors: {
    primary: string
    secondary: string
    accent: string
    background: string
    surface: string
    text: string
    textSecondary: string
    border: string
  }
  fonts: {
    heading: string
    body: string
    button: string
  }
  layout: {
    borderRadius: string
    spacing: 'compact' | 'normal' | 'spacious'
    cardStyle: 'flat' | 'elevated' | 'outlined'
    buttonStyle: 'rounded' | 'square' | 'pill'
  }
  effects: {
    animations: boolean
    shadows: boolean
    hoverEffects: boolean
    transitions: boolean
  }
}

export interface StoreFeatures {
  chat: {
    enabled: boolean
    position: 'bottom-right' | 'bottom-left' | 'top-right'
    autoOpen: boolean
    responseTime: string
  }
  discounts: {
    enabled: boolean
    showBadge: boolean
    showTimer: boolean
    autoApply: boolean
  }
  banners: {
    enabled: boolean
    autoRotate: boolean
    interval: number
    showDots: boolean
  }
  reviews: {
    enabled: boolean
    showPhotos: boolean
    showVerified: boolean
    sortBy: 'newest' | 'rating' | 'helpful'
  }
  wishlist: {
    enabled: boolean
    public: boolean
    shareable: boolean
  }
  socialSharing: {
    enabled: boolean
    platforms: ('facebook' | 'twitter' | 'instagram' | 'whatsapp')[]
    position: 'top' | 'bottom'
  }
}

export interface StoreBranding {
  logo: string | null
  banner: string | null
  favicon: string | null
  brandName: string
  tagline: string
  description: string
  contactInfo: {
    email: string
    phone: string
    address: string
    social: {
      facebook: string
      instagram: string
      twitter: string
      youtube: string
    }
  }
}

export interface StoreConfiguration {
  storeId: string
  theme: StoreTheme
  features: StoreFeatures
  branding: StoreBranding
  customCSS: string
  lastModified: string
  version: string
}

// Default themes
export const DEFAULT_THEMES: Record<string, StoreTheme> = {
  light: {
    id: 'light',
    name: 'Light & Fresh',
    description: 'Clean and modern design with bright colors',
    colors: {
      primary: '#3b82f6',
      secondary: '#10b981',
      accent: '#f59e0b',
      background: '#ffffff',
      surface: '#f8fafc',
      text: '#1f2937',
      textSecondary: '#6b7280',
      border: '#e5e7eb'
    },
    fonts: {
      heading: 'Inter, sans-serif',
      body: 'Inter, sans-serif',
      button: 'Inter, sans-serif'
    },
    layout: {
      borderRadius: '0.5rem',
      spacing: 'normal',
      cardStyle: 'elevated',
      buttonStyle: 'rounded'
    },
    effects: {
      animations: true,
      shadows: true,
      hoverEffects: true,
      transitions: true
    }
  },
  minimalist: {
    id: 'minimalist',
    name: 'Minimalist',
    description: 'Simple and clean design with minimal elements',
    colors: {
      primary: '#000000',
      secondary: '#666666',
      accent: '#ff6b6b',
      background: '#ffffff',
      surface: '#fafafa',
      text: '#000000',
      textSecondary: '#666666',
      border: '#e0e0e0'
    },
    fonts: {
      heading: 'Helvetica, Arial, sans-serif',
      body: 'Helvetica, Arial, sans-serif',
      button: 'Helvetica, Arial, sans-serif'
    },
    layout: {
      borderRadius: '0rem',
      spacing: 'compact',
      cardStyle: 'flat',
      buttonStyle: 'square'
    },
    effects: {
      animations: false,
      shadows: false,
      hoverEffects: true,
      transitions: true
    }
  },
  dark: {
    id: 'dark',
    name: 'Dark Mode',
    description: 'Modern dark theme with high contrast',
    colors: {
      primary: '#818cf8',
      secondary: '#34d399',
      accent: '#fbbf24',
      background: '#111827',
      surface: '#1f2937',
      text: '#f9fafb',
      textSecondary: '#d1d5db',
      border: '#374151'
    },
    fonts: {
      heading: 'Inter, sans-serif',
      body: 'Inter, sans-serif',
      button: 'Inter, sans-serif'
    },
    layout: {
      borderRadius: '0.75rem',
      spacing: 'spacious',
      cardStyle: 'elevated',
      buttonStyle: 'rounded'
    },
    effects: {
      animations: true,
      shadows: true,
      hoverEffects: true,
      transitions: true
    }
  }
}

// Default features configuration
export const DEFAULT_FEATURES: StoreFeatures = {
  chat: {
    enabled: true,
    position: 'bottom-right',
    autoOpen: false,
    responseTime: '< 1 jam'
  },
  discounts: {
    enabled: true,
    showBadge: true,
    showTimer: true,
    autoApply: false
  },
  banners: {
    enabled: true,
    autoRotate: true,
    interval: 5000,
    showDots: true
  },
  reviews: {
    enabled: true,
    showPhotos: true,
    showVerified: true,
    sortBy: 'newest'
  },
  wishlist: {
    enabled: true,
    public: false,
    shareable: true
  },
  socialSharing: {
    enabled: true,
    platforms: ['facebook', 'twitter', 'whatsapp'],
    position: 'bottom'
  }
}

// Default branding
export const DEFAULT_BRANDING: StoreBranding = {
  logo: null,
  banner: null,
  favicon: null,
  brandName: '',
  tagline: '',
  description: '',
  contactInfo: {
    email: '',
    phone: '',
    address: '',
    social: {
      facebook: '',
      instagram: '',
      twitter: '',
      youtube: ''
    }
  }
}

// Default configuration
export const DEFAULT_CONFIG: StoreConfiguration = {
  storeId: '',
  theme: DEFAULT_THEMES.light,
  features: DEFAULT_FEATURES,
  branding: DEFAULT_BRANDING,
  customCSS: '',
  lastModified: new Date().toISOString(),
  version: '1.0.0'
}