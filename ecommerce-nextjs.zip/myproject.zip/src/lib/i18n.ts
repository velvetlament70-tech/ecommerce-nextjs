'use client'

import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'
import LanguageDetector from 'i18next-browser-languagedetector'

// Import translation files
import enTranslations from './locales/en.json'
import idTranslations from './locales/id.json'
import esTranslations from './locales/es.json'
import frTranslations from './locales/fr.json'
import zhTranslations from './locales/zh.json'
import jaTranslations from './locales/ja.json'

const resources = {
  en: {
    translation: enTranslations
  },
  id: {
    translation: idTranslations
  },
  es: {
    translation: esTranslations
  },
  fr: {
    translation: frTranslations
  },
  zh: {
    translation: zhTranslations
  },
  ja: {
    translation: jaTranslations
  }
}

// Initialize i18n
i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    debug: process.env.NODE_ENV === 'development',
    
    interpolation: {
      escapeValue: false
    },
    
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage']
    }
  })

export function TranslationProvider({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}

export default i18n