"use client"

import React, { createContext, useContext, useEffect, useState, ReactNode } from "react"
import { JWTManager, JWTPayload } from "@/lib/jwt-manager"
import { toastHelpers } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

interface AuthContextType {
  user: JWTPayload | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<boolean>
  register: (userData: RegisterData) => Promise<boolean>
  logout: () => void
  refreshToken: () => Promise<boolean>
  hasRole: (role: "CUSTOMER" | "SELLER" | "ADMIN") => boolean
  canAccess: (requiredRole: "CUSTOMER" | "SELLER" | "ADMIN") => boolean
  canAccessResource: (resourceOwnerId: string) => boolean
  canAccessStore: (storeId: string) => boolean
}

interface RegisterData {
  name: string
  email: string
  phone?: string
  password: string
  confirmPassword: string
  role: "CUSTOMER" | "SELLER"
}

interface AuthProviderProps {
  children: ReactNode
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<JWTPayload | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Check authentication status on mount
  useEffect(() => {
    const checkAuth = () => {
      try {
        const { valid, user: userData } = JWTManager.validateSession()
        
        if (valid && userData) {
          setUser(userData)
        } else {
          JWTManager.clearAuth()
          setUser(null)
        }
      } catch (error) {
        console.error("Auth check error:", error)
        JWTManager.clearAuth()
        setUser(null)
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()

    // Set up periodic token refresh
    const refreshInterval = setInterval(() => {
      if (JWTManager.getToken()) {
        refreshToken()
      }
    }, 30 * 60 * 1000) // Refresh every 30 minutes

    return () => clearInterval(refreshInterval)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true)
    
    try {
      // Simulate API call
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        toastHelpers.loginError(errorData.error || "Invalid credentials")
        return false
      }

      const data = await response.json()
      
      if (data.user && data.token) {
        // Save authentication data
        JWTManager.saveAuth(data.token, data.user)
        setUser(data.user)
        
        toastHelpers.loginSuccess(data.user.name)
        
        // Redirect based on role
        switch (data.user.role) {
          case "ADMIN":
            router.push("/admin/dashboard")
            break
          case "SELLER":
            if (data.user.storeId) {
              router.push("/seller/dashboard")
            } else {
              router.push("/buat-toko")
            }
            break
          default:
            router.push("/")
        }
        
        return true
      }
      
      toastHelpers.loginError("Login failed")
      return false
    } catch (error) {
      console.error("Login error:", error)
      toastHelpers.networkError()
      return false
    } finally {
      setIsLoading(false)
    }
  }

  const register = async (userData: RegisterData): Promise<boolean> => {
    setIsLoading(true)
    
    try {
      // Simulate API call
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
      })

      if (!response.ok) {
        const errorData = await response.json()
        toastHelpers.registerError(errorData.error || "Registration failed")
        return false
      }

      const data = await response.json()
      
      if (data.user && data.token) {
        // Save authentication data
        JWTManager.saveAuth(data.token, data.user)
        setUser(data.user)
        
        toastHelpers.registerSuccess()
        
        // Redirect based on role
        if (userData.role === "SELLER") {
          router.push("/buat-toko")
        } else {
          router.push("/")
        }
        
        return true
      }
      
      toastHelpers.registerError("Registration failed")
      return false
    } catch (error) {
      console.error("Registration error:", error)
      toastHelpers.networkError()
      return false
    } finally {
      setIsLoading(false)
    }
  }

  const logout = () => {
    try {
      JWTManager.clearAuth()
      setUser(null)
      toastHelpers.logoutSuccess()
      router.push("/auth/signin")
    } catch (error) {
      console.error("Logout error:", error)
    }
  }

  const refreshToken = async (): Promise<boolean> => {
    try {
      const newToken = JWTManager.refreshToken()
      if (newToken) {
        const userData = JWTManager.parseToken(newToken)
        if (userData) {
          setUser(userData)
          return true
        }
      }
      
      // Token refresh failed, logout user
      logout()
      toastHelpers.sessionExpired()
      return false
    } catch (error) {
      console.error("Token refresh error:", error)
      logout()
      toastHelpers.sessionExpired()
      return false
    }
  }

  const hasRole = (role: "CUSTOMER" | "SELLER" | "ADMIN"): boolean => {
    return user?.role === role
  }

  const canAccess = (requiredRole: "CUSTOMER" | "SELLER" | "ADMIN"): boolean => {
    if (!user) return false
    
    const roleHierarchy = {
      CUSTOMER: 0,
      SELLER: 1,
      ADMIN: 2
    }
    
    return roleHierarchy[user.role] >= roleHierarchy[requiredRole]
  }

  const canAccessResource = (resourceOwnerId: string): boolean => {
    if (!user) return false
    
    // Admin can access all resources
    if (user.role === "ADMIN") return true
    
    // Users can access their own resources
    return user.id === resourceOwnerId
  }

  const canAccessStore = (storeId: string): boolean => {
    if (!user) return false
    
    // Admin can access all stores
    if (user.role === "ADMIN") return true
    
    // Seller can access their own store
    return user.role === "SELLER" && user.storeId === storeId
  }

  const value: AuthContextType = {
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    register,
    logout,
    refreshToken,
    hasRole,
    canAccess,
    canAccessResource,
    canAccessStore,
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

// Higher-order component for route protection
export interface ProtectedRouteProps {
  children: ReactNode
  requiredRole?: "CUSTOMER" | "SELLER" | "ADMIN"
  fallback?: ReactNode
  redirectTo?: string
}

export function ProtectedRoute({
  children,
  requiredRole,
  fallback,
  redirectTo = "/auth/signin"
}: ProtectedRouteProps) {
  const { isAuthenticated, isLoading, canAccess } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push(redirectTo)
      return
    }

    if (!isLoading && isAuthenticated && requiredRole && !canAccess(requiredRole)) {
      toastHelpers.unauthorized()
      router.push("/unauthorized")
      return
    }
  }, [isLoading, isAuthenticated, requiredRole, canAccess, router, redirectTo])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return fallback || null
  }

  if (requiredRole && !canAccess(requiredRole)) {
    return fallback || null
  }

  return <>{children}</>
}

// Hook for checking store access
export function useStoreAccess(storeId: string) {
  const { canAccessStore, user } = useAuth()
  
  return {
    canAccess: canAccessStore(storeId),
    isOwner: user?.storeId === storeId,
    isAdmin: user?.role === "ADMIN"
  }
}

// Hook for checking resource access
export function useResourceAccess(resourceOwnerId: string) {
  const { canAccessResource, user } = useAuth()
  
  return {
    canAccess: canAccessResource(resourceOwnerId),
    isOwner: user?.id === resourceOwnerId,
    isAdmin: user?.role === "ADMIN"
  }
}